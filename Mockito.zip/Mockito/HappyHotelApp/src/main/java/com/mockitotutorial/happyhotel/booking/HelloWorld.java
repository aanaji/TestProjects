package com.mockitotutorial.happyhotel.booking;
//bean
public class HelloWorld {
    public HelloWorld(String msg){
         System.out.println( msg + ", " + this);
    }   
}

