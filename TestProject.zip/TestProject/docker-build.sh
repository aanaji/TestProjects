#!/bin/bash

APPLICATION_NAME=com-manh-cp-ext-$APP_SHORTNAME

echo "> Cleaning build/docker-stage..."
rm -Rf build/docker-stage
mkdir build/docker-stage
mkdir build/docker-stage/nativelibs

echo "> Staging the content for containerization..."
cp src/main/docker/* build/docker-stage/
cp src/main/resources/*.jks build/docker-stage/
cp build/libs/ext-$APP_SHORTNAME-$APP_VERSION.jar build/docker-stage/main-stage.jar

echo "> Building $APPLICATION_NAME:latest"
docker build -t testProject:latest build/docker-stage

echo "> Done."

