package com.example.demo.controller;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.CreditCardPaymentRequest;
import com.example.demo.dto.PaymentRequest;
import com.example.demo.entity.Employee;
import com.example.demo.entity.OrderEntity;
import com.example.demo.entity.Voter;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.repository.OrderRepository;
import com.example.demo.repository.VoterRepository;
import com.example.demo.service.OrderService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;

@RestController
@RequestMapping("/test")
// @Scope("session")
@SpringBootConfiguration
public class TestController
{

    /*
     * @Autowired TestService testService;
     */

    @Autowired
    OrderRepository orderRepository;

    @Autowired
    MeterRegistry meterRegistry;

    @Autowired
    EmployeeRepository employeeRepository;

    Timer timer;

    @Autowired
    OrderService orderService;

    @Autowired
    private VoterRepository voterRepository;
    /*
     * private Timer getClassTimer;
     * 
     * private Timer saveOrderTimer;
     * 
     * @Autowired public TestController(MetricRegistry metricRegistry) {
     * 
     * String controllerName = TestController.class.getName(); this.getClassTimer = metricRegistry.timer(controllerName
     * + ".getClassTimer"); this.saveOrderTimer = metricRegistry.timer(controllerName + ".saveOrderTimer"); }
     */
    /*
     * private Meter meter;
     * 
     * @Autowired public TestController(MetricRegistry metricRegistry) {
     * 
     * this.meter = metricRegistry.meter(getClass() + "meter"); }
     */

    // @Autowired
    // CRUDFunction crudFunction;

    @GetMapping("/getClssName")
    public String getClassInstance()
    {

        long startTime = System.currentTimeMillis();
        String className = "Test";

        meterRegistry.counter(TestController.class.getName() + ".getClassCount").increment();

        meterRegistry.timer(TestController.class.getName() + ".getClassTimer")
                .record(System.currentTimeMillis() - startTime, TimeUnit.MILLISECONDS);
        return className;
    }

    /*
     * @Lookup public TestService getTestService() { return testService; }
     * 
     * public void setTestService(TestService testService) { this.testService = testService; }
     */

    @PostMapping("/saveOrder")
    public OrderEntity saveOrder(@RequestBody OrderEntity orderEntity) throws Exception
    {

        long startTime = System.currentTimeMillis();
        OrderEntity saveOrder = orderService.saveOrder(orderEntity); // = orderRepository.save(orderEntity);
        meterRegistry.counter(TestController.class.getName() + ".saveOrderCount").increment();
        meterRegistry.timer(TestController.class.getName() + ".saveOrderTimer")
                .record(System.currentTimeMillis() - startTime, TimeUnit.MILLISECONDS);

        return saveOrder;
    }

    @GetMapping("/getOrder/{OrderId}")
    public OrderEntity getOrder(@PathVariable String OrderId)
    {

        long startTime = System.currentTimeMillis();
        OrderEntity saveOrder = orderRepository.findByOrderId(OrderId);
        meterRegistry.counter(TestController.class.getName() + ".getOrderCount").increment();
        meterRegistry.timer(TestController.class.getName() + ".getOrderTimer")
                .record(System.currentTimeMillis() - startTime, TimeUnit.MILLISECONDS);

        return saveOrder;
    }

    @DeleteMapping("/deleteOrder/{OrderId}")
    public void deleteOrderById(@PathVariable String OrderId)
    {

        long startTime = System.currentTimeMillis();
        orderRepository.deleteByOrderId(OrderId);
        meterRegistry.counter(TestController.class.getName() + ".deleteOrderCount").increment();
        meterRegistry.timer(TestController.class.getName() + ".deleteOrderTimer")
                .record(System.currentTimeMillis() - startTime, TimeUnit.MILLISECONDS);

    }

    @GetMapping("/getAllOrder")
    public Page<OrderEntity> getAllOrder(@RequestParam(value = "page") int page, @RequestParam(value = "size") int size)
    {
        long startTime = System.currentTimeMillis();

        Pageable pageable = PageRequest.of(page, size);

        Page<OrderEntity> OrderList = orderRepository.findAll(pageable);

        meterRegistry.counter(TestController.class.getName() + ".deleteOrderCount").increment();
        meterRegistry.timer(TestController.class.getName() + ".deleteOrderTimer")
                .record(System.currentTimeMillis() - startTime, TimeUnit.MILLISECONDS);

        return OrderList;
    }

    @GetMapping("/getOrderUsingQuery/{OrderId}")
    @Transactional
    public OrderEntity getOrderUsingQuery(@PathVariable String OrderId)
    {

        long startTime = System.currentTimeMillis();
        OrderEntity getOrder = orderService.lockOrder(OrderId);
        meterRegistry.counter(TestController.class.getName() + ".getOrderUsingQueryCount").increment();
        meterRegistry.timer(TestController.class.getName() + ".getOrderUsingQueryTimer")
                .record(System.currentTimeMillis() - startTime, TimeUnit.MILLISECONDS);

        return getOrder;
    }

    /*
     * public Order getOrderByOrderId(@PathVariable String OrderId) {
     * 
     * JPQLQuery
     * 
     * return new Order(); }
     */

    @GetMapping("/getPayment")
    public PaymentRequest getPaymentRequest()
    {

        CreditCardPaymentRequest paymentRequest = new CreditCardPaymentRequest();

        paymentRequest.setCardType("VISA");
        paymentRequest.setCreditCard("123123213");
        paymentRequest.setCustomerName("Ananda");

        return paymentRequest;
    }

    @PostMapping("/saveEmployee")
    public Employee saveEmployee(@RequestBody Employee emp)
    {

        return employeeRepository.save(emp);

    }

    @GetMapping("/getEmployee/{employee}")
    public Employee getEmployee(@PathVariable Long employee) throws JsonProcessingException
    {

        Employee emp = employeeRepository.findById(employee).get();

        ObjectMapper mapper = new ObjectMapper();

        // System.out.println(mapper.writeValueAsString(emp));

        return emp;

    }

    @PostMapping("/voter")
    public Voter saveVoter(@RequestBody Voter voter) throws JsonProcessingException
    {

        ObjectMapper mapper = new ObjectMapper();

        System.out.println(mapper.writeValueAsString(voter));
        return voterRepository.save(voter);

    }
}
