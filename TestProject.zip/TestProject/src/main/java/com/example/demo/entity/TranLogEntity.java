package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TRAN_LOG")
public class TranLogEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TRAN_LOG_SEQUENCE")
	@SequenceGenerator(name = "TRAN_LOG_SEQUENCE", initialValue = 1, allocationSize = 1000000000)
	Long pk;

	@Column
	String action;

	@Column
	String user;

	public Long getPk() {
		return pk;
	}

	public void setPk(Long pk) {
		this.pk = pk;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

}
