package com.example.demo.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ORD_ORDER")
public class OrderEntity
{

    /*
     * @Id
     * 
     * @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_Sequence") Integer number;
     */

    // @Column(columnDefinition = "serial")
    @Id
    // @GeneratedValue(strategy = GenerationType.IDENTITY)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ORDER_SEQUENCE")
    @SequenceGenerator(name = "ORDER_SEQUENCE", initialValue = 1, allocationSize = 10)
    @Column(name = "PK")
    private long pk;

    @Column
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String orderId;

    @Column
    private Double orderTotal;

    @Column
    private String customerName;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "order", targetEntity = OrderLineEntity.class)
    // @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = OrderLineEntity.class)
    // @JoinColumn(name = "order_pk")
    private List<OrderLineEntity> orderLine;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "customer_pk")
    private CustomerEntity customer;

    @Enumerated(EnumType.STRING)
    private State state;

    public String getOrderId()
    {
        return orderId;
    }

    public void setOrderId(String orderId)
    {
        this.orderId = orderId;
    }

    public Double getOrderTotal()
    {
        return orderTotal;
    }

    public void setOrderTotal(Double orderTotal)
    {
        this.orderTotal = orderTotal;
    }

    public String getCustomerName()
    {
        return customerName;
    }

    public void setCustomerName(String customerName)
    {
        this.customerName = customerName;
    }

    public long getPk()
    {
        return pk;
    }

    public void setPk(long pk)
    {
        this.pk = pk;
    }

    public List<OrderLineEntity> getOrderLine()
    {
        return orderLine;
    }

    public void setOrderLine(List<OrderLineEntity> orderLine)
    {
        this.orderLine = orderLine;
    }

    public CustomerEntity getCustomer()
    {
        return customer;
    }

    public void setCustomer(CustomerEntity customer)
    {
        this.customer = customer;
    }

    public enum State
    {
        CREATED, FAILED, SUCCESSFUL
    }

    public State getState()
    {
        return state;
    }

    public void setState(State state)
    {
        this.state = state;
    }

}
