package com.example.demo.test;

import java.io.IOException;

import com.example.demo.dto.Account;
import com.example.demo.dto.CreditCardPaymentRequest;

public class Prototype
{

    public static void main(String[] args) throws CloneNotSupportedException, IOException
    {

        long startTime = System.currentTimeMillis();

        CreditCardPaymentRequest paymentRequest = new CreditCardPaymentRequest();

        Account account = new Account();

        paymentRequest.setCardType("VISA");
        paymentRequest.setCreditCard("123123213");
        paymentRequest.setCustomerName("Ananda");
        paymentRequest.openFile();
        paymentRequest.setAccount(account);

        // System.out.println(paymentRequest.isFileOpen());
        for (int i = 0; i < 10000; i++)
        {
            CreditCardPaymentRequest cloned = paymentRequest.clone();
            System.out.println(cloned.getAccount());
            // cloned.setFileOpen(false);
            // System.out.println(cloned.isFileOpen());

            /*
             * CreditCardPaymentRequest paymentRequest = new CreditCardPaymentRequest(); //
             * System.out.println(paymentRequest.isFileOpen()); paymentRequest.setCardType("VISA");
             * paymentRequest.setCreditCard("123123213"); paymentRequest.setCustomerName("Ananda");
             * paymentRequest.openFile();
             */
            // System.out.println(paymentRequest);

        }

        System.out.println(System.currentTimeMillis() - startTime);
    }
}
