package com.example.demo.test;
// Program to Demonstrate the size() method

// of ArrayBlockingQueue.

import java.util.concurrent.ArrayBlockingQueue;

public class GFG
{

    public static void main(String[] args) throws InterruptedException
    {
        // Define capacity of ArrayBlockingQueue
        int capacity = 5;

        // Create object of ArrayBlockingQueue
        ArrayBlockingQueue<Integer> queue = new ArrayBlockingQueue<Integer>(capacity);

        // Add elements to ArrayBlockingQueue
        queue.add(23);

        System.out.println(queue.take());

        System.out.println(queue.take());
        /*
         * queue.add(32); queue.add(45);
         * 
         * // Print size of queue after adding numbers int size = queue.size();
         * System.out.println("After addding numbers" + " Queue size = " + size);
         * 
         * // Add more elements to ArrayBlockingQueue queue.add(88); queue.add(42); // queue.add(88); queue.put(412);
         * queue.put(122);
         */

        // Print size of queue after adding numbers
        int size = queue.size();
        System.out.println("After addding more numbers" + " Queue size = " + size);

    }
}
