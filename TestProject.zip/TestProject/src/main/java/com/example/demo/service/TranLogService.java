
package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.TranLogEntity;
import com.example.demo.repository.TranLogRepository;

@Service
public class TranLogService {

	@Autowired
	TranLogRepository tranLogRepository;

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void saveTranLog() throws Exception {

		System.out.println("saveTranLog entry");
		TranLogEntity entity = new TranLogEntity();

		entity.setAction("Create");
		entity.setUser("Ananda");

		tranLogRepository.save(entity);

		if (entity.getUser().equalsIgnoreCase("Ananda")) {
			throw new RuntimeException();
		}

		System.out.println("saveTranLog exit");
	}
}
