package com.example.demo.annotation;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(prefix = "com.manh", name = "test", matchIfMissing = true)
public class ConditionTest
{

}
