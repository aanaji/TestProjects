package com.example.demo.dto;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CreditCardPaymentRequest extends PaymentRequest implements Cloneable
{

    private String creditCard;

    private String cardType;

    private boolean isFileOpen;

    private Account account;

    public String getCreditCard()
    {
        return creditCard;
    }

    public void setCreditCard(String creditCard)
    {
        this.creditCard = creditCard;
    }

    public String getCardType()
    {
        return cardType;
    }

    public void setCardType(String cardType)
    {
        this.cardType = cardType;
    }

    public void openFile() throws IOException
    {
        if (!isFileOpen)
        {
            FileReader fr = new FileReader("/Users/aanaji/Desktop/Backup_codes.txt");

            fr.close();
            isFileOpen = true;
        }
    }

    public boolean isFileOpen()
    {
        return isFileOpen;
    }

    public void setFileOpen(boolean isFileOpen)
    {
        this.isFileOpen = isFileOpen;
    }

    public Account getAccount()
    {
        return account;
    }

    public void setAccount(Account account)
    {
        this.account = account;
    }

    @Override
    public CreditCardPaymentRequest clone() throws CloneNotSupportedException
    {
        return (CreditCardPaymentRequest) super.clone();

    }

}