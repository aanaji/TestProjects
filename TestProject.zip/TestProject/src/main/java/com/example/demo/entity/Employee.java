package com.example.demo.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "Employee")
public class Employee
{

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EmployeeIdSequence")
    @SequenceGenerator(name = "EmployeeIdSequence", initialValue = 1, allocationSize = 50)
    private long employeeId;

    @Column
    private String employeeName;

    @Column
    private String parentEmployeeId;

    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "parentEmployeeId", insertable = false, updatable = false)
    // @JsonIgnore
    @JsonBackReference
    private Employee parentEmployee;

    @OneToMany(mappedBy = "parentEmployee", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private Set<Employee> reportingEmployee;

    public long getEmployeeId()
    {
        return employeeId;
    }

    public void setEmployeeId(long employeeId)
    {
        this.employeeId = employeeId;
    }

    public String getEmployeeName()
    {
        return employeeName;
    }

    public void setEmployeeName(String employeeName)
    {
        this.employeeName = employeeName;
    }

    public String getParentEmployeeId()
    {
        return parentEmployeeId;
    }

    public void setParentEmployeeId(String parentEmployeeId)
    {
        this.parentEmployeeId = parentEmployeeId;
    }

    public Employee getParentEmployee()
    {
        return parentEmployee;
    }

    public void setParentEmployee(Employee parentEmployee)
    {
        this.parentEmployee = parentEmployee;
    }

    public Set<Employee> getReportingEmployee()
    {
        return reportingEmployee;
    }

    public void setReportingEmployee(Set<Employee> reportingEmployee)
    {
        this.reportingEmployee = reportingEmployee;
    }

}
