package com.example.demo.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToOne;

@Entity
public class Voter
{

    @Column
    public String name;

    @Column
    public String gender;

    @Id
    @Column(name = "VOTER_ID")
    public String id;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinTable(name = "MOVIE_VOTERS", joinColumns = @JoinColumn(name = "VOTER_ID"), inverseJoinColumns = @JoinColumn(name = "MOVIE_ID"))
    public Movie movie;

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getGender()
    {
        return gender;
    }

    public void setGender(String gender)
    {
        this.gender = gender;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public Movie getMovie()
    {
        return movie;
    }

    public void setMovie(Movie movie)
    {
        this.movie = movie;
    }

}
