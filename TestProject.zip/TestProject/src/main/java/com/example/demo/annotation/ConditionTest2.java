package com.example.demo.annotation;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingClass;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnMissingClass(value = "com.example.demo.annotation.ConditionTest")
public class ConditionTest2
{

}
