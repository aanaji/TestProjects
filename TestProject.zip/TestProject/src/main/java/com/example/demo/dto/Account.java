package com.example.demo.dto;

public class Account
{

    String testName;

    public String getTestName()
    {
        return testName;
    }

    public void setTestName(String testName)
    {
        this.testName = testName;
    }

}
