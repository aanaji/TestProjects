package com.example.demo.java8;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Supplier;

public class Snippet
{
    public static void main(String[] args) throws InterruptedException, ExecutionException
    {
        System.out.println(CompletableFuture.supplyAsync(() -> "ab").thenApply(String::toUpperCase)
                .thenApply(x -> x.substring(1)).join());

        CompletableFuture<String> completableFuture = CompletableFuture.supplyAsync((Supplier<String>) () -> {
            try
            {
                Thread.sleep(1000L);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
            System.out.println("Hello");

            return "Ananda";
        });
        System.out.println("World!");

        System.out.println(completableFuture.join());
        // Thread.sleep(5000L);
    }
}
