package com.example.demo.dto;

public class PaymentRequest
{

    private String customerName;

    public String getCustomerName()
    {
        return customerName;
    }

    public void setCustomerName(String customerName)
    {
        this.customerName = customerName;
    }

}
