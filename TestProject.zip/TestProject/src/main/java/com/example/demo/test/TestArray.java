package com.example.demo.test;

import java.util.ArrayList;
import java.util.List;

public class TestArray
{

    public static void main(String[] args)
    {
        int[] abc = { 1, 2, 4, 5 };

        System.out.println(abc.length);

        List<String> inputList = new ArrayList<>();

        inputList.add("Test");

        // inputList.so
        // inputList.

        while (inputList.iterator().hasNext())
        {

            System.out.println(inputList.iterator().next());
        }

    }
}
