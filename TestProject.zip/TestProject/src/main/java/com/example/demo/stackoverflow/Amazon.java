package com.example.demo.stackoverflow;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Amazon
{

    public static URL url;

    public static void main(String[] args) throws IOException
    {
        /*
         * BufferedReader br = null;
         * 
         * try {
         * 
         * url = new URL("https://www.amazon.com");
         * 
         * } catch (MalformedURLException ex) {
         * 
         * System.out.println("came exception"); }
         * 
         * try { url.openConnection(); br = new BufferedReader(new InputStreamReader(url.openStream())); String line;
         * 
         * StringBuilder sb = new StringBuilder();
         * 
         * while ((line = br.readLine()) != null) {
         * 
         * sb.append(line); sb.append(System.lineSeparator()); }
         * 
         * System.out.println(sb);
         * 
         * } catch (Exception e) { System.out.println("Exception: " + e.toString()); }
         * 
         * URL oracle = new URL("https://www.amazon.com/"); oracle.openConnection(); BufferedReader in = new
         * BufferedReader(new InputStreamReader(oracle.openStream())); String inputLine; StringBuilder sb = new
         * StringBuilder(); while ((inputLine = in.readLine()) != null) sb.append(inputLine);
         * sb.append(System.lineSeparator()); in.close();
         * 
         * System.out.println(sb);
         */

        /*
         * RestTemplate restTemplate = new RestTemplate();
         * 
         * HttpHeaders headers = new HttpHeaders();
         * headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
         * 
         * headers.set("User-Agent",
         * "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");
         * 
         * HttpEntity<String> entity = new HttpEntity<>(headers); Map response = (Map)
         * restTemplate.exchange("https://www.amazon.com/", HttpMethod.GET, entity, Map.class); // (Map) //
         * restTemplate.getForEntity("https://www.amazon.com/", // Map.class);
         * 
         * System.out.println(response);
         */

        URL url = new URL("https://www.amazon.com");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestProperty("User-Agent",
                "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");

        BufferedReader bufr = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String data;
        while ((data = bufr.readLine()) != null)
            System.out.println(data);
    }
}
