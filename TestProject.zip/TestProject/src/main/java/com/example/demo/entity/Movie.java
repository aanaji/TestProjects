package com.example.demo.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class Movie
{

    @Column
    public String movieName;

    @Column
    public String language;

    @Column(name = "MOVIE_ID")
    @Id
    public String id;

    /*
     * @OneToMany
     * 
     * @JoinTable(name = "MOVIE_VOTERS", joinColumns = @JoinColumn(name = "MOVIE_ID"), inverseJoinColumns
     * = @JoinColumn(name = "VOTER_ID")) public List<Voter> voterList;
     */

    public String getMovieName()
    {
        return movieName;
    }

    public void setMovieName(String movieName)
    {
        this.movieName = movieName;
    }

    public String getLanguage()
    {
        return language;
    }

    public void setLanguage(String language)
    {
        this.language = language;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    /*
     * public List<Voter> getVoterList() { return voterList; }
     * 
     * public void setVoterList(List<Voter> voterList) { this.voterList = voterList; }
     */

}
