package com.example.demo.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.cfg.Environment;
import org.hibernate.jdbc.Work;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.OrderEntity;
import com.example.demo.repository.OrderRepository;

@Service
public class OrderService
{

    @Autowired
    OrderRepository orderRepository;

    @Autowired
    TranLogService tranLogService;

    @PersistenceContext
    EntityManager entityManger;

    int orderId = 0;

    @Transactional(propagation = Propagation.REQUIRED)
    public OrderEntity saveOrder(OrderEntity order) throws Exception
    {

        System.out.println("saveorder entry");

        // order.setPk(new Long(orderId++));
        Query query = entityManger.createQuery("from OrderEntity where orderId = :orderId");
        query.setParameter("orderId", order.getOrderId());
        query.setLockMode(LockModeType.PESSIMISTIC_WRITE);

        //order.getOrderLine().forEach(orderLine -> orderLine.setOrder(order));

        OrderEntity savedOrder = orderRepository.save(order);

        try
        {
            tranLogService.saveTranLog();
        }
        catch (Exception e)
        {
            System.out.println("caught exception");
        }

        System.out.println("saveorder exit");
        return savedOrder;

    }

    @Transactional(propagation = Propagation.REQUIRED)
    public OrderEntity lockOrder(String orderId)
    {

        // OrderEntity orderEntity = entityManger.find(OrderEntity.class, orderId);

        Query query = entityManger.createQuery("from OrderEntity where orderId = :orderId");
        query.setParameter("orderId", orderId);
        query.setLockMode(LockModeType.PESSIMISTIC_WRITE);
        // entityManger.lock(orderEntity, LockModeType.PESSIMISTIC_WRITE);

        List result = query.getResultList();
        if (result != null && !result.isEmpty())
        {
            System.out.println("Locked Order");
        }

        return new OrderEntity();
    }

    public void checkIsolationLevel()
    {
        // Query query = entityManger.createQuery("from OrderEntity where orderId = :orderId");

        Session session = entityManger.unwrap(Session.class);

        // Transaction txn = session.beginTransaction();

        try
        {
            session.doWork(new Work()
            {
                @Override
                public void execute(Connection connection) throws SQLException
                {
                    System.out.println("Transaction isolation level is "
                            + Environment.isolationLevelToString(connection.getTransactionIsolation()));
                }
            });
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }
}
