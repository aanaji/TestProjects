package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ORD_ORDER_LINE")
public class OrderLineEntity
{

    // @Column(columnDefinition = "serial")
    @Id
    // @GeneratedValue(strategy = GenerationType.IDENTITY)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ORDER_LINE_SEQUENCE")
    @SequenceGenerator(name = "ORDER_LINE_SEQUENCE", initialValue = 1, allocationSize = 10)
    long orderLinePK;

    @Column(nullable = false)
    private String orderLineId;

    @Column
    private String itemId;

    @ManyToOne(targetEntity = OrderEntity.class)
    //@JoinColumn(name = "orderPK")
    @JsonIgnore
    private OrderEntity order;

    public long getOrderLinePK()
    {
        return orderLinePK;
    }

    public void setOrderLinePK(long orderLinePK)
    {
        this.orderLinePK = orderLinePK;
    }

    public String getOrderLineId()
    {
        return orderLineId;
    }

    public void setOrderLineId(String orderLineId)
    {
        this.orderLineId = orderLineId;
    }

    public String getItemId()
    {
        return itemId;
    }

    public void setItemId(String itemId)
    {
        this.itemId = itemId;
    }

    public OrderEntity getOrder()
    {
        return order;
    }

    public void setOrder(OrderEntity order)
    {
        this.order = order;
    }

}
