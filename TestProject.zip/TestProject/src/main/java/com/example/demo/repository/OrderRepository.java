package com.example.demo.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.OrderEntity;

@Component
@Transactional
public interface OrderRepository extends PagingAndSortingRepository<OrderEntity, Long>
{

    OrderEntity findByOrderId(String orderId);

    @Transactional
    void deleteByOrderId(String orderId);

    @Transactional(propagation = Propagation.REQUIRED)
    // @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query(value = "select * from ORD_ORDER where order_Id =?1 for update", nativeQuery = true)
    OrderEntity findUsingQuery(String orderId);
}
