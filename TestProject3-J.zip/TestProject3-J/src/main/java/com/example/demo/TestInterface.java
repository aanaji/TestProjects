package com.example.demo;

import java.util.ArrayList;
import java.util.List;

public interface TestInterface
{

    List<String> abc = new ArrayList<>();
}
