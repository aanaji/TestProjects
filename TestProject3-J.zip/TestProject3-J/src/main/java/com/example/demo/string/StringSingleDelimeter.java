package com.example.demo.string;

import java.util.Arrays;

public class StringSingleDelimeter
{

    public static void main(String[] args)
    {
        String str1 = "two-separate-tokens-this--is--just--one--token-another";

        String[] output = Arrays.asList(str1.split("(?<!-)-(?!-)")).stream().toArray(String[]::new);

        for (String s1 : output)
        {
            System.out.println(s1);
        }
    }
}