package com.example.demo.string;
public class StringCompareToExample {

    /**
     * This class show String compareTo examples
     * @param args
     */
    public static void main(String[] args) {
        String str = "ABC";
        System.out.println(str.compareTo("DEF"));
        System.out.println(str.compareToIgnoreCase("abc"));
    }

}
