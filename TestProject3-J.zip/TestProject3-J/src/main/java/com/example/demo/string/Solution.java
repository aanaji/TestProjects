package com.example.demo.string;

import java.util.Arrays;
import java.util.StringJoiner;

class Solution
{
    public static void main(String[] args)
    {
        String input = "5F3Z-2e-9-w";

        // System.out.println(licenseKeyFormatting(input, 4));

        String abc = "dir\n\tsubdir1\n\t\tfile1.ext\n\t\tsubsubdir1\n\tsubdir2\n\t\tsubsubdir2\n\t\t\tfile2.ext";
        // System.out.println("dir\n\tsubdir1\n\t\tfile1.ext\n\t\tsubsubdir1\n\tsubdir2\n\t\tsubsubdir2\n\t\t\tfile2.ext");

        //System.out.println(recursivleySplit(abc, 0));
        
        String anotherString = "two-separate-tokens-this--is--just--one--token-another";
        
        
        
        System.out.println(Arrays.toString(anotherString.split("(?:[^\\-]|--)")));

        // System.out.println("dir/subdir2/subsubdir2/file2.ext".length());

    }

    public static int recursivleySplit(String input, int count)
    {
        if (input.startsWith("dir"))
        {
            count = 3;
            input = input.replaceAll("dir", "");
        }

        if (input.startsWith("\n") || input.startsWith("\t"))
        {
            String[] splitInput = input.startsWith("\n") ? input.split("\n") : input.split("\t");
            for (int i = 0; i < splitInput.length; i++)
            {
                if (!(splitInput[i].contains("\n") || splitInput[i].contains("\t")))
                {
                    if ((count + splitInput[i].length()) > count)
                    {
                        count = count + splitInput[i].length();
                    }
                }
                else
                {

                    count = recursivleySplit(splitInput[i], count);

                }
            }
        }
        else
        {
            if ((count + input.length()) > count)
            {
                count = count + input.length();
            }
            return count;
        }
        return count;
    }

    public static String licenseKeyFormatting(String S, int K)
    {

        S = S.replaceAll("-", "");
        S = S.toUpperCase();
        StringJoiner joiner = new StringJoiner("-");

        int start = 0;

        if (S.length() % K != 0)
        {

            joiner.add(S.substring(start, S.length() % K));
            start = S.length() % K;
        }
        for (; start < S.length(); start = start + K)
        {
            joiner.add(S.substring(start, start + K));
        }

        return joiner.toString();

    }
}