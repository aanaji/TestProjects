package com.example.demo.multithreading.oddeven;

public class OddEvenObject
{
    private int number;

    public synchronized void printEven() throws InterruptedException
    {

        while (number < 100)
        {
            while (number % 2 != 0)
            {
                wait();
            }

            System.out.println(Thread.currentThread().getName() + number);

            number++;

            notify();
        }
    }

    public synchronized void printOdd() throws InterruptedException
    {

        while (number < 100)
        {
            while (number % 2 == 0)
            {
                wait();
            }

            System.out.println(Thread.currentThread().getName() + number);

            number++;
            notify();
        }
    }
}
