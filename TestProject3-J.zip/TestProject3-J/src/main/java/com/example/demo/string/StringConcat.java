package com.example.demo.string;

public class StringConcat
{
    public static void main(String[] args)
    {
        String input = "Ananda";

        System.out.println(input.concat(" Anaji"));
    }
}
