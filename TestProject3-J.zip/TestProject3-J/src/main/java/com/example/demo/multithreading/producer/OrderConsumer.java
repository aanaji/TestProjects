package com.example.demo.multithreading.producer;

import java.util.concurrent.BlockingQueue;

public class OrderConsumer implements Runnable
{

    private BlockingQueue<Order> queue;

    public OrderConsumer(BlockingQueue<Order> queue)
    {
        super();
        this.queue = queue;
    }

    @Override
    public void run()
    {
        Order order;
        try
        {
            while ((order = queue.take()).getOrderId() < 999)
            {

                System.out.println(order.getOrderId());
            }
        }
        catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
