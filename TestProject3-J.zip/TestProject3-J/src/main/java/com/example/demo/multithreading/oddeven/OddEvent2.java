package com.example.demo.multithreading.oddeven;

public class OddEvent2
{

    public static void main(String[] args)
    {
        OddEvenObject oddEvenObject = new OddEvenObject();

        Thread oddThread = new Thread(() -> {
            try
            {
                oddEvenObject.printOdd();
            }
            catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        });
        oddThread.setName("Odd Thread : ");

        Thread evenThread = new Thread(() -> {
            try
            {
                oddEvenObject.printEven();
            }
            catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        });
        evenThread.setName("Even Thread : ");

        oddThread.start();
        evenThread.start();
    }
}
