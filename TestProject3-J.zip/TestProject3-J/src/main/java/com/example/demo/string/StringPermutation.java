package com.example.demo.string;

import java.util.StringJoiner;

public class StringPermutation
{

    public static void main(String[] args)
    {
        StringPermutation permutation = new StringPermutation();
        String input = "Ana";
        permutation.permute(input, 0, input.length() - 1);

        StringJoiner join = new StringJoiner(",", "[", "]");

        join.add("ANa").add("def").add("zzcxz");

        System.out.println(join.toString());
    }

    public void permute(String input, int left, int right)
    {

        if (left == right)
        {
            System.out.println(input);
            // return input;
        }

        for (int i = left; i <= right; i++)
        {
            input = swap(input, left, i);
            permute(input, left + 1, right);
            input = swap(input, left, i);
        }
    }

    public String swap(String input, int left, int right)
    {
        char[] inputArray = input.toCharArray();
        char temp = inputArray[left];
        inputArray[left] = inputArray[right];
        inputArray[right] = temp;
        return String.valueOf(inputArray);
    }
}
