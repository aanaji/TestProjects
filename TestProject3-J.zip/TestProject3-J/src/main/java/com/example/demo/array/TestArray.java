package com.example.demo.array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestArray
{
    public static void main(String[] args)
    {

        int[] testIntArray = new int[5];

        testIntArray[0] = 5;
        testIntArray[1] = 20;
        testIntArray[2] = 15;

        Arrays.sort(testIntArray);

        for (int a : testIntArray)
        {
            // System.out.println(a);
        }

        List<Integer> testList = new ArrayList<>();

        // testList.forEach(System.out::println);

        // new String

        int arr[] = { 1, 2, 3, -4, -1, 4 };

        Arrays.sort(arr);

        int updatedArray[] = new int[arr.length];

        int negativeNumber = 0;
        for (int i : arr)
        {
            if (i < 0)
            {
                negativeNumber++;
            }
        }

        int negativeIndex = 0;
        int positveIndex = negativeNumber;

        int currentIndex = 0;
        while (negativeIndex < negativeNumber && positveIndex < arr.length)
        {
            updatedArray[currentIndex++] = arr[negativeIndex++];
            updatedArray[currentIndex++] = arr[positveIndex++];
        }

        while (negativeIndex < negativeNumber)
        {
            updatedArray[currentIndex++] = arr[negativeIndex++];
        }

        while (positveIndex < arr.length)
        {
            updatedArray[currentIndex++] = arr[positveIndex++];
        }

        for (int a : updatedArray)
        {
            System.out.println(a);
        }
    }
}