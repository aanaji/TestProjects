package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestFinalMap implements Comparable<TestFinalMap>
{

    public static void main(String[] args)
    {

        final Map<String, String> testMap = new HashMap<>();

        testMap.put("Ananda", "A");
        testMap.put("Anaji", "AnajiV");
        testMap.put("Ananda", "AnandaV");

        testMap.forEach((key, value) -> System.out.println(value));

        List testList = new ArrayList();

        testList.add("Afd");

        testList.forEach(x -> System.out.println(x));

        // Collections.sort

    }

    @Override
    public int compareTo(TestFinalMap o)
    {
        // TODO Auto-generated method stub
        return 0;
    }
}