package com.example.demo.multithreading;

public class TestWaitTimeOut
{

    public static void main(String[] args)
    {

        TestWaitTimeOut testWaitTimeOut = new TestWaitTimeOut();
        Thread waitThread = new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                synchronized (testWaitTimeOut)
                {
                    try
                    {
                        System.out.println("wait thread 1");
                        testWaitTimeOut.wait(1000);
                        System.out.println("out of wait thread 1");

                    }
                    catch (InterruptedException e)
                    {
                    }
                    System.out.println("wait thread is executing");
                }
            }
        });

        Thread waitThread2 = new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                synchronized (testWaitTimeOut)
                {
                    try
                    {
                        System.out.println("wait thread 2");
                        Thread.sleep(10000);
                        System.out.println("out of wait thread 2");

                    }
                    catch (InterruptedException e)
                    {
                    }
                }
            }
        });

        waitThread.start();
        waitThread2.start();

    }
}
