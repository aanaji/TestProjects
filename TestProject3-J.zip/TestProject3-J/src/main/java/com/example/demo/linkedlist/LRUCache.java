package com.example.demo.linkedlist;

import java.util.LinkedHashMap;
import java.util.Map;

public class LRUCache
{

    Map<String, String> cache;

    int maxCapacity;

    public LRUCache(int maxCapacity)
    {
        super();
        this.cache = new LinkedHashMap<>(maxCapacity);
        this.maxCapacity = maxCapacity;
    }

    public String getValue(String key)
    {

        if (cache != null && cache.get(key) != null)
        {
            String value = cache.get(key);
            cache.remove(key);
            cache.put(key, value);
            return value;
        }

        return null;
    }

    public String add(String key, String value)
    {
        if (cache.size() >= maxCapacity)
        {
            String leastUsedKey = cache.keySet().iterator().next();
            cache.remove(leastUsedKey);
        }

        return cache.put(key, value);
    }
}
