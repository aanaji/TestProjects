package com.example.demo.multithreading.callable;

import java.util.concurrent.Callable;

public class FactorialTask implements Callable<Integer>
{
    int number;

    // standard constructors

    public Integer call() throws InterruptedException
    {
        int fact = 1;
        // ...
        Thread.sleep(1000);
        for (int count = number; count > 1; count--)
        {
            fact = fact * count;
        }

        return fact;
    }

    public FactorialTask(int number)
    {
        super();
        this.number = number;
    }
}