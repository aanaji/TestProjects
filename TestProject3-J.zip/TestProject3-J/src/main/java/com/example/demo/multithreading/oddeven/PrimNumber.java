package com.example.demo.multithreading.oddeven;

public class PrimNumber
{

    public static void main(String[] args)
    {
        int i = 0;
        int num = 0;
        String primeNumbers = "";
        for (i = 1; i <= 100; i++)
        {
            int counter = 0;
            for (num = i; num >= 1; num--)
            {

                // condition to check if the number is prime
                if (i % num == 0)
                {

                    // increment counter
                    counter = counter + 1;
                }
            }

            if (counter == 2)
            {
                System.out.println(i);
            }
        }
    }
}
