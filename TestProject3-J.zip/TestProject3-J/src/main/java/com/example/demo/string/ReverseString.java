package com.example.demo.string;

public class ReverseString
{

    public static void main(String[] args)
    {
        String input = "DBCBAD";
        char[] inputArray = input.toCharArray();

        for (int i = 0, j = input.length() - 1; i <= input.length() / 2 && i < j; i++, j--)
        {
            char temp = inputArray[i];
            inputArray[i] = inputArray[j];
            inputArray[j] = temp;
        }

        System.out.println(String.valueOf(inputArray));
    }
}
