package com.example.demo.array;

import java.util.HashSet;
import java.util.Set;

public class LongestSubSequence
{

    public static void main(String[] args)
    {
        int arr[] = { 1, 9, 10, 4, 20, 2, 3, 5 };

        Set<Integer> setInteger = new HashSet<>();

        int currentMax = 0;

        for (int i = 0; i < arr.length; i++)
        {
            setInteger.add(arr[i]);

        }

        for (Integer setValue : setInteger)
        {

            int j = 1;
            int count = 1;

            if (!setInteger.contains((setValue - j)))
            {
                /*
                 * while (setInteger.contains((setValue - j))) { count++; j++; } j = 1;
                 */

                while (setInteger.contains(setValue + j))
                {
                    count++;
                    j++;
                }

                if (currentMax < count)
                {
                    currentMax = count;
                }
            }

        }

        System.out.println(currentMax);
    }
}
