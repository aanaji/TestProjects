package com.example.demo.multithreading.callable;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.*;

public class InvokeAllExample
{
    public static void main(String[] args) throws InterruptedException, ExecutionException
    {
        ExecutorService executorService = Executors.newFixedThreadPool(5);

        Callable<String> task1 = () -> {
            Thread.sleep(2000);
            return "Result of Task1";
        };

        Callable<String> task2 = () -> {
            Thread.sleep(1000);
            return "Result of Task2";
        };

        Callable<String> task3 = () -> {
            Thread.sleep(5000);
            return "Result of Task3";
        };

        List<Callable<String>> taskList = Arrays.asList(task1, task2, task3);

        /*
         * Future<String> future1 = executorService.submit(task1); Future<String> future2 =
         * executorService.submit(task2); Future<String> future3 = executorService.submit(task3);
         * 
         * List<Future<String>> futures = Arrays.asList(future1, future2, future3);
         */

        List<Future<String>> futures = executorService.invokeAll(taskList);

        String result = executorService.invokeAny(Arrays.asList(task1, task2, task3));
        System.out.println(result);
        System.out.println("Test");
        for (Future<String> future : futures)
        {
            // The result is printed only after all the futures are complete. (i.e. after 5 seconds)
            System.out.println(future.get());
        }

        executorService.shutdown();
    }
}