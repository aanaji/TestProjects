package com.example.demo;

import java.util.ArrayList;
import java.util.List;

public class Heirarchy
{

    public static void main(String[] args)
    {
        BaseClass base = new ExtendedClass();

        List<String> testList = new ArrayList<>();
        testList.add("Ananda");
        // base.test();
        base.test2(testList);

        testList.forEach(System.out::println);

    }
}

class ExtendedClass extends BaseClass
{
    public static void test()
    {
        System.out.println("Child Class");
    }

    public void test2(List<String> childList)
    {
        childList = new ArrayList<>();
        System.out.println("Child Class Test2");
    }
}

class BaseClass
{
    public static void test()
    {
        System.out.println("Parent Class");
    }

    public void test2(List<String> childList)
    {
        System.out.println("Parent Class Test2");
    }
}