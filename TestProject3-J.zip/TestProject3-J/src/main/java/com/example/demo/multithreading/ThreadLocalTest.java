package com.example.demo.multithreading;

public class ThreadLocalTest
{

    public static void main(String[] args)
    {

        ThreadLocal<Object> obj = new ThreadLocal<>();
        obj.set(new Object());

        for (int i = 0; i < 10; i++)
        {
            Thread abc = new ThreadClass(obj);
            abc.start();
        }
    }
}

class Object
{
    int abc;

    public int getAbc()
    {
        return abc;
    }

    public void setAbc(int abc)
    {
        this.abc = abc;
    }

}

class ThreadClass extends Thread
{

    private ThreadLocal<Object> obj;

    public ThreadClass(ThreadLocal<Object> obj)
    {
        super();
        this.obj = obj;
    }

    @Override
    public void run()
    {
        obj.set(new Object());
        System.out.println(this.obj.get());
        // this.obj.get().setAbc(this.obj.get().getAbc() + 1);
    }
}