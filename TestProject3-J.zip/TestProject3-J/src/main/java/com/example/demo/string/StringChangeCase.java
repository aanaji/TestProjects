package com.example.demo.string;

public class StringChangeCase
{

    public static void main(String[] args)
    {
        String abc = "ABCdEf";

        char[] stringArray = abc.toCharArray();

        for (int i = 0; i < stringArray.length; i++)
        {
            if (Character.isUpperCase(stringArray[i]))
            {
                stringArray[i] = Character.toLowerCase(stringArray[i]);
            }
            else if (Character.isLowerCase(stringArray[i]))
            {
                stringArray[i] = Character.toUpperCase(stringArray[i]);
            }
        }

        System.out.println(String.valueOf(stringArray));
    }
}