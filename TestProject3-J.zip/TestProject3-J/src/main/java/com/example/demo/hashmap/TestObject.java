package com.example.demo.hashmap;

import java.io.Serializable;
import java.util.Date;

public class TestObject //implements Serializable
{

    private String firstName;

    private String lastName;

    private Date currentDate;

    private TestObjectTwo testObjectTwo;

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public Date getCurrentDate()
    {
        return currentDate;
    }

    public void setCurrentDate(Date currentDate)
    {
        this.currentDate = currentDate;
    }

    public TestObjectTwo getTestObjectTwo()
    {
        return testObjectTwo;
    }

    public void setTestObjectTwo(TestObjectTwo testObjectTwo)
    {
        this.testObjectTwo = testObjectTwo;
    }

    @Override
    public String toString()
    {
        return "TestObject [firstName=" + firstName + ", lastName=" + lastName + ", currentDate=" + currentDate
                + ", testObjectTwo=" + testObjectTwo + "]";
    }

}
