package com.example.demo.java8;

// Java code for Stream.min() method
// to get the minimum element of the
// Stream according to provided comparator.
import java.util.*;

class GFG
{

    // Driver code
    public static void main(String[] args)
    {

        // Creating a list of integers
        List<Integer> list = Arrays.asList(-9, -18, 0, 25, 4);

        // Using Stream.min() with reverse
        // comparator to get maximum element.
        Optional<Integer> var = list.stream().min(Comparator.reverseOrder());

        // list.stream().map

        // IF var is empty, then output will be Optional.empty
        // else value in var is printed.
        if (var.isPresent())
        {
            System.out.println(var.get());
        }
        else
        {
            System.out.println("NULL");
        }

    }
}
