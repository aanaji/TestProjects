package com.example.demo.array;

import java.util.Arrays;

public class RearrangeArray
{
    public static void main(String[] args)
    {
        int[] input = { 1, 2, 3, -4, -1, 4 };

        int start = 0;
        int end = input.length - 1;

        while (start < end)
        {
            while (input[start] < 0)
            {
                start++;
            }
            while (input[end] > 0)
            {
                end--;
            }

            if (start < end)
            {
                int temp = input[start];
                input[start] = input[end];
                input[end] = temp;
            }
        }

        System.out.println(Arrays.toString(input));
    }
}
