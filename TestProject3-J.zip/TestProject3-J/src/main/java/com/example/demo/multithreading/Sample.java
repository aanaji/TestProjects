package com.example.demo.multithreading;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Sample
{
    public static void main(String[] args) throws InterruptedException, ExecutionException
    {

        List<Callable<String>> callables = new ArrayList<>();

        ExecutorService executor = Executors.newFixedThreadPool(5);
        for (int i = 0; i < 10; i++)
        {
            Callable<String> a = new ABC();
            // a.
            callables.add(a);
        }

        System.out.println("Invoke Call Start ");
        // executor.invokeAll(callables);

        for (Callable<String> call : callables)
        {
            Future<String> output = executor.submit(call);
            // output.get();
        }

        System.out.println("Invoke Call End ");
        /*
         * for(Callable<String> cal : callables) { cal. }
         */

        executor.shutdown();
    }
}

class ABC implements Callable<String>
{

    @Override
    public String call() throws Exception
    {
        // TODO Auto-generated method stub
        Thread.sleep(1000);
        System.out.println(Thread.currentThread().getName());
        return "Ananda";
    }

}