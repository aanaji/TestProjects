package com.example.demo.linkedlist;

import java.util.Iterator;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

public class GoogleCache
{

    public static void main(String[] args)
    {
        CacheLoader<String, String> loader;
        loader = new CacheLoader<String, String>()
        {
            @Override
            public String load(String key)
            {
                return key.toUpperCase();
            }
        };
        LoadingCache<String, String> cache = CacheBuilder.newBuilder().maximumSize(3).build(loader);

        cache.getUnchecked("first");
        cache.getUnchecked("second");
        cache.getUnchecked("third");
        cache.getUnchecked("forth");

        System.out.println(cache.toString());

        // Iterator<String> cacheIterator = cache.
        // assertEquals(3, cache.size());
        // assertNull(cache.getIfPresent("first"));
        // assertEquals("FORTH", cache.getIfPresent("forth"));
    }
}
