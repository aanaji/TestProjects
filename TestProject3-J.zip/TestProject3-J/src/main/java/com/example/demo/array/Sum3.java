package com.example.demo.array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Sum3
{

    public static void main(String[] args)
    {
        int[] nums = new int[] { -1, 0, 1, 2, -1, -4 };
        List<List<Integer>> output = new ArrayList<>();

        Arrays.sort(nums);

        for (int i = 0; i < nums.length; i++)
        {
            for (int j = i + 1; j < nums.length; j++)
            {
                for (int k = j + 1; k < nums.length; k++)
                {
                    if (nums[i] + nums[j] + nums[k] == 0)
                    {
                        List<Integer> result = new ArrayList<>();
                        result.add(nums[i]);
                        result.add(nums[j]);
                        result.add(nums[k]);
                        if (!output.contains(result))
                        {
                            output.add(result);
                        }
                        // output.add(nums[i] + "," + nums[j] + "," + nums[k]);
                    }
                    else if (nums[i] + nums[j] + nums[k] > 0)
                    {
                        break;
                    }
                }
            }
        }

        for (List<Integer> ints : output)
        {
            System.out.println(ints.toString());
        }

    }

    public List<List<Integer>> threeSum(int[] nums)
    {

        List<List<Integer>> output = new ArrayList<>();
        Arrays.sort(nums);

        for (int i = 0; i < nums.length; i++)
        {
            for (int j = i + 1; j < nums.length; j++)
            {
                for (int k = j + 1; k < nums.length; k++)
                {
                    if (nums[i] + nums[j] + nums[k] == 0)
                    {
                        List<Integer> result = new ArrayList<>();
                        result.add(nums[i]);
                        result.add(nums[j]);
                        result.add(nums[k]);
                        if (!output.contains(result))
                        {
                            output.add(result);
                        }
                        // output.add(nums[i] + "," + nums[j] + "," + nums[k]);
                    }
                    else if (nums[i] + nums[j] + nums[k] > 0)
                    {
                        break;
                    }
                }
            }
        }
        return output;

    }
}
