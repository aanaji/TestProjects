package com.example.demo.multithreading;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorServiceTest
{

    public static void main(String[] args) throws InterruptedException, ExecutionException
    {

        Callable<String> test1 = new Callable<String>()
        {

            @Override
            public String call()
            {
                try
                {
                    Thread.sleep(6000);
                }
                catch (InterruptedException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                System.out.println("In Call method");
                return null;
            }
        };

        ExecutorService executorService = Executors.newFixedThreadPool(1);

        List<Callable<String>> runList = new ArrayList<>();
        runList.add(test1);
        // executorService.execute(test1);
         executorService.submit(test1);
        executorService.invokeAny(runList);

        System.out.println("Executed");
        executorService.shutdown();

    }

}
