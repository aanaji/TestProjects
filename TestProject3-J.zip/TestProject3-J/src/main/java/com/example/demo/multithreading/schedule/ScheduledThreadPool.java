
package com.example.demo.multithreading.schedule;

import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ScheduledThreadPool
{

    public static void main(String[] args) throws InterruptedException
    {
        ScheduledExecutorService scheduledThreadPool = Executors.newScheduledThreadPool(5);
        
       ExecutorService executorService = Executors.newFixedThreadPool(5);
       
       executorService.submit(new Runnable()
    {
        
        @Override
        public void run()
        {
            // TODO Auto-generated method stub
            
        }
    });

        // schedule to run after sometime
        System.out.println("Current Time = " + new Date());
        for (int i = 0; i < 3; i++)
        {
            Thread.sleep(1000);
            WorkerThread worker = new WorkerThread("do heavy processing");
            scheduledThreadPool.schedule(worker, 10, TimeUnit.SECONDS);
            //scheduledThreadPool.s
        }

        // add some delay to let some threads spawn by scheduler
        Thread.sleep(30000);

        scheduledThreadPool.shutdown();
        while (!scheduledThreadPool.isTerminated())
        {
            // wait for all tasks to finish
        }
        System.out.println("Finished all threads");
    }

}
