package com.example.demo.array;

import java.util.ArrayList;
import java.util.Arrays;

public class JaggedArray
{
    public static void main(String[] args)
    {
        int arr_name[][] = { { 10, 20, 30, 40 }, { 50, 60, 70, 80, 90, 100 }, { 110, 120 } };

        int[] firstRow = arr_name[1];

        // Arrays.co

        // firstRow = Arrays.copyOf(firstRow, 10);
        /*
         * firstRow = new int[10]; firstRow[0] = 10;
         */

        System.out.println(firstRow.length);

        Object[] allDataType = new Object[] { 1234, "Test", new ArrayList<>() };

        System.out.println(allDataType[1]);

    }

    public static void name()
    {
        main(null);
    }
}
