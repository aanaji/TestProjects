
package com.example.demo.string;

public class StringTest
{

    public static void main(String[] args)
    {
        String s1 = new String("pankaj");
        String s2 = new String("PANKAJ");
        System.out.println(s1 = s2);
    }

}
