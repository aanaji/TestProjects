package com.example.demo.multithreading.producer;

import java.util.concurrent.BlockingQueue;

public class OrderProducer implements Runnable
{

    private BlockingQueue<Order> queue;

    public OrderProducer(BlockingQueue<Order> queue)
    {
        super();
        this.queue = queue;
    }

    @Override
    public void run()
    {
        for (int i = 0; i < 1000; i++)
        {
            /*
             * // boolean notify = false; if (queue.isEmpty()) { notify = true; }
             */
            try
            {
                Order order = new Order();
                order.setOrderId(i);
                queue.put(order);
                /*
                 * if (notify) { notify(); }
                 */
            }
            catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        // Thread.ter
    }

}
