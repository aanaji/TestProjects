package com.example.demo.linkedlist;

public class DisplayLinkedList
{

    public static void main(String[] args)
    {

        Node chilNodeThree = new Node(3, null);

        Node chidNodeOne = new Node(2, chilNodeThree);

        Node head = new Node(1, chidNodeOne);

        /*
         * while (head != null) { System.out.println(head.toString()); head = head.getNode(); }
         */

        do
        {
            System.out.println(head);
            head = head.getNode();
        }
        while (head != null);

    }

}

class Node
{

    private int number;

    private Node node;

    public Node(int number, Node node)
    {
        super();
        this.number = number;
        this.node = node;
    }

    public int getNumber()
    {
        return number;
    }

    public void setNumber(int number)
    {
        this.number = number;
    }

    public Node getNode()
    {
        return node;
    }

    public void setNode(Node node)
    {
        this.node = node;
    }

}