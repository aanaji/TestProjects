package com.example.demo.multithreading.callable;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Snippet
{
    // @Test
    public static void main(String[] args) throws InterruptedException, ExecutionException
    {

        ExecutorService executorService = Executors.newFixedThreadPool(5);

        List<FactorialTask> futureTaskList = new ArrayList<>();
        for (int i = 1; i < 10; i++)
        {
            FactorialTask task = new FactorialTask(i);
            futureTaskList.add(task);
        }

        List<Future<Integer>> futureList = executorService.invokeAll(futureTaskList);

        for (Future<Integer> future : futureList)
        {
            System.out.println(future.get());
        }

    }

    // assertEquals(120, future.get().intValue());

}
