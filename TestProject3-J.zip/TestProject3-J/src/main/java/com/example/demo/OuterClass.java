package com.example.demo;

class OuterClass
{
    public class InnerClass
    {

        public void test()
        {

        }
    }

    public static class StaticNestedClass
    {
    }
}