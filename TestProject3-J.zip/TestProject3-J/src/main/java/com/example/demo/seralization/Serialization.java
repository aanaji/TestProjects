package com.example.demo.seralization;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Date;

import com.example.demo.hashmap.TestObject;
import com.example.demo.hashmap.TestObjectTwo;

public class Serialization
{

    public static void main(String[] args) throws IOException
    {
        TestObject one = new TestObject();
        one.setCurrentDate(new Date());
        one.setFirstName("Ana");
        one.setLastName("Anaji");

        TestObjectTwo testObjectTwo = new TestObjectTwo();
        one.setTestObjectTwo(testObjectTwo);

        FileOutputStream out = new FileOutputStream("/Users/aanaji/Documents/text.txt");

        ObjectOutputStream objectOutputStream = new ObjectOutputStream(out);

        objectOutputStream.writeObject(one);

        objectOutputStream.close();

        out.close();
    }
}
