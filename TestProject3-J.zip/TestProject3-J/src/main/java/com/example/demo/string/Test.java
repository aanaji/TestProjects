
package com.example.demo.string;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.util.StringUtils;

public class Test
{

    public void foo(String s)
    {
        System.out.println("String");

    }

    public void foo(StringBuffer sb)
    {
        System.out.println("StringBuffer");
    }

    public static void main(String[] args)
    {
        // new Test().foo(new StringBuffer());

        String s = "Ananda";

        char[] charArray = s.toCharArray();

        char[] updateCharArray = new char[s.length()];
        int i = 0;
        for (char ch : charArray)
        {
            if (Character.isLowerCase(ch))
            {
                updateCharArray[i] = Character.toUpperCase(ch);
            }
            else if (Character.isUpperCase(ch))
            {
                updateCharArray[i] = Character.toLowerCase(ch);
            }
            else
            {
                updateCharArray[i] = ch;
            }
            i++;
        }

        Arrays.sort(updateCharArray);

        // StringUtils.ca

        System.out.println(new String(updateCharArray));

        String name1 = "Java";
        /*
         * Does not create string object in string pool as this "Java" literal already present there
         */
        String name2 = "Java";
        /*
         * name3 and name1 are pointing to same string literal "Java"
         */
        String name3 = name1;

        /*
         * creates new object in heap and does not create new object in string pool as it already present there
         */
        String name4 = new String("Java");

        // name4 = name4.intern();
        /*
         * creates new object in heap and does not create new object in string pool as it already present there
         */
        String name5 = new String("Java");

        System.out.println(name1 == name2);// prints true
        System.out.println(name1 == name3);// prints true
        System.out.println(name2 == name3);// prints true

        System.out.println(name1 == name4);// prints false
        System.out.println(name1 == name5);// prints false
        System.out.println(name4 == name5);// prints false

        String test = "Ananda Anaji";

        // Arrays.tos

        System.out.println(test.substring(5));

        String s1 = new String("pankaj");
        String s2 = new String("PANKAJ");
        System.out.println(s1 = s2);

        int[] testIntArray = new int[] { 1, 2, 3, 4 };
        
        System.out.println(Arrays.toString(testIntArray));

    }

}
