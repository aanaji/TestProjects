package com.example.demo.multithreading;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Factorial
{

    public static void main(String[] args)
    {
        Queue<Integer> input = new ArrayBlockingQueue<>(100);
        input.add(1);
        input.add(2);
        input.add(3);

        ExecutorService executorService = Executors.newFixedThreadPool(10);

        System.out.println(Runtime.getRuntime().availableProcessors());

        Runnable factorial = new Runnable()
        {

            @Override
            public void run()
            {
                while (!input.isEmpty())
                {
                    try
                    {
                        // System.out.println(input.poll());
                        Thread.sleep(10);
                    }
                    catch (InterruptedException e)
                    {

                    }
                }

                // break;
            }
        };

        executorService.execute(factorial);

        executorService.shutdown();

        List<String> arrayList = new ArrayList<>();

        // arrayList.stream().parallel().
    }

}
