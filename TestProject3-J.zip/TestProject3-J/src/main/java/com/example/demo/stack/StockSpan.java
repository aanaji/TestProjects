package com.example.demo.stack;
// Java linear time solution for stock span problem

import java.util.Stack;
import java.util.Arrays;

public class StockSpan
{
    // A stack based efficient method to calculate
    // stock span values
    static void calculateSpan(int price[], int n, int S[])
    {
        Stack<Integer> storeIndexValues = new Stack<>();

        storeIndexValues.add(0);

        S[0] = 1;

        for (int i = 1; i < price.length; i++)
        {

            while (!storeIndexValues.isEmpty() && price[storeIndexValues.peek()] <= price[i])
            {
                storeIndexValues.pop();
            }

            S[i] = storeIndexValues.empty() ? i + 1 : i - storeIndexValues.peek();

            storeIndexValues.add(i);
        }
    }

    // A utility function to print elements of array
    static void printArray(int arr[])
    {
        System.out.print(Arrays.toString(arr));
    }

    // Driver method
    public static void main(String[] args)
    {
        int price[] = { 10, 4, 5, 90, 120, 80 };
        int n = price.length;
        int S[] = new int[n];

        // Fill the span values in array S[]
        calculateSpan(price, n, S);

        // print the calculated span values
        printArray(S);
    }
}
// This code is contributed by Sumit Ghosh
