package com.example.demo.array;

import java.util.Arrays;

public class RearrangeAlternative
{

    public static void main(String[] args)
    {

        int[] input = { -5, -2, 5, 2, 4, 7, 1, 8, 0, -8 };

        Arrays.sort(input);

        System.out.println(Arrays.toString(input));

        int positiveIndex = 0;
        for (positiveIndex = 0; positiveIndex < input.length; positiveIndex++)
        {
            if (input[positiveIndex] > 0)
            {
                break;
            }
        }

        int start = 0;
        while (input[start] < 0)
        {
            start++;
            if (input[start] < 0)
            {
                int temp = input[start];
                input[start] = input[positiveIndex];
                input[positiveIndex] = temp;
                positiveIndex++;
                start++;
            }
        }

        System.out.println(Arrays.toString(input));

    }
}
