package com.example.demo.multithreading.producer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProducerConsumer
{

    int number = 0;

    int maxValue = 20;

    public void printEvenNumber()
    {
        while (number < maxValue)
        {
            synchronized (this)
            {
                while (number % 2 == 1)
                {
                    try
                    {
                        wait();
                    }
                    catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
                System.out.println("Print even number : " + number);
                number++;
                notify();
            }
        }
    }

    public void printOddNumber()
    {
        while (number < maxValue)
        {
            synchronized (this)
            {
                while (number % 2 == 0)
                {
                    try
                    {
                        wait();
                    }
                    catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
                System.out.println("Print odd number : " + number);
                number++;
                notify();
            }
        }
    }

    public static void main(String[] args)
    {

        ProducerConsumer producerConsumer = new ProducerConsumer();
        Thread t1 = new Thread(() -> {
            producerConsumer.printEvenNumber();
        });

        Thread t2 = new Thread(() -> {
            producerConsumer.printOddNumber();
        });

        // Thread.currentThread().

        System.out.println(Runtime.getRuntime().availableProcessors());

        t1.start();
        t2.start();

        Map<String, String> testMap = new HashMap<>();

        // testMap.forEach(action);

        List<String> testList = new ArrayList<>();

        // ProducerConsumer pr = ProducerConsumer::new;

        // testList.stream().forEach(action);
    }
}
