package com.example.demo.matrix;

import java.io.*;
import java.util.*;

class BFSElement
{
    int row, column;

    BFSElement(int row, int column)
    {
        this.row = row;
        this.column = column;
    }
}

class GFG
{
    static int R = 4, C = 4;

    BFSElement b;

    static boolean findPath(int M[][])
    {

        // 1) Create BFS queue q
        Queue<BFSElement> q = new LinkedList<>();

        // 2)scan the matrix
        for (int row = 0; row < R; ++row)
        {
            for (int column = 0; column < C; ++column)
            {

                // if there exists a cell in the matrix such
                // that its value is 1 then push it to q
                if (M[row][column] == 1)
                {
                    q.add(new BFSElement(row, column));
                    break;
                }
            }

        }

        // 3) run BFS algorithm with q.
        while (q.size() != 0)
        {
            BFSElement x = q.peek();
            q.remove();
            int row = x.row;
            int column = x.column;

            // skipping cells which are not valid.
            // if outside the matrix bounds
            if (row < 0 || row >= R || column < 0 || column >= C)
                continue;

            // if they are walls (value is 0).
            if (M[row][column] == 0)
                continue;

            // 3.1) if in the BFS algorithm process there was a
            // vertex x=(row,column) such that M[row][column] is 2 stop and
            // return true
            if (M[row][column] == 2)
                return true;

            // marking as wall upon successful visitation
            M[row][column] = 0;

            // pushing to queue u=(row,column+1),u=(row,column-1)
            // u=(row+1,column),u=(row-1,column)
            
            //1       2          3
            //0,0     0,1        0,2
            //4       5           6
            //1,0     1,1         1,2
            //7       8           9
            //2,0     2,1         2,2

            for (int k = -1; k <= 1; k += 2)
            {
                q.add(new BFSElement(row + k, column));
                q.add(new BFSElement(row, column + k));
            }
        }

        // BFS algorithm terminated without returning true
        // then there was no element M[row][column] which is 2, then
        // return false
        return false;

    }

    // Main Driver code
    public static void main(String[] args)
    {
        int M[][] = { { 0, 3, 0, 1 }, { 3, 0, 3, 3 }, { 2, 3, 3, 3 }, { 0, 3, 3, 3 } };

        if (findPath(M) == true)
            System.out.println("Yes");
        else
            System.out.println("No");
    }
}

// This code is contributed by avanitrachhadiya2155
