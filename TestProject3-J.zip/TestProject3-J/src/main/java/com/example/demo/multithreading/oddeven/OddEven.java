package com.example.demo.multithreading.oddeven;

public class OddEven
{

    public static void main(String[] args)
    {

        Obj obj = new Obj();

        Runnable odd = new Runnable()
        {

            @Override
            public void run()
            {
                int i = 1;
                try
                {
                    while (!obj.isOdd)
                    {
                        wait();
                    }
                    System.out.println("Odd : " + i);
                    i = i + 2;
                    obj.isOdd = false;
                    notifyAll();
                }
                catch (Exception e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        };

        Runnable even = new Runnable()
        {

            @Override
            public void run()
            {
                int i = 0;
                try
                {
                    while (obj.isOdd)
                    {
                        wait();
                    }
                    System.out.println("Odd : " + i);
                    i = i + 2;
                    obj.isOdd = false;
                    notifyAll();
                }
                catch (Exception e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        };

        Thread evenThread = new Thread(even);
        Thread oddThread = new Thread(odd);

        evenThread.start();
        oddThread.start();

    }
}

class Obj
{

    volatile boolean isOdd;

    public boolean isOdd()
    {
        return isOdd;
    }

    public void setOdd(boolean isOdd)
    {
        this.isOdd = isOdd;
    }

}
