package com.example.demo.java8;

import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.IntStream;

public class StreamTest
{

    public static void main(String[] args)
    {

        IntSummaryStatistics intS = IntStream.range(0, 1000).parallel().summaryStatistics();

        System.out.println(intS.getMax());

        printNameAndActivities();
    }

    static Consumer<String> c2 = p -> System.out.print(p.toLowerCase());

    static Consumer<String> c3 = p -> System.out.println(p.concat("Test"));

    static Function<String, String> c4 = p -> p.toLowerCase();

    public static void printNameAndActivities()
    {
        System.out.println("printNameAndActivities : ");
        List<String> personList = Arrays.asList("ABC", "DEF");
        personList.forEach(c2.andThen(c3));

        personList.forEach(c2);

        // personList.stream().

    }

}
