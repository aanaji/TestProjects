package com.example.demo.arraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.util.StringUtils;

public class Test
{
    public static void main(String[] args)
    {
        List<String> inputList = new ArrayList<>();

        inputList.add("Ananda");
        inputList.add("T");
        inputList.add("Anaji");
        inputList.add(1, "insert");

        List<String> inputSubList = inputList.subList(1, 3);

        inputSubList = Collections.unmodifiableList(inputSubList);

        inputSubList.add("SubList");
        // inputList.add

        for (String data : inputList)
        {
            if (data.equalsIgnoreCase("T"))
            {
                // inputList.add("Test");
            }
        }

        Iterator<String> iterator = inputList.iterator();

        /*
         * while (iterator.hasNext()) { String data = iterator.next(); if (data.equalsIgnoreCase("T")) {
         * inputList.add("Test"); } }
         */

        System.out.println(StringUtils.collectionToCommaDelimitedString(inputList));

        System.out.println(inputSubList.toString());

        ArrayList<String> gfg = new ArrayList<String>()
        {
            {
                add("Geeks");
                add("for");
                add("Geeks");
            }
        };

        List concurrentList = new CopyOnWriteArrayList<>();

        // concurrentList.su
    }
}
