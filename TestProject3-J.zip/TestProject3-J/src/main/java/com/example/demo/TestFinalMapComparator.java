package com.example.demo;

import java.util.Comparator;

public class TestFinalMapComparator implements Comparator<TestFinalMap>
{

    @Override
    public int compare(TestFinalMap o1, TestFinalMap o2)
    {
        // TODO Auto-generated method stub
        return 0;
    }

}
