package com.example.demo.multithreading.producer;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Client
{

    public static void main(String[] args) throws InterruptedException
    {
        BlockingQueue<Order> queue = new ArrayBlockingQueue<>(10);

        Thread consumer = new Thread(new OrderConsumer(queue));

        Thread producer = new Thread(new OrderProducer(queue));

        consumer.start();

        producer.start();

        consumer.join();
        producer.join();
    }

}
