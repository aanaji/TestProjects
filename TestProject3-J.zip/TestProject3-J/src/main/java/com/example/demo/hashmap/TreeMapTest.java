package com.example.demo.hashmap;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class TreeMapTest
{

    public static void main(String[] args)
    {

        Map<Integer, TestObject> treeMap = new TreeMap<>();
        
        treeMap.put(null, null);

        TestObject one = new TestObject();
        one.setCurrentDate(new Date());
        one.setFirstName("Ana");
        one.setLastName("Anaji");

        treeMap.put(3, one);

        TestObject two = new TestObject();
        two.setCurrentDate(new Date());
        two.setFirstName("Thir");
        two.setLastName("Anaji");

        treeMap.put(4, two);

        Iterator<TestObject> treeIterator = treeMap.values().iterator();

        treeMap.forEach((a, b) -> System.out.println(a));

        /*
         * while (treeIterator.hasNext()) { // System.out.println(treeIterator.next().getFirstName()); }
         */

        Set<String> se = ConcurrentHashMap.newKeySet();

        se.add("Test");
        se.add("Ana");

        se.forEach(System.out::println);
    }
}
