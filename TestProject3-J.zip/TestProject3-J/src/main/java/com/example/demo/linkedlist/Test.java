package com.example.demo.linkedlist;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Test
{

    public static void main(String[] args)
    {
        Map<String, String> inputMap = new LinkedHashMap<>();

        inputMap.put(null, null);
        inputMap.put(null, null);

        // inputMap

        List<String> stringList = new ArrayList<>();

        stringList.add("Ananda");
        stringList.add("T");
        stringList.add("Anaji");
        stringList.add("Thirakappa");

        for (String str : stringList)
        {

            int h;
            System.out.println(h = (str == null) ? 0 : (h = str.hashCode()) ^ (h >>> 16));

            System.out.println((16 - 1) & h);
        }

        /*
         * List<RotateLinkedList> listCheck = new ArrayList<>();
         * 
         * listCheck.add(new RotateLinkedList());
         * 
         * System.out.println(listCheck.get(0).hashCode());
         */
        
        System.out.println(32 << 1);

    }
}
