package com.example.demo.hashmap;

import java.io.Serializable;

public class TestObjectTwo implements Serializable
{

    private String testObjectName;

    public String getTestObjectName()
    {
        return testObjectName;
    }

    public void setTestObjectName(String testObjectName)
    {
        this.testObjectName = testObjectName;
    }

}
