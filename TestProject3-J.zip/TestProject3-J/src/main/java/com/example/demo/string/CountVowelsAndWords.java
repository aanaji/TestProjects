package com.example.demo.string;

public class CountVowelsAndWords
{

    public static void main(String[] args)
    {
        String input = "adhvsddaksjdnqwygeqiwe";

        input = input.toLowerCase();
        int vowelCout = 0;

        for (int i = 0; i < input.length(); i++)
        {
            if (input.charAt(i) == 'a' || input.charAt(i) == 'e' || input.charAt(i) == 'i' || input.charAt(i) == 'o'
                    || input.charAt(i) == 'u')
            {
                vowelCout++;
            }
            
           // Character.is

            

            // String vowels = "aeiouAEIOU";

            // Character.is
            /*
             * if(vowels.contains(input.charAt(i))) {
             * 
             * }
             */

        }
        
        System.out.println(vowelCout);
        System.out.println(input.length() - vowelCout);
    }
}
