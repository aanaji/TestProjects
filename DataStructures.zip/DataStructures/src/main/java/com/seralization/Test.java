package com.seralization;

class Base {
	public void show() {
		System.out.println("Base class show() method");
	}

	public static void test() {
		System.out.println("Base class test() method");
	}
}

class Derived extends Base {
	public void show() {
		System.out.println("Derived class show() method");
	}

	// This is not an overridden method, this will be considered as new method in
	// Derived class
	// @Override
	public static void test() {
		System.out.println("Derived class test() method");
	}
}

public class Test {
	public static void main(String[] args) {
		Base ref = new Derived();
		// It will call the Base class's test() because it had static binding
		ref.test();
		// Calling the overridden method show()
		ref.show();
	}
}

class MainClass {

	static class MainInnerClass {
		public static void testmethod() {

		}
	}
}