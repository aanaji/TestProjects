package com.seralization;

public class InterfaceClass {
	public static void main(String[] args) {
		ProgrammerInterview p = new ProgrammerInterview() {
			public void read() {
				System.out.println("interface ProgrammerInterview class implementer");
			}

			@Override
			public void read1() {
				System.out.println("interface ProgrammerInterview class implementer1");

			}
		};

		p.read();
		p.read1();
	}
}

interface ProgrammerInterview {
	public void read();

	public void read1();
}