package com.seralization;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.seralization.Animal.Testing;

class Animal {
	public Animal() {
		System.out.println("Animal Constructor");
	}

	static void test() {

	}

	static class Testing {

	}
}

class Dog extends Animal {
	public Dog() {
		// super(null);
		System.out.println("Dog Constructor");
	}
}

class Labrador extends Dog {
	public Labrador() {
		System.out.println("Labrador Constructor");
	}
}

public class ConstructorExamples {
	public static void main(String[] args) {
		Labrador labrador = new Labrador();
		Animal.test();

		Animal.Testing testing = new Testing();

		for (int i = 0, j = 0; i < 10; i++, j--) {
			System.out.println(j);
		}

		int[] numbers1 = { 1, 2, 3 };
		int[] numbers2 = { 2, 1, 3 };

		System.out.println(Arrays.equals(numbers1, numbers2));

		System.out.println(OrderStatus.OPEN.getValue());

		System.gc();

		TestInitializer testInitializer = new TestInitializer();

		List<Person> personList = new ArrayList<>();

		// Arrays.sort
	}
}

class privateClass {

}

enum OrderStatus {
	OPEN("Open"), CLOSED("Closed");

	private String value;

	private OrderStatus(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}

class TestInitializer {

	static {
		System.out.println("Static");
	}
	{
		System.out.println("Instance");
	}
}