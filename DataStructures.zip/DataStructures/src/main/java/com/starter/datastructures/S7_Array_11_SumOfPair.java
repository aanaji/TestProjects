package com.starter.datastructures;

public class S7_Array_11_SumOfPair
{

    public static void main(String[] args)
    {
        int[] a = { 6, 3, 8, 10, 16, 7, 5, 2, 9, 14 };
        int key=10;
        
        for(int i=0; i<a.length-1; i++)
        {
            for(int j=i+1; j<a.length; j++)
            {
                if(a[i] + a[j] == key)
                {
                    System.out.println(a[i] + " and " + a[j] + " equals key : " + key);
                }
            }
        }
        
        // using hashing
        int[] h = new int[15];
        for (int i = 0; i < a.length; i++)
        {
            if (key - a[i] >= 0)
            {
                if (h[key - a[i]] != 0)
                    System.out.println(a[i] + "+" + (key - a[i] + "=" + key));

                h[a[i]]++;
            }
        }
    }

}
