package com.starter.datastructures;

public class S7_Array_8_Set
{

    public static void main(String[] args)
    {
         union();
        System.out.println();
         sortedUnion();

        System.out.println();
         intersection();
        System.out.println();

        difference();

        setMemberShip();
    }

    private static void setMemberShip() // linear search or binary search
    {
    }

    private static void difference() // A-B
    {
        int[] a = { 3, 4, 5, 6, 10 };
        int[] b = { 2, 4, 5, 7, 12 };
        int[] c = new int[10];

        int i = 0, j = 0, k = 0;
        while (i < a.length && j < b.length)
        {
            if (a[i] < b[j])
                c[k++] = a[i++];

            else if (b[j] < a[i])
                j++;

            else    // do not copy when both are equal, skip - increment only
            {
                i++;
                j++;
            }
        }

        for (int l = 0; l < k; l++)
            System.out.print("\t" + c[l]);
    }

    private static void intersection()
    {
        int[] a = { 3, 4, 5, 6, 10 };
        int[] b = { 2, 4, 5, 7, 12 };
        int[] c = new int[10];

        int i = 0, j = 0, k = 0;
        while (i < a.length && j < b.length)
        {
            if (a[i] < b[j])
                i++;

            else if (b[j] < a[i])
                j++;

            else if(a[i] == b[j])                       // for equal values, copy once, increment both
            {
                c[k++] = a[i++];
                j++;
            }
        }

        for (int l = 0; l < k; l++)
            System.out.print("\t" + c[l]);
    }

    private static void sortedUnion()
    {
        int[] a = { 3, 4, 5, 6, 10 };
        int[] b = { 2, 4, 5, 7, 12 };
        int[] c = new int[20];

        int i = 0, j = 0, k = 0;
        while (i < a.length && j < b.length)
        {
            if (a[i] < b[j])
                c[k++] = a[i++];

            else if (b[j] < a[i])
                c[k++] = b[j++];

            else // for equal values, copy once, increment both
            {
                c[k++] = a[i++];
                j++;
            }
        }

        for (; i < a.length; i++) // considering there are no duplicates
            c[k++] = a[i++];

        for (; j < b.length; j++)
            c[k++] = b[j++];

        for (int l = 0; l < k; l++)
            System.out.print("\t" + c[l]);
    }

    private static void union()
    {
        int[] a = { 3, 5, 10, 4, 6 };
        int[] b = { 12, 4, 7, 2, 5 };
        int[] c = new int[20];

        int i = 0;
        int len = 0;
        for (; i < a.length; i++)
        {
            c[i] = a[i];
            len++;
        }

        for (int j = 0; j < b.length; j++)
        {
            if (isNotPresent(b[j], c, len))
            {
                c[i++] = b[j];
                len++;
            }
        }

        for (int j = 0; j < len; j++)
            System.out.print("\t" + c[j]);
    }

    private static boolean isNotPresent(int b, int[] c, int len)
    {
        for (int i = 0; i < len; i++)
        {
            if (b == c[i])
                return false;
        }
        return true;
    }

}
