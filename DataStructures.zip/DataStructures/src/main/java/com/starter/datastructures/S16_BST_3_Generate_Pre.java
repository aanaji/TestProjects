package com.starter.datastructures;

import java.util.Stack;

public class S16_BST_3_Generate_Pre
{
    TreeNode root;

    static class TreeNode
    {
        TreeNode left;
        int data; 
        TreeNode right;
        
        TreeNode()              
        {
            
        }

        TreeNode(int data)
        {
            this.data = data;
            left = null;
            right = null;
        }
    }

    public static void main(String[] args)
    {
        S16_BST_3_Generate_Pre tree = new S16_BST_3_Generate_Pre();
        
        int pre[] = {30, 20, 10, 15, 25, 40, 50, 45};
        int size = 8;
        
        tree.createFromPre(pre, size - 1);                  // FYI
        
        System.out.println();
        tree.inOrder(tree.root);
    }
    
    private void createFromPre(int[] pre, int n)
    {
        Stack<TreeNode> stk = new Stack<>();
        TreeNode newNode, currentNode;
        
        int i = 0;
        
        root = new TreeNode();
        root.data = pre[i++];
        root.left = root.right = null;
        
        currentNode = root;
        
        while (i < n)
        {
            if (pre[i] < currentNode.data)                    // FYI
            {
            	newNode = new TreeNode();
            	newNode.data = pre[i++];
            	newNode.left = newNode.right = null;
                
            	currentNode.left = newNode;
                stk.push(currentNode);
                currentNode = newNode;
            }
            else
            {
                if (pre[i] > currentNode.data && pre[i] < (stk.isEmpty() ? 32767 : stk.peek().data))          // FYI
                {
                	newNode = new TreeNode();
                	newNode.data = pre[i++];
                	newNode.left = newNode.right = null;
                    
                	currentNode.right = newNode;
                	currentNode = newNode;
                }
                else
                {
                	currentNode = stk.pop();              // FYI
                }
            }
        }
    }

    void inOrder(TreeNode node)
    {
        if (node == null)
            return;

        inOrder(node.left);
        System.out.print(node.data + " ");
        inOrder(node.right);
    }

}