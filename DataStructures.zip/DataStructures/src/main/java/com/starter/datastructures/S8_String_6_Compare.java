package com.starter.datastructures;

public class S8_String_6_Compare
{

    public static void main(String[] args)
    {
        char[] a = "Painter".toLowerCase().toCharArray();
        char[] b = "painting".toCharArray();

        for (int i = 0, j = 0; i < a.length && j < b.length; i++, j++)
        {
            if (a[i] != b[j])
            {
                System.out.println("Not Equal");
                return;
            }
        }
        System.out.println("Equal");
    }

}
