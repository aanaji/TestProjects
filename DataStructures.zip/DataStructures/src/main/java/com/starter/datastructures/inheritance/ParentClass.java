package com.starter.datastructures.inheritance;

public class ParentClass {

	public Order populateOrder() {
		Order order = new Order();

		order.setOrderId("1234");
		order.setCustomerName("Ananda");

		return order;
	}
}
