package com.starter.datastructures;

public class S13_Stack_1_Array
{
    int top = -1;

    int size = 50;

    int[] stack = new int[size];

    public static void main(String[] args)
    {
        S13_Stack_1_Array st = new S13_Stack_1_Array();

        st.push(5);
        st.push(17);
        st.push(8);

        st.peek();
        st.peek(2);
        st.display();

        st.pop();

        st.push(22);

        st.display();
    }

    private void display()
    {
        System.out.println();

        for (int i = top; i >= 0; i--)                              // FYI
            System.out.println(stack[i] + "\t");
    }

    private void pop()
    {
        if (top == -1)
        {
            System.out.println("Stack underflow");
            // return -1;
        }
        else
        {
            // return stack[--top];
            top--;
        }
    }

    private void peek()
    {
        System.out.println(stack[top]);
    }

    private void peek(int pos)
    {
        if (top - pos + 1 < 0)                              // FYI : Top - Index + 1
            System.out.println("Invalid index");

        else
            System.out.println(stack[top - pos + 1]);
    }

    private void push(int val)
    {
        if (top == size - 1)
        {
            System.out.println("Stack overflow");
        }
        else
        {
            stack[++top] = val;
        }
    }

}
