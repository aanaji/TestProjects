package com.starter.datastructures;

public class S13_Stack_5_Infix_Postfix
{
    Node top;

    class Node
    {
        char data;
        Node next;

        Node(char data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S13_Stack_5_Infix_Postfix ll = new S13_Stack_5_Infix_Postfix();

//        ll.push('#');
        
        char[] infix = { 'a', '+', 'b', '*', 'c', '-', 'd', '/', 'e', '\0' };

        ll.convert(infix);
    }

    private void convert(char[] infix)
    {
        char[] postfix = new char[infix.length+1];

        int i = 0, j = 0;

        while (infix[i] != '\0')
        {
            if (isOperand(infix[i]))
            {
                postfix[j++] = infix[i++];
            }
            else
            {
                if (isEmpty() || pre(infix[i]) > pre(stackTop()))                // FYI
                {
                    push(infix[i++]);
                }
                else
                {
                    postfix[j++] = pop();
                }
            }
        }
        
        // pop out remaining char from stack
        
        while(!isEmpty())
        {
            postfix[j++] = pop();
        }
        
        System.out.println(postfix);
    }

    private boolean isOperand(char c)
    {
        if (c == '+' || c == '-' || c == '*' || c == '/')
            return false;

        return true;
    }

    private int pre(char c)
    {
        if (c == '+' || c == '-')
            return 1;

        if (c == '*' || c == '/')
            return 2;

        return 0;
    }

    private char stackTop()
    {
        return top.data;
    }

    private char pop()
    {
        char x = '\0';
        if (!isEmpty())
        {
            Node p = top;
            top = top.next;
            x = p.data;
        }
        return x;
    }

    private boolean isEmpty()
    {
        if (top == null)
            return true;

        return false;
    }

    private void push(char val)
    {
        Node t = new Node(val);

        if (!isFull(t))
        {
            t.next = top;
            top = t;
        }
    }

    private boolean isFull(Node t)
    {
        if (t == null)
            return true;

        return false;
    }

}
