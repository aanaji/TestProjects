package com.starter.datastructures;

public class S11_LinkedList_13_CheckLoop
{
    Node first, last, second, third;

    static class Node
    {
        int data;
        Node next;

        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_13_CheckLoop ll = new S11_LinkedList_13_CheckLoop();

        ll.insertLast(2);
        ll.insertLast(6);
        ll.insertLast(8);
        ll.insertLast(4);
        ll.insertLast(5);

        boolean result = ll.checkLoop();
        System.out.println(result);
    }
    
    private boolean checkLoop()
    {
        Node p1 = first.next.next;
        Node p2 = first.next.next.next.next;
        p2.next = p1;
        
        Node p = first;
        Node q = first;
        
        do
        {
            p = p.next;
            q = q.next;
            
            q = q != null ? q.next : null;
            
        } while (p != null && q != null && p != q);
        
        if(p == q)
            return true;
        
        return false;
    }

    private void insertLast(int val)
    {
        Node t = new Node(val);

        if (first == null)
        {
            first = last = t;
        }
        else
        {
            last.next = t;
            last = t;
        }
    }
}
