package com.starter.datastructures;

public class S8_String_7_Palindrome
{

    public static void main(String[] args)
    {
        char[] a = "madam".toCharArray();

        // Reverse + Copy

        // In-Place
        
        int i = 0;
        int j = a.length - 1;
        for (; i < j; i++, j--)
        {
            if (a[i] != a[j])
            {
                System.out.println("Not Palindrome");
                return;
            }
        }
        System.out.println("Palindrome");
    }

}
