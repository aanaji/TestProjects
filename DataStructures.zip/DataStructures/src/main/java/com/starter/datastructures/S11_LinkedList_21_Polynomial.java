package com.starter.datastructures;

public class S11_LinkedList_21_Polynomial
{
    Node poly, last;
    
    static class Node
    {
        int coeff;
        int exp;
        Node next;
        
        Node(int coeff, int exp)
        {
            this.coeff = coeff;
            this.exp = exp;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_21_Polynomial ll = new S11_LinkedList_21_Polynomial();
        
        ll.poly = new Node (5, 4);
        
        Node second =  new Node (6, 3);
        Node third =  new Node (7, 2);
        Node fourth =  new Node (9, 0);
        
        ll.poly.next = second;
        second.next = third;
        third.next = fourth;
        ll.last = fourth;
        
        
        // Read from console and create the Polynomial
        
//        Node t = new Node(5, 4);
//        
//        if(ll.poly == null)
//        {
//            ll.poly = ll.last = t;
//        }
//        else
//        {
//            ll.last.next = t;
//            ll.last = t;
//          ,m......
        
        ll.display(ll.poly);
        
        ll.eval(ll.poly);
        
    }
    
    void display(Node p)
    {
        while(p != null)
        {
            System.out.println("Co-eff : " + p.coeff + " and exp : " + p.exp);
            p = p.next;
        }
    }
    
    void eval(Node p)
    {
        long val = 0;
        int x = 5;
        
        while(p != null)
        {
            val += p.coeff *Math.pow(x, p.exp);
            p = p.next;
        }
        
        System.out.println(val);
    }

}
