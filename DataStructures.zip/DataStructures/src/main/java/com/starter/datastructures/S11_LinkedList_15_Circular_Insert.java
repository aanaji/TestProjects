package com.starter.datastructures;

public class S11_LinkedList_15_Circular_Insert
{
    Node head;
    int flag = 0;
    
    static class Node
    {
        int data;
        Node next;
        
        Node() 
        { }
        
        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_15_Circular_Insert ll = new S11_LinkedList_15_Circular_Insert();
        
        ll.head = new Node(8);
        
        Node second = new Node(3);
        Node third = new Node(4);
        
        ll.head.next = second;
        second.next = third;
        third.next = ll.head;
        
        ll.printCircularLL(ll.head);
        
        ll.insertCircularLL(0, 5);
        ll.insertCircularLL(2, 7);
        
        ll.printCircularLL(ll.head);
        
    }
    
    private void insertCircularLL(int pos, int val)
    {
        Node p;
        
        Node t = new Node();
        t.data = val;
        
        if(pos == 0)
        {
            if(head == null)
            {
                head = t;
                head.next = head;                       // FYI : Circular LL
            }
            else
            {
                p = head;                               // FYI
                
                while(p.next != head)                   // FYI
                    p = p.next;
                
                p.next = t;
                t.next = head;
                head = t;
            }
        }
        else
        {
            p = head;                                     // FYI
            
            for(int i=0; i<pos-1; i++)
                p = p.next;
            
            t.next = p.next;
            p.next = t;
        }
        
    }

    private void printCircularLL(Node p)
    {
        System.out.println();
        
        do                                        // FYI : do - while
        {
            System.out.print("\t" + p.data);
            p = p.next;
            
        } while( p != head);
    }

}
