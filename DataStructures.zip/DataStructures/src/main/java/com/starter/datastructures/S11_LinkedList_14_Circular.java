package com.starter.datastructures;

public class S11_LinkedList_14_Circular
{
    Node head;
    int flag = 0;
    
    static class Node
    {
        int data;
        Node next;
        
        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_14_Circular ll = new S11_LinkedList_14_Circular();
        
        ll.head = new Node(8);
        
        Node second = new Node(3);
        Node third = new Node(4);
        
        ll.head.next = second;
        second.next = third;
        third.next = ll.head;
        
        ll.printCircularLL(ll.head);
        
        System.out.println();
        
        ll.printRecursiveCircularLL(ll.head);
    }
    
    private void printCircularLL(Node p)
    {
        System.out.println();
        
        do                                        // FYI : do - while
        {
            System.out.print("\t" + p.data);
            p = p.next;
            
        } while( p != head);
    }
    
    private void printRecursiveCircularLL(Node p)
    {
        if(p != head || flag == 0)                      // FYI : global or static : flag                                   
        {
            flag = 1;
            System.out.print("\t" + p.data);
            
            printRecursiveCircularLL(p.next);
        }
    }

}
