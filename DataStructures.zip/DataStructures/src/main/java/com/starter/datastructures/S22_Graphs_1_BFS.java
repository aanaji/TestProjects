package com.starter.datastructures;

public class S22_Graphs_1_BFS {
	static int[] visited = new int[8];

	public static void main(String[] args) {
		int A[][] = { { 0, 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 1, 1, 1, 0, 0, 0 }, { 0, 1, 0, 1, 0, 0, 0, 0 },
				{ 0, 1, 1, 0, 1, 1, 0, 0 }, { 0, 1, 0, 1, 0, 1, 0, 0 }, { 0, 0, 0, 1, 1, 0, 1, 1 },
				{ 0, 0, 0, 0, 0, 1, 0, 0 }, { 0, 0, 0, 0, 0, 1, 0, 0 } };

		BFS(A, 4, 8);
	}

	static void BFS(int G[][], int start, int n) {
		LinkedQueue q = new LinkedQueue();

		int u = start, v;
		int visited[] = new int[n];

		System.out.print("\t" + u);
		visited[u] = 1;
		q.enqueue(u);

		while (q.front != null) {
			u = q.deQueue();
			for (v = 1; v < n; v++) {
				if (G[u][v] == 1 && visited[v] == 0) {
					System.out.print("\t" + v);
					visited[v] = 1;
					q.enqueue(v);
				}
			}
		}
	}
}
