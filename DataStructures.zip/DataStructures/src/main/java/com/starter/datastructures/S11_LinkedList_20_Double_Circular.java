package com.starter.datastructures;

public class S11_LinkedList_20_Double_Circular
{
    Node first, last;
    
    static class Node
    {
        Node prev;
        int data;
        Node next;
        
        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_20_Double_Circular ll = new S11_LinkedList_20_Double_Circular();
        
        // display
        // insert
        // delete
        
        ll.printDoubleLL(ll.first);
        
    }

    private void printDoubleLL(Node p)
    {
        System.out.println();
        
        while (p != null)                                       // FYI : while
        {
            System.out.print("\t" + p.data);
            p = p.next;
            
        }
    }

}
