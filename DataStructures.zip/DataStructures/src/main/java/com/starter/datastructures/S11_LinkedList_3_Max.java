package com.starter.datastructures;

public class S11_LinkedList_3_Max {
	Node head;

	static class Node {
		int data;

		Node next;

		Node(int data) {
			this.data = data;
		}
	}

	public Node findMax() {
		Node n = head;
		Node max = head;

		while (n != null) {
			if (max.data < n.data) {
				max = n;
			}
		}
		return max;
	}

	public Node search(int data, Node n) {

		if (n == null) {
			return null;
		}
		if (n.data == data) {
			return n;
		}

		return search(data, n.next);
	}

	public static void main(String[] args) {
		S11_LinkedList_3_Max ll = new S11_LinkedList_3_Max();

		ll.head = new Node(2);

		Node second = new Node(6);
		Node third = new Node(4);

		ll.head.next = second;
		second.next = third;

		int max = ll.max(ll.head);
		System.out.println("Max : " + max);

		max = ll.recursiveMax(ll.head);
		System.out.println("Max : " + max);

	}

	private int recursiveMax(Node head2) {
		int x = 0;

		if (head2 == null)
			return 0;

		x = recursiveMax(head2.next);

		return x > head2.data ? x : head2.data; // FYI

	}

	private int max(Node head2) {
		int max = 0;

		while (head2 != null) {
			if (max < head2.data)
				max = head2.data;

			head2 = head2.next;
		}

		return max;
	}
}
