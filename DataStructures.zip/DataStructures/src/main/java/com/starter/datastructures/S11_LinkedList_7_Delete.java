package com.starter.datastructures;

public class S11_LinkedList_7_Delete
{
    Node first, last;

    static class Node
    {
        int data;
        Node next;

        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_7_Delete ll = new S11_LinkedList_7_Delete();

        ll.insertLast(3);
        ll.insertLast(6);
        ll.insertLast(7);
        ll.insertLast(9);
        ll.insertLast(15);

        ll.printLL();

        ll.delete(0);
        ll.delete(2);

        ll.printLL();
    }

    private void delete(int pos)
    {
        if(pos < 0)
        {
            return;
        }
        else if (pos == 0)
        {
            Node p = first;
            first = p.next;
            // delete p;
            p = null;
        }
        else
        {
            Node p = first;
            Node q = null;

            for (int i = 0; i < pos - 1 && p != null; i++)
            {
                q = p;
                p = p.next;
            }

            if (p != null)
            {
                q.next = p.next;
                // delete p;
                p = null;
            }
        }
    }

    private void insertLast(int val)
    {
        Node t = new Node(val);

        if (first == null)
        {
            first = last = t;
        }
        else
        {
            last.next = t;
            last = t;
        }
    }

    private void printLL()
    {
        System.out.println();
        Node n = first;

        while (n != null) // FYI : while
        {
            System.out.print("\t" + n.data);
            n = n.next;
        }
    }
}
