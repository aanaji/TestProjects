package com.starter.datastructures;

public class S21_Hashing_4_DoubleHashing
{
    static int SIZE = 10;

    static int PRIME = 7;

    public static void main(String[] args)
    {
        int[] ht = new int[10];

        insert(ht, 5);
        insert(ht, 25);
        insert(ht, 15);
        insert(ht, 35);
        insert(ht, 95);

        System.out.println("\nKey found at : " + search(ht, 25));

        System.out.println("\nKey found at : " + search(ht, 35));
    }

    static int hash(int key)
    {
        return key % SIZE;
    }

    static int primeHash(int key)
    {
        return PRIME - (key % PRIME);
    }

    static int doubleHash(int H[], int key)
    {
        int idx = hash(key);
        int i = 0;
        while (H[(hash(idx) + i * primeHash(idx)) % SIZE] != 0)
        {
            i++;
        }
        return (idx + i * primeHash(idx)) % SIZE;
    }

    static void insert(int H[], int key)
    {
        int idx = hash(key);

        if (H[idx] != 0)
        {
            idx = doubleHash(H, key);
        }
        H[idx] = key;
    }

    static int search(int H[], int key)
    {
        int idx = hash(key);
        int i = 0;
        while (H[(hash(idx) + i * primeHash(idx)) % SIZE] != key)
        {
            i++;
            if (H[(hash(idx) + i * primeHash(idx)) % SIZE] == 0)
            {
                return -1;
            }
        }
        return (hash(idx) + i * primeHash(idx)) % SIZE;
    }

}
