package com.starter.datastructures;

public class S5_Recursion_11_TaylorSeries_Iterative
{
    static double s;

    public static void main(String[] args)
    {
        int x = 4, n = 15;

        double result = iterativeTaylor(x, n);

        System.out.println("Result : " + result);
    }

    private static double iterativeTaylor(int x, int n)
    { 
        for (; n > 0; n--)
        {
            s = 1 +  (double) x / n * s;    
        }
        return s;
    }
}
