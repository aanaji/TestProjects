package com.starter.datastructures;

public class S7_Array_4_GetSetMinMaxSumAvg
{

    public static void main(String[] args)
    {
        int[] n = { 34, 2, 16, 54, 78, 63, 29, 71, 25 };

        min(n);

        max(n);

        int index5 = get(n, 5);
        System.out.println("Index-5 : " + index5);

        int index7 = set(n, 7, 11);
        System.out.println("Index-7 : " + index7);

        int sum = sum(n);
        double avg = sum / n.length;
        System.out.println("Sum : " + sum + " Avg : " + avg);
    }

    private static void min(int[] n)
    {
        int min = n[0];
        for (int i = 0; i < n.length; i++)
        {
            if (min > n[i])
                min = n[i];
        }
        System.out.println("Min : " + min);
    }

    private static void max(int[] n)
    {
        int max = n[0];
        for (int i = 0; i < n.length; i++)
        {
            if (max < n[i])
                max = n[i];
        }
        System.out.println("Max : " + max);
    }

    private static int sum(int[] n)
    {
        int s = 0;
        for (int i = 0; i < n.length; i++)
        {
            s += n[i];
        }
        return s;
    }

    private static int get(int[] n, int index)
    {
        if (index >= 0 && index < n.length)
            return n[index];
        return -1;
    }

    private static int set(int[] n, int index, int value)
    {
        if (index >= 0 && index < n.length)
        {
            n[index] = value;
            return value;
        }
        return -1;
    }

}
