package com.starter.datastructures;

class CircularQueue
{
    private static int front, rear, size;

    private static int[] queue;

    CircularQueue(int size)
    {
        front = rear = 0;                                  // FYI
        CircularQueue.size = size;
        queue = new int[size];
    }

    void enqueue(int val)
    {
        if ((rear + 1) % size == front)                                          // FYI
        {
            System.out.println("Queue is full");
        }
        else
        {
            rear = (rear + 1) % size;
            queue[rear] = val;                                                    // FYI
        }
    }

    void dequeue()
    {
        if (front == rear)
        {
            System.out.println("Queue is empty");
        }
        else
        {
            front = (front + 1) % size;                                     // FYI
        }
    }

    void display()
    {
        if (front == rear)
        {
            System.out.println("Queue is Empty");
        }
        else
        {
            int i = front + 1;
            do 
            {
                System.out.println(queue[i]);
                i = (i + 1) % size;
            } 
            while(i != (rear + 1) % size);
        }
    }

    void queueFront()
    {
        if (front == rear)
        {
            System.out.println("Queue is Empty");
        }
        else
        {
            System.out.println("Queue Front : " + queue[++front]);                      // FYI
        }
    }
}

public class S14_Queue_2_Circular
{
    public static void main(String[] args)
    {
        CircularQueue q = new CircularQueue(5);                                     // FYI
        q.display();

        q.enqueue(20);
        q.enqueue(30);
        q.enqueue(40);
        q.enqueue(50);

        q.display();

        q.enqueue(60);

        q.display();

        q.dequeue();
        q.dequeue();
        System.out.printf("After two node deletion");

        q.enqueue(70);
        q.enqueue(65);
        
        q.display();

        q.queueFront();
    }

}
