package com.starter.datastructures;

public class S5_Recursion_1_Tail
{

    public static void main(String[] args)
    {
        int x = 5;

        recursiveTail(x);

        iterativeTail(x);
    }

    private static void recursiveTail(int n)
    {
        if (n > 0)
        {
            System.out.print("\t " + n);
            recursiveTail(n - 1);
        }
    }

    private static void iterativeTail(int n)
    {
        System.out.print("\n");
        while (n > 0)
        {
            System.out.print("\t " + n);
            n--;
        }
    }

}
