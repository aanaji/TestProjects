package com.starter.datastructures;

public class S11_LinkedList_9_RemoveDuplicates
{
    Node first, last;

    static class Node
    {
        int data;
        Node next;

        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_9_RemoveDuplicates ll = new S11_LinkedList_9_RemoveDuplicates();

        ll.insertLast(3);
        ll.insertLast(5);
        ll.insertLast(5);
        ll.insertLast(8);
        ll.insertLast(8);
        ll.insertLast(8);

        ll.printLL();

        ll.removeDup();
        
        ll.printLL();
    }

    private void removeDup()
    {
        Node p = first;
        Node q = first.next;
        
        while(q != null)
        {
            if(p.data != q.data)
            {
                p = q;
                q = q.next;
            }
            else
            {
                p.next = q.next;
//                delete q;
                q = p.next;
            }
        }
    }

    private void insertLast(int val)
    {
        Node t = new Node(val);

        if (first == null)
        {
            first = last = t;
        }
        else
        {
            last.next = t;
            last = t;
        }
    }

    private void printLL()
    {
        System.out.println();
        Node n = first;

        while (n != null) // FYI : while
        {
            System.out.print("\t" + n.data);
            n = n.next;
        }
    }
}
