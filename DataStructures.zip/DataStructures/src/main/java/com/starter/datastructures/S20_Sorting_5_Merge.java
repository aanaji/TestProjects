package com.starter.datastructures;

public class S20_Sorting_5_Merge
{

    public static void main(String[] args)
    {
        int[] arr = { 50, 70, 60, 90, 40, 80, 10, 20, 30 };
        int i;

        System.out.println("Before Iterative Merge Sort - ");
        for (i = 0; i < arr.length; i++)
            System.out.print(" " + arr[i]);

        mergeSort(arr, arr.length);

        System.out.println("\nAfter Iterative Merge Sort - ");
        for (i = 0; i < arr.length; i++)
            System.out.print(" " + arr[i]);
        
        int[] arr2 = { 50, 70, 60, 90, 40, 80, 10, 20, 30 };

        System.out.println("\nBefore Recursive Merge Sort - ");
        for (i = 0; i < arr2.length; i++)
            System.out.print(" " + arr2[i]);

        recursiveMergeSort(arr2, 0, arr2.length-1);

        System.out.println("\nAfter Recursive Merge Sort - ");
        for (i = 0; i < arr2.length; i++)
            System.out.print(" " + arr2[i]);
    }

    private static void recursiveMergeSort(int[] arr, int l, int h)
    {
        if (l < h) 
        {
            int mid = (l + h) / 2;
            recursiveMergeSort(arr, l, mid);
            recursiveMergeSort(arr, mid + 1, h);
            merge(arr, l, mid, h);
        }
    }
    
    private static void mergeSort(int[] arr, int n)
    {
        int i, p, low, mid, high;

        for (p = 2; p <= n; p = p * 2)
        {
            for (i = 0; i + p - 1 < n; i = i + p)
            {
                low = i;
                high = i + p - 1;
                mid = (low + high) / 2;

                merge(arr, low, mid, high);
            }
        }

        if (p / 2 < n)
            merge(arr, 0, p / 2 - 1, n - 1);
    }

    private static void merge(int[] arr, int low, int mid, int high)
    {
        int i = low;
        int j = mid + 1;
        int k = low;
        int[] b = new int[high + 1];

        while (i <= mid && j <= high)
        {
            if (arr[i] < arr[j])
                b[k++] = arr[i++];
            else
                b[k++] = arr[j++];
        }

        for (; i <= mid; i++)
            b[k++] = arr[i];

        for (; j <= high; j++)
            b[k++] = arr[j];

        for (i = low; i <= high; i++)
            arr[i] = b[i];
    }

}
