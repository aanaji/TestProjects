package com.starter.datastructures;

public class S5_Recursion_2_Head
{

    public static void main(String[] args)
    {
        int x = 5;

        recursiveHead(x);

        iterativeHead(x);
    }

    private static void recursiveHead(int n)
    {
        if (n > 0)
        {
            recursiveHead(n - 1);
            System.out.print("\t" + n);
        }
    }

    private static void iterativeHead(int n)
    {
        int i = 1;
        System.out.print("\n");
        while (i <= n)
        {
            System.out.print("\t" + i);
            i++;
        }
    }

}
