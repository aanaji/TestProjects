package com.starter.datastructures;

public class S10_SparseMat_2_Add
{
    public static void main(String[] args)
    {
        int a[][] = { { 0, 0, 3, 0, 4 }, { 0, 0, 5, 7, 0 }, { 0, 0, 0, 0, 0 }, { 0, 2, 6, 0, 0 } };
        int b[][] = { { 0, 0, 2, 0, 5 }, { 0, 6, 0, 0, 8 }, { 0, 0, 0, 0, 0 }, { 1, 0, 0, 5, 0 } };

        int aNonZero = 0;
        int bNonZero = 0;

        int am = 0, an = 0, bm = 0, bn = 0;

        for (int i = 0; i < 4; i++)
        {
            am++;
            for (int j = 0; j < 5; j++)
            {
                if (i == 0)
                    an++;

                if (a[i][j] != 0)
                    aNonZero++;
            }
        }

        for (int i = 0; i < 4; i++)
        {
            bm++;
            for (int j = 0; j < 5; j++)
            {
                if (i == 0)
                    bn++;

                if (b[i][j] != 0)
                    bNonZero++;
            }
        }

        int a1[][] = new int[3][aNonZero];
        int b1[][] = new int[3][bNonZero];

        int k = 0;

        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 5; j++)
                if (a[i][j] != 0)
                {
                    a1[0][k] = i;
                    a1[1][k] = j;
                    a1[2][k] = a[i][j];
                    k++;
                }

        k = 0;

        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 5; j++)
                if (b[i][j] != 0)
                {
                    b1[0][k] = i;
                    b1[1][k] = j;
                    b1[2][k] = b[i][j];
                    k++;
                }

        // Add a1 and b1

        if (am != bm || an != bn)
            return;

        int apos = 0, bpos = 0, len = 0;
        int result[][] = new int[3][aNonZero + bNonZero];

        while (apos < aNonZero && bpos < bNonZero)
        {
            if (a1[0][apos] < b1[0][bpos] || (a1[0][apos] == b1[0][bpos] && a1[1][apos] < b1[1][bpos]))
            {
                result[0][len] = a1[0][apos];
                result[1][len] = a1[1][apos];
                result[2][len] = a1[2][apos];
                apos++;
                len++;
            }
            else if (a1[0][apos] > b1[0][bpos] || (a1[0][apos] == b1[0][bpos] && a1[1][apos] > b1[1][bpos]))
            {
                result[0][len] = b1[0][bpos];
                result[1][len] = b1[1][bpos];
                result[2][len] = b1[2][bpos];
                bpos++;
                len++;
            }
            else
            {
                result[0][len] = a1[0][apos];
                result[1][len] = a1[1][apos];
                result[2][len] = a1[2][apos] + b1[2][bpos];
                apos++;
                bpos++;
                len++;
            }
        }

        while (apos < aNonZero)
        {
            result[0][len] = a1[0][apos];
            result[1][len] = a1[1][apos];
            result[2][len] = a1[2][apos];
            apos++;
            len++;
        }

        while (bpos < bNonZero)
        {
            result[0][len] = b1[0][bpos];
            result[1][len] = b1[1][bpos];
            result[2][len] = b1[2][bpos];
            bpos++;
            len++;
        }

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < len; j++)
            {
                System.out.print(result[i][j]);
            }
            System.out.println();
        }

        System.out.println("Sparse Matrix : ");

        k = 0;
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if (i == result[0][k] && j == result[1][k])
                {
                    System.out.print("\t" + result[2][k++]);
                }
                else
                {
                    System.out.print("\t" + 0);
                }
            }
            System.out.println();
        }
    }
}
