package com.starter.datastructures;

public class S15_Tree_7_BinaryTree_Height {
	TreeNode root;

	static class TreeNode {
		TreeNode left;
		int data;
		TreeNode right;

		TreeNode(int data) {
			this.data = data;
			left = null;
			right = null;
		}
	}

	public static void main(String[] args) {
		S15_Tree_7_BinaryTree_Height tree = new S15_Tree_7_BinaryTree_Height();
		tree.root = new TreeNode(10);
		tree.root.left = new TreeNode(-2);
		tree.root.right = new TreeNode(7);

		tree.root.left.left = new TreeNode(8);
		tree.root.left.right = new TreeNode(-4);

		/*
		 * tree.root.left.right.left = new TreeNode(6); tree.root.left.right.right = new
		 * TreeNode(7);
		 */

		int height = tree.height(tree.root);
		System.out.println("Height : " + height);

		System.out.println(tree.minimumDepth(tree.root));

		System.out.println(tree.minimumDepth(tree.root, 0));

		System.out.println(tree.maximumSum(tree.root));
	}

	int height(TreeNode p) {
		if (p == null)
			return 0;

		else {
			int x = height(p.left); // FYI : int
			int y = height(p.right); // FYI : int

			if (x > y) // FYI
				return (x + 1);

			else
				return (y + 1);
		}
	}

	int minimumDepth(TreeNode root) {
		// Corner case. Should never be hit unless the code is
		// called on root = NULL
		if (root == null)
			return 0;

		// Base case : Leaf Node. This accounts for height = 1.
		if (root.left == null && root.right == null)
			return 1;

		// If left subtree is NULL, recur for right subtree
		if (root.left == null)
			return minimumDepth(root.right) + 1;

		// If right subtree is NULL, recur for left subtree
		if (root.right == null)
			return minimumDepth(root.left) + 1;

		return Math.min(minimumDepth(root.left), minimumDepth(root.right)) + 1;
	}

	int minimumDepth(TreeNode root, int level) {

		if (root == null)
			return level;
		level++;

		return Math.min(minimumDepth(root.left, level), minimumDepth(root.right, level));
	}

	int maximumSum(TreeNode node) {

		if (node.left == null && node.right == null) {
			return node.data;
		}

		int leftSum = maximumSum(node.left) + node.data;
		int rightSum = maximumSum(node.right) + node.data;

		return Math.max(leftSum, rightSum);
	}

}