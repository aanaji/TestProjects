package com.starter.datastructures;

public class S5_Recursion_5_Nested
{

    public static void main(String[] args)
    {
        int n = 95;

        int result = recursiveNested(n);

        System.out.println("Result of " + n + " : " + result);
    }

    private static int recursiveNested(int n)
    {
        if (n > 100)
        {
            return n - 10;
        }
        else
        {
            return recursiveNested(recursiveNested(n + 11));
        }
    }
}
