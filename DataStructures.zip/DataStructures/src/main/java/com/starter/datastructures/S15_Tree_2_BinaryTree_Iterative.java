package com.starter.datastructures;

import java.util.Stack;

public class S15_Tree_2_BinaryTree_Iterative {
	Node top;

	class Node {
		int data;
		Node next;

		Node(int data) {
			this.data = data;
		}
	}

	TreeNode root;

	public static void main(String[] args) {
		S15_Tree_2_BinaryTree_Iterative tree = new S15_Tree_2_BinaryTree_Iterative();

		tree.root = new TreeNode(1);
		tree.root.left = new TreeNode(2);
		tree.root.right = new TreeNode(3);

		tree.root.left.left = new TreeNode(4);
		tree.root.left.right = new TreeNode(5);

		System.out.println("PreOrder : ");
		tree.preorder();

		System.out.println("InOrder : ");
		tree.inorder();

		System.out.println("PostOrder : ");
		tree.postorder();
	}

	private void preorder() {
		if (root == null)
			return;

		Stack<TreeNode> st = new Stack<>(); // FYI
		TreeNode t = root;

		while (t != null || st.isEmpty()) {
			if (t != null) {
				System.out.print(t.data + " "); // FYI
				st.push(t);
				t = t.left;
			} else {
				t = st.pop();
				t = t.right;
			}
		}
	}

	private void inorder() {
		if (root == null)
			return;

		Stack<TreeNode> st = new Stack<>(); // FYI
		TreeNode t = root;

		while (t != null || st.isEmpty()) {
			if (t != null) {
				st.push(t);
				t = t.left;
			} else {
				t = st.pop();
				System.out.print(t.data + " "); // FYI
				t = t.right;
			}
		}
	}

	private void postorder() {
		Stack<TreeNode> stack = new Stack<>();

		while (true) // FYI
		{
			while (root != null) {
				stack.push(root);
				stack.push(root);
				root = root.left;
			}

			if (stack.empty())
				return; // FYI

			root = stack.pop();

			if (!stack.empty() && stack.peek() == root)
				root = root.right;

			else {
				System.out.print(root.data + " ");
				root = null; // FYI
			}
		}
	}
}
