package com.starter.datastructures;

public class S7_Array_1_Insert_Delete
{

    public static void main(String[] args)
    {
        int a[] = new int[10];

        a[0] = 10;
        a[1] = 15;
        a[2] = 20;
        a[3] = 40;
        a[4] = 45;

        insert(30, 3, a, 5);

        delete(1, a, 6);
    }

    private static void insert(int x, int index, int[] a, int length)
    {
        if (index < 0 || index >= a.length)
            return;

        for (int i = length; i > index; i--)
        {
            a[i] = a[i - 1];
        }
        a[index] = x;
        length++;

        for (int i = 0; i < length; i++)
        {
            System.out.print("\t" + a[i]);
        }
    }

    private static void delete(int index, int[] a, int length)
    {
        if (index < 0 || index >= a.length)
            return;

        int x = a[index];
        System.out.println("\n\tDeleting item : " + x);

        for (int i = index; i < length - 1; i++)
        {
            a[i] = a[i + 1];
        }
        length--;

        for (int i = 0; i < length; i++)
        {
            System.out.print("\t" + a[i]);
        }
    }
}
