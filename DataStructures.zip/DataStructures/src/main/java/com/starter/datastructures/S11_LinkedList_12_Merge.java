package com.starter.datastructures;

public class S11_LinkedList_12_Merge {
	Node first, last, second, third;

	static class Node {
		int data;
		Node next;

		Node(int data) {
			this.data = data;
		}
	}

	public static void main(String[] args) {
		S11_LinkedList_12_Merge ll = new S11_LinkedList_12_Merge();

		ll.insertLast(2);
		ll.insertLast(6);
		ll.insertLast(8);
		ll.insertLast(14);

		S11_LinkedList_12_Merge ll2 = new S11_LinkedList_12_Merge();

		ll2.insertLast(4);
		ll2.insertLast(5);
		ll2.insertLast(10);
		ll2.insertLast(16);
		ll2.insertLast(18);
		ll2.insertLast(20);

		ll.printLL(ll.first); // FYI
		ll2.printLL(ll2.first);

		//ll.merge(ll.first, ll2.first);
		ll.printLL(ll.first);

		ll.merge2(ll.first, ll2.first);
		ll.printLL(ll.third);

	}

	private void merge(Node first, Node second) // FYI
	{
		if (first.data < second.data) {
			third = last = first;
			first = first.next;
			last.next = null;
		} else if (first.data == second.data) {
			third = last = first;
			first = first.next;
			second = second.next;
			last.next = null;
		} else {
			third = last = second;
			second = second.next;
			last.next = null;
		}

		while (first != null && second != null) {
			if (first.data < second.data) {
				last.next = first;
				last = first;
				first = first.next;
				last.next = null;
			} else if (first.data == second.data) {
				last.next = first;
				last = first;
				first = first.next;
				second = second.next;
				last.next = null;
			} else {
				last.next = second;
				last = second;
				second = second.next;
				last.next = null;
			}
		}
		if (first != null)
			last.next = first;
		else
			last.next = second;
	}

	private void insertLast(int val) {
		Node t = new Node(val);

		if (first == null) {
			first = last = t;
		} else {
			last.next = t;
			last = t;
		}
	}

	private void printLL(Node n) // FYI
	{
		System.out.println();

		while (n != null) // FYI : while
		{
			System.out.print("\t" + n.data);
			n = n.next;
		}
	}

	private void merge2(Node firstNode, Node secondNode) {

		while (firstNode != null && secondNode != null) {

			if (firstNode.data < secondNode.data) {
				if (third == null) {
					third = firstNode;
					last = firstNode;
				} else {
					last.next = firstNode;
					last = last.next;
				}
				firstNode = firstNode.next;
			} else {
				if (third == null) {
					third = secondNode;
					last = secondNode;
				} else {
					last.next = secondNode;
					last = last.next;
				}
				secondNode = secondNode.next;
			}
		}

		while (firstNode != null) {
			last.next = firstNode;
			last = last.next;
			firstNode = firstNode.next;
		}

		while (secondNode != null) {
			last.next = secondNode;
			last = last.next;
			secondNode = secondNode.next;
		}
	}
}
