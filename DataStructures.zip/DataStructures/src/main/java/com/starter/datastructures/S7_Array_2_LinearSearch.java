package com.starter.datastructures;

public class S7_Array_2_LinearSearch
{

    public static void main(String[] args)
    {
        int[] a = { 45, 23, 34, 67, 54, 12, 9, 15, 3 };

        int key = 15;

        int index = linear(a, key);
        System.out.println("Index : " + index);

        index = transposition(a, key);
        System.out.println("Index : " + index);
        
        index = moveToHead(a, key);
        System.out.println("Index : " + index);
    }

    private static int linear(int[] a, int key)
    {
        for (int i = 0; i < a.length; i++)
            if (key == a[i])
                return i;

        return -1;
    }

    private static int transposition(int[] a, int key)
    {
        for (int i = 0; i < a.length; i++)
        {
            if (key == a[i])
            {
                // swap (a[i], a[i-1])

                int temp = a[i];
                a[i] = a[i - 1];
                a[i - 1] = temp;

                return i - 1;
            }
        }
        return -1;
    }

    private static int moveToHead(int[] a, int key)
    {
        for (int i = 0; i < a.length; i++)
        {
            if (key == a[i])
            {
                // swap (a[i], a[0])

                int temp = a[i];
                a[i] = a[0];
                a[0] = temp;

                return 0;
            }
        }
        return -1;
    }
}
