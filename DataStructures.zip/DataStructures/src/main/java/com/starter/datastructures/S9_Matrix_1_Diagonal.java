package com.starter.datastructures;

public class S9_Matrix_1_Diagonal
{

    public static void main(String[] args)
    {
        int[][] m = new int[][] { { 1, 0, 0, 0 }, { 0, 3, 0, 0, 0 }, { 0, 0, 4, 0, 0 }, { 0, 0, 0, 8, 0 },
                { 0, 0, 0, 0, 6 } };

        int[] a = new int[5];

        // Set from 2D -> 1D
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if (i == j)
                    a[i] = m[i][j];
            }
        }
        
        for(int i=0; i<5; i++)
            System.out.print("\t" + a[i]);
        
        System.out.println("\nMatrix - ");
        
        // Print 1D -> 2D format
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if (i == j)
                    System.out.print("\t" + a[i]);
                else
                    System.out.print("\t" + 0);
            }
            System.out.println();
        }
    }

}
