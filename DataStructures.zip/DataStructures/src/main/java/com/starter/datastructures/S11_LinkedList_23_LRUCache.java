package com.starter.datastructures;

/* We can use Java inbuilt Deque as a double
ended queue to store the cache keys, with
the descending time of reference from front
to back and a set container to check presence
of a key. But remove a key from the Deque using
remove(), it takes O(N) time. This can be
optimized by storing a reference (iterator) to
each key in a hash map. */
import java.util.Deque;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

public class S11_LinkedList_23_LRUCache {

	// store keys of cache
	private Deque<Integer> doublyQueue;

	// store references of key in cache
	// private HashSet<Integer> hashSet;

	// maximum capacity of cache
	private final int CACHE_SIZE;

	S11_LinkedList_23_LRUCache(int capacity) {
		doublyQueue = new LinkedList<>();
		// hashSet = new HashSet<>();
		CACHE_SIZE = capacity;
	}

	/* Refer the page within the LRU cache */

	// get

	// D, B, A
	public void refer(int page) {
		if (!doublyQueue.contains(page)) {
			if (doublyQueue.size() == CACHE_SIZE) {
				int last = doublyQueue.removeLast();
				// hashSet.remove(last);
			}
		} else {/*
				 * The found page may not be always the last element, even if it's an
				 * intermediate element that needs to be removed and added to the start of the
				 * Queue
				 */
			doublyQueue.remove(page);
		}
		doublyQueue.push(page);
		// doublyQueue.add(page);
	}

	// display contents of cache
	public void display() {
		Iterator<Integer> itr = doublyQueue.iterator();
		while (itr.hasNext()) {
			System.out.print(itr.next() + " ");
		}
	}

	public static void main(String[] args) {
		S11_LinkedList_23_LRUCache cache = new S11_LinkedList_23_LRUCache(4);
		cache.refer(1);
		cache.refer(2);
		cache.refer(3);
		cache.refer(1);
		cache.refer(4);
		cache.refer(5);
		cache.refer(2);
		cache.refer(2);
		cache.refer(1);
		cache.display();

		Hashtable<String, String> hashTable = new Hashtable<>();

		// hashTable.put(null, "Ananda");

		System.out.println(hashTable);

		HashMap<String, String> hashMap = new HashMap<>();

		hashMap.put("Ananda", "Ananda");
		hashMap.put("Anaji", "Anaji");
		hashMap.put("Anan", "Anan");

		System.out.println(hashMap.size());

		System.out.println(hashMap);

		while (hashMap.entrySet().iterator().hasNext()) {
			Entry<String, String> entry = hashMap.entrySet().iterator().next();
		}
	}
}
// This code is contributed by Niraj Kumar
