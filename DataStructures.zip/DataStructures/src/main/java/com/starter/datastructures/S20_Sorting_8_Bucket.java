package com.starter.datastructures;

import java.util.Arrays;

public class S20_Sorting_8_Bucket
{
    public static void main(String[] args)
    {
        int[] arr = { 6, 8, 3, 10, 15, 12, 3, 6, 8, 9, 6 };

        System.out.println("Before Bucket Sort - ");
        System.out.print(" " + Arrays.toString(arr));

        int max = findMax(arr, arr.length);

        bucketSort(arr, max);                                       // FYI

        System.out.println("\nAfter Bucket Sort - ");
        System.out.print(" " + Arrays.toString(arr));
    }

    private static void bucketSort(int arr[], int max)
    {
        int[] bucket = new int[max + 1];                                // FYI
        int[] sortedArr = new int[arr.length];

        for (int i = 0; i < arr.length; i++)
            bucket[arr[i]]++;

        int outPos = 0;
        for (int i = 0; i < bucket.length; i++)
            for (int j = 0; j < bucket[i]; j++)
                sortedArr[outPos++] = i;
        
        for (int i = 0; i < sortedArr.length; i++)
            arr[i] = sortedArr[i];
    }

    private static int findMax(int[] arr, int n)
    {
        int max = arr[0];

        for (int i = 1; i < n; i++)
            if (max < arr[i])
                max = arr[i];

        return max;
    }

}
