package com.starter.datastructures;

public class S17_AVL_1_Create {
	TreeNode root;

	static class TreeNode {
		TreeNode left;
		int data;
		int height; // FYI : to calculate bf
		TreeNode right;

		TreeNode(int data) {
			this.data = data;
			left = null;
			right = null;
		}
	}

	public static void main(String[] args) {
		S17_AVL_1_Create tree = new S17_AVL_1_Create();

		// LL
		TreeNode root0 = null;
		root0 = tree.recursiveInsert(root0, 10);
		tree.recursiveInsert(root0, 5);
		tree.recursiveInsert(root0, 2);

		// LR
		TreeNode root = null;
		root = tree.recursiveInsert(root, 50);
		tree.recursiveInsert(root, 10);
		tree.recursiveInsert(root, 20);

		// RL
		TreeNode root2 = null;
		root2 = tree.recursiveInsert(root2, 20);
		tree.recursiveInsert(root2, 50);
		tree.recursiveInsert(root2, 30);

	}

	static int nodeHeight(TreeNode p) {
		int hl, hr;

		hl = (p != null && p.left != null) ? p.left.height : 0;
		hr = (p != null && p.right != null) ? p.right.height : 0;

		return (hl > hr) ? (hl + 1) : (hr + 1);
	}

	static int balanceFactor(TreeNode p) {
		int hl, hr;

		hl = (p != null && p.left != null) ? p.left.height : 0;
		hr = (p != null && p.right != null) ? p.right.height : 0;

		return hl - hr;
	}

	private TreeNode recursiveInsert(TreeNode p, int key) {
		TreeNode t;

		if (p == null) {
			t = new TreeNode(key);
			t.height = 1; // Set Height for every Node
			t.left = t.right = null;
			return t;
		}

		if (key < p.data)
			p.left = recursiveInsert(p.left, key);

		else if (key > p.data)
			p.right = recursiveInsert(p.right, key);

		p.height = nodeHeight(p); // FYI

		if (balanceFactor(p) == 2) {
			if (balanceFactor(p.left) == 1)
				return LLRotation(p);

			else if (balanceFactor(p.left) == -1)
				return LRRotation(p);
		} else if (balanceFactor(p) == -2) {
			if (balanceFactor(p.right) == 1)
				return RLRotation(p);

			else if (balanceFactor(p.right) == -1)
				return RRRotation(p);
		}

		return p;
	}

	private TreeNode LLRotation(TreeNode currentNode) // FYI
	{
		TreeNode leftNode = currentNode.left;

		currentNode.left = leftNode.right;
		leftNode.right = currentNode;

		currentNode.height = nodeHeight(currentNode);
		leftNode.height = nodeHeight(leftNode);

		if (root == currentNode)
			root = leftNode;

		return leftNode;
	}

	private TreeNode LRRotation(TreeNode currentNode) // FYI
	{
		TreeNode leftNode = currentNode.left;
		TreeNode leftNodeRight = leftNode.right;

		leftNode.right = leftNodeRight.left;
		currentNode.left = leftNodeRight.right;

		/// Check this code
		leftNodeRight.left = leftNode;
		leftNodeRight.right = currentNode;

		currentNode.height = nodeHeight(currentNode);
		leftNode.height = nodeHeight(leftNode);
		leftNodeRight.height = nodeHeight(leftNodeRight);

		if (root == currentNode)
			root = leftNodeRight;

		return leftNodeRight;
	}

	private TreeNode RLRotation(TreeNode p) // FYI
	{
		TreeNode pr = p.right;
		TreeNode prl = pr.left;

		pr.left = prl.right;
		p.right = prl.left;

		p.height = nodeHeight(p);
		pr.height = nodeHeight(pr);
		prl.height = nodeHeight(prl);

		if (root == p)
			root = prl;

		return prl;
	}

	private TreeNode RRRotation(TreeNode currentNode) // FYI
	{
		TreeNode rightNode = currentNode.right;
		TreeNode rightNodeLeft = rightNode.left;

		rightNode.left = currentNode;
		currentNode.right = rightNodeLeft;

		currentNode.height = nodeHeight(currentNode);
		rightNode.height = nodeHeight(rightNode);

		if (root == currentNode)
			root = rightNode;

		return rightNode;
	}

}