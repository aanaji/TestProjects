package com.starter.datastructures;

public class S11_LinkedList_17_Double_Insert
{
    Node first, last;
    
    static class Node
    {
        Node prev;
        int data;
        Node next;
        
        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_17_Double_Insert ll = new S11_LinkedList_17_Double_Insert();
        
        ll.insert(5);
        ll.insert(10);
        ll.insert(15);
        
        ll.insert(2, 1);
        ll.insert(4, 2);
        ll.insert(8, 4);
        
        ll.printDoubleLL(ll.first);
        
    }

    private void insert(int val, int pos)
    {
        Node p = first;
        
        Node t = new Node(val);
        t.prev = t.next = null;
        
        for(int i=0; i<pos-1; i++)
            p = p.next;
        
        t.next = p.next;
        t.prev = p;
        
        if(p.next != null)                          // FYI : Null check
        {
            p.next.prev = t;
        }
        
        p.next = t;
    }

    private void insert(int val)
    {
        Node t = new Node(val);
        t.prev = t.next = null;
        
        if(first == null)
        {
            first = last = t;
        }
        else
        {
            last.next = t;
            t.prev = last;
            last = t;
        }
        
    }

    private void printDoubleLL(Node p)
    {
        System.out.println();
        
        while (p != null)                                       // FYI : while
        {
            System.out.print("\t" + p.data);
            p = p.next;
            
        }
    }

}
