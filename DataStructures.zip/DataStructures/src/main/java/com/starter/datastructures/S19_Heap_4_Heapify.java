package com.starter.datastructures;

public class S19_Heap_4_Heapify {
	public static void main(String[] args) {
		int A[] = { 5, 10, 30, 20, 35, 40, 15 };
		int i;

		System.out.println("A - ");
		for (i = 0; i < 7; i++)
			System.out.print(" " + A[i]);

		heapify(A, 7);

		System.out.println("\nHeapify - ");
		for (i = 0; i < 7; i++)
			System.out.print(" " + A[i]);
	}

	private static void heapify(int[] A, int n) {
		// # of leaf elements: (n+1)/2, index of last leaf element's parent = (n/2)-1

		for (int parent = (n / 2) - 1; parent >= 0; parent--) {
			int leftChild = 2 * parent + 1; // Left child for current parent

			while (leftChild < n - 1) {
				// Compare left and right children of current parent
				int rightChild = leftChild + 1;
				if (A[leftChild] < A[rightChild]) {
					leftChild = rightChild;
				}

				// Compare parent and largest child
				if (A[parent] < A[leftChild]) {
//                    swap(A, i, j);
					int temp = A[parent];
					A[parent] = A[leftChild];
					A[leftChild] = temp;

					parent = leftChild;
					leftChild = 2 * parent + 1;
				} else {
					break;
				}
			}
		}
	}
}