package com.starter.datastructures;

public class S5_Recursion_3_Tree
{

    public static void main(String[] args)
    {
        int x = 3;

        recursiveTree(x);
    }

    private static void recursiveTree(int n)
    {
        if (n > 0)
        {
            System.out.print("\t" + n);
            recursiveTree(n - 1);
            recursiveTree(n - 1);
        }
    }

}
