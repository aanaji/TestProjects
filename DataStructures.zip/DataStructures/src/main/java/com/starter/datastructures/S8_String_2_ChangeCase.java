package com.starter.datastructures;

public class S8_String_2_ChangeCase
{

    public static void main(String[] args)
    {
        char[] charArr1 = { 'W', 'E', 'L', 'C', 'O', 'M', 'E' };

        int i = 0;
        for (; i < charArr1.length; i++)
            charArr1[i] = (char) (charArr1[i] + 32);

        System.out.println(charArr1);

        char[] charArr2 = { 'w', 'e', 'l', 'c', 'o', 'm', 'e' };

        for (i = 0; i < charArr2.length; i++)
            charArr2[i] = (char) (charArr2[i] - 32);

        System.out.println(charArr2);

        char[] charArr3 = { 'W', 'e', 'L', 'c', 'O', 'm', 'E' };

        for (i = 0; i < charArr3.length; i++)
            if (charArr3[i] >= 65 && charArr3[i] <= 90)
                charArr3[i] = (char) (charArr3[i] + 32);

            else if (charArr3[i] >= 97 && charArr3[i] <= 122)
                charArr3[i] = (char) (charArr3[i] - 32);

        System.out.println(charArr3);
    }

}
