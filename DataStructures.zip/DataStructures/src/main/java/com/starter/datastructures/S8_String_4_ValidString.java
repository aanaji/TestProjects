package com.starter.datastructures;

public class S8_String_4_ValidString
{

    public static void main(String[] args)
    {
        char[] ch = "Ani?321".toCharArray();
        boolean isValid = true;
        for (int i = 0; i < ch.length; i++)
        {
            if (!(ch[i] >= 65 && ch[i] <= 90) && !(ch[i] >= 97 && ch[i] <= 122) && !(ch[i] >= 48 && ch[i] <= 57))
            {
                isValid = false;
                break;
            }
        }
        if (isValid)
            System.out.println("Valid string");
        else
            System.out.println("Invalid string");
    }

}
