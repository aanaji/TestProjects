package com.starter.datastructures;

import java.util.ArrayDeque;
import java.util.Comparator;
import java.util.TreeMap;
import java.util.concurrent.ArrayBlockingQueue;

class Queue {
	private static int front, rear, size;

	private static int[] queue;

	Queue(int size) {
		front = rear = -1; // FYI
		Queue.size = size;
		queue = new int[size];
	}

	void enqueue(int val) {
		if (rear == size - 1) // FYI
		{
			System.out.println("Queue overflow");
		} else {
			queue[++rear] = val; // FYI
		}
	}

	void dequeue() {
		if (front == rear) {
			System.out.println("Queue underflow");
		} else {
			// 1. Shift elements

//            for (int i = 0; i < rear; i++)
//            {
//                queue[i] = queue[i + 1];
//            }
//
//            if (rear < size)
//            {
//                queue[rear] = 0;
//            }
//
//            rear--;

			// 2. Move front

			front++; // FYI
		}
	}

	void display() {
		if (front == rear) {
			System.out.println("Queue is Empty");
		} else {
			for (int i = front + 1; i <= rear; i++) // FYI
			{
				System.out.println(queue[i]);
			}
		}
	}

	void queueFront() {
		if (front == rear) {
			System.out.println("Queue is Empty");
		} else {
			System.out.println("Queue Front : " + queue[++front]); // FYI
		}
	}
}

public class S14_Queue_1_Array {
	public static void main(String[] args) throws InterruptedException {
		/*
		 * Queue q = new Queue(4); q.display();
		 * 
		 * q.enqueue(20); q.enqueue(30); q.enqueue(40); q.enqueue(50);
		 * 
		 * q.display();
		 * 
		 * q.enqueue(60);
		 * 
		 * q.display();
		 * 
		 * q.dequeue(); q.dequeue(); System.out.printf("After two node deletion");
		 * 
		 * q.display();
		 * 
		 * q.queueFront();
		 */

		java.util.ArrayDeque<String> testQueue = new ArrayDeque<>(5);

		testQueue.add("Test");
		testQueue.add("Test1");
		testQueue.add("Test2");
		testQueue.remove();
		testQueue.remove();
		testQueue.add("Test3");
		testQueue.add("Test4");
		testQueue.add("Test5");
		testQueue.add("Test");
		testQueue.add("Test1");
		testQueue.add("Test2");
		testQueue.add("Test7");
		testQueue.add("Test8");
		testQueue.add("Test9");

		ArrayBlockingQueue<String> arrayBlockingQueue = new ArrayBlockingQueue<>(1);
		
		//arrayBlockingQueue.cl

		// arrayBlockingQueue.put("123");
		// arrayBlockingQueue.put("345");

		System.out.println(new Object().hashCode());

		System.out.println(new Object().hashCode());

		System.out.println(new Object().hashCode());
		
		//TreeMap<, V>

	}

}

class testComparator implements Comparator<String> {

	@Override
	public int compare(String o1, String o2) {
		// TODO Auto-generated method stub
		return 0;
	}

}

class testComparable implements Comparable<String> {

	@Override
	public int compareTo(String o) {
		// TODO Auto-generated method stub
		return 0;
	}

}