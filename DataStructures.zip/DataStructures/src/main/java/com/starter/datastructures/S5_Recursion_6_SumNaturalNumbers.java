package com.starter.datastructures;

public class S5_Recursion_6_SumNaturalNumbers
{
    public static void main(String[] args)
    {
        int n = 10;

        int result = recursiveSum(n);

        System.out.println("Result : " + result);
    }

    private static int recursiveSum(int n)
    {
        if (n == 0)
            return 0;

        return recursiveSum(n - 1) + n;
    }
}
