package com.starter.datastructures;

public class S19_Heap_3_HeapSort
{
    public static void main(String[] args)
    {
        int[] A = { 0, 10, 20, 30, 25, 5, 40, 35 };
        int i;

        for (i = 2; i <= 7; i++) // FYI
            insert(A, i);

        System.out.println("Heap - ");
        for (i = 1; i <= 7; i++)
            System.out.print(" " + A[i]);
        
        for (i = 7; i > 1; i--)
            delete(A, i);
        
        System.out.println("\nHeap Sort - ");
        for (i = 1; i <= 7; i++)
            System.out.print(" " + A[i]);
    }

    private static void delete(int[] A, int n) // FYI
    {
        int i, j, val;

        val = A[1];
        A[1] = A[n];

        A[n] = val;
        
        i = 1;
        j = 2 * i;

        while (j < n - 1)
        {
            if (A[j + 1] > A[j])
                j = j + 1;

            if (A[i] < A[j])
            {
                int temp = A[i];
                A[i] = A[j];
                A[j] = temp;
                
                i = j;
                j = 2 * j;
            }
            else
            {
                break;
            }
        }
        
        System.out.print("\nDeleted : " + val);
    }

    private static void insert(int[] A, int n) // FYI
    {
        int temp, i = n;
        temp = A[n];

        // Compare and Move

        while (i > 1 && temp > A[i / 2]) // FYI & '<' : MIN HEAP
        {
            A[i] = A[i / 2];
            i = i / 2;
        }
        A[i] = temp;
    }
}