package com.starter.datastructures;

public class S15_Tree_6_BinaryTree_Count
{
    TreeNode root;

    static class TreeNode
    {
        TreeNode left;
        int data; 
        TreeNode right;

        TreeNode(int data)
        {
            this.data = data;
            left = null;
            right = null;
        }
    }

    public static void main(String[] args)
    {
        S15_Tree_6_BinaryTree_Count tree = new S15_Tree_6_BinaryTree_Count();
        tree.root = new TreeNode(1);
        tree.root.left = new TreeNode(2);  
        tree.root.right = new TreeNode(3); 
        
        tree.root.left.left = new TreeNode(4);  
        tree.root.left.right = new TreeNode(5);
        
        tree.root.left.right.left = new TreeNode(6);
        tree.root.left.right.right = new TreeNode(7);
        
        int count = tree.count(tree.root);
        System.out.println("Count : " + count);
        
        int leafCount = tree.leaf(tree.root);
        System.out.println("Leaf Count : " + leafCount);
        
        int deg1 = tree.deg1(tree.root);
        System.out.println("Deg1 Count : " + deg1);
        
        int deg2 = tree.deg2(tree.root);
        System.out.println("Deg2 Count : " + deg2);
        
        int deg12 = tree.deg12(tree.root);
        System.out.println("Deg12 Count : " + deg12);

    }
    
    int count(TreeNode p)
    {
        if (p == null)
            return 0;

        else
        {
            int x = count(p.left);
            int y = count(p.right);

            return x + y + 1;               // return count(p.left) + count(p.right) + 1;
        }
    }
    
//    int leaf(TreeNode p)
//    {
//        if (p == null)
//            return 0;
//        
//        if(p.left == null && p.right == null)
//            return 1;
//        
//        else
//            return leaf(p.left) + leaf(p.right);
//    }
    
    int leaf(TreeNode p)
    {
        if (p == null)
            return 0;

        else
        {
            int x = leaf(p.left);
            int y = leaf(p.right);

            if(p.left == null && p.right == null)
                return x + y + 1;
            
            else 
                return x + y;
        }
    }
    
    int deg2(TreeNode p)
    {
        if (p == null)
            return 0;

        else
        {
            int x = deg2(p.left);
            int y = deg2(p.right);

            if(p.left != null && p.right != null)
                return x + y + 1;
            
            else 
                return x + y;
        }
    }
    
    int deg12(TreeNode p)
    {
        if (p == null)
            return 0;

        else
        {
            int x = deg12(p.left);
            int y = deg12(p.right);

            if(p.left != null || p.right != null)
                return x + y + 1;
            
            else 
                return x + y;
        }
    }
    
    int deg1(TreeNode p)
    {
        if (p == null)
            return 0;

        else
        {
            int x = deg1(p.left);
            int y = deg1(p.right);

            if((p.left != null && p.right == null) || (p.left == null && p.right != null))
                return x + y + 1;
            
            else 
                return x + y;
        }
    }

}