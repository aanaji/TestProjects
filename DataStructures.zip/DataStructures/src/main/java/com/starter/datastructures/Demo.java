package com.starter.datastructures;

import java.util.ArrayList;
import java.util.Iterator;

public class Demo {
	public static void main(String[] args) {
		ArrayList<String> aList = new ArrayList<String>();
		aList.add("Apple");
		aList.add("Mango");
		aList.add("Guava");
		aList.add("Orange");
		aList.add("Peach");

		System.out.println("The ArrayList elements are: ");
		for (String s : aList) {
			System.out.println(s);
		}
		Iterator i = aList.iterator();
		String str = "";
		while (i.hasNext()) {
			str = (String) i.next();

			if (str.equals("Orange")) {
				i.remove();
				//i.
				System.out.println("\nThe element Orange is removed");
				//break;
			}

			aList.add("ABC");
		}
		System.out.println("\nThe ArrayList elements are: ");
		for (String s : aList) {
			System.out.println(s);
		}
	}
}