package com.starter.datastructures;

public class S5_Recursion_13_Combination
{

    public static void main(String[] args)
    {
        int result = recursive(4, 2);                           // Pascal's Triangle
        System.out.println("Result-1 : " + result);

        result = iterative(4, 2);
        System.out.println("Result-2 : " + result);
    }

    private static int recursive(int n, int r)
    {
        if (r == 0 || n == r)
            return 1;

        return recursive(n - 1, r - 1) + recursive(n - 1, r);
    }

    private static int iterative(int n, int r)
    {
        int num = fact(n);
        int den = fact(r) * fact(n - r);
        return num / den;
    }

    private static int fact(int n)
    {
        if (n == 0)
            return 1;

        return fact(n - 1) * n;
    }
}
