package com.starter.datastructures;

public class S8_String_3_Count
{

    public static void main(String[] args)
    {
        int vcount = 0, ccount = 0, word = 1;

        char ch[] = "How are you".toCharArray();

        for (int i = 0; i < ch.length; i++)
        {
            if (ch[i] == 'A' || ch[i] == 'E' || ch[i] == 'o' || ch[i] == 'a' || ch[i] == 'e' || ch[i] == 'u'
                    || ch[i] == 'i')
                vcount++;
            
            else if ((ch[i] >= 65 && ch[i] <= 90) || (ch[i] >= 97 && ch[i] <= 122))
                ccount++;
            
            else if (ch[i] == ' ')
                word++;
        }
        System.out.println("Vowels: " + vcount + ", Consonants: " + ccount + " and Words: " + word);
    }

}
