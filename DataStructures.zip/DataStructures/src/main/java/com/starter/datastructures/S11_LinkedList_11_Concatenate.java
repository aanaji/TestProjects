package com.starter.datastructures;

public class S11_LinkedList_11_Concatenate
{
    Node first, last;

    static class Node
    {
        int data;
        Node next;

        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_11_Concatenate ll = new S11_LinkedList_11_Concatenate();

        ll.insertLast(2);
        ll.insertLast(4);
        ll.insertLast(6);
        ll.insertLast(8);
        
        S11_LinkedList_11_Concatenate ll2 = new S11_LinkedList_11_Concatenate();

        ll2.insertLast(10);
        ll2.insertLast(12);
        ll2.insertLast(14);
        ll2.insertLast(16);

        ll.printLL(ll.first);                                   // FYI
        ll2.printLL(ll2.first);

        ll.concat(ll.first, ll2.first);
        ll.printLL(ll.first);
        
    }
    
    private void concat(Node llFirst, Node ll2First)            // FYI
    {
        Node p = llFirst;
        while(p.next != null)
            p = p.next;
        
        p.next = ll2First;
        ll2First = null;
    }

    private void insertLast(int val)
    {
        Node t = new Node(val);

        if (first == null)
        {
            first = last = t;
        }
        else
        {
            last.next = t;
            last = t;
        }
    }
    
    private void printLL(Node n)                            // FYI
    {
        System.out.println();

        while (n != null)                                   // FYI : while
        {
            System.out.print("\t" + n.data);
            n = n.next;
        }
    }
}
