package com.starter.datastructures;

public class S11_LinkedList_5_Insert
{
    Node first;

    static class Node
    {
        int data;
        Node next;

        Node(int d)
        {
            data = d;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_5_Insert ll = new S11_LinkedList_5_Insert();

        ll.first = new Node(5);
        Node sec = new Node(10);
        Node thir = new Node(15);

        ll.first.next = sec;
        sec.next = thir;

        ll.printLL();

        ll.insert(0, 20);
        ll.printLL();

        ll.insert(2, 25);
        ll.printLL();

        ll.insert(5, 40);
        ll.printLL();
    }

    private void insert(int pos, int value)
    {
        if (pos == 0)
        {
            Node t = new Node(value); // Node t = new Node(); t.data = value;
            t.next = first;
            first = t;
        }
        else if (pos > 0)
        {
            Node p = first;
            for (int i = 0; i < pos - 1 && p != null; i++)                  // FYI
                p = p.next;

            if (p != null)                                                  // FYI
            {
                Node t = new Node(value);
                t.next = p.next;
                p.next = t;
            }
        }
    }

    private void printLL()
    {
        System.out.println();
        Node n = first;

        while (n != null)                                                               // FYI : while
        {
            System.out.print("\t" + n.data);
            n = n.next;
        }
    }

}
