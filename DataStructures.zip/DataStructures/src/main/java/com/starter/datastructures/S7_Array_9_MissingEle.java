package com.starter.datastructures;

public class S7_Array_9_MissingEle
{

    public static void main(String[] args)
    {
        int[] a = { 1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12 };

        // In Sequence from 0 to N
        int sum = 0;
        for (int i = 0; i < a.length; i++)
            sum += a[i];

        int n = a.length + 1;
        double sumN = n * (n + 1) / 2;

        System.out.println("Missing ele : " + (sumN - sum));

        // Out of Sequence
        int[] b = { 6, 7, 8, 9, 10, 11, 13, 14, 15, 16 };

        int diff = b[0] - 0;
        for (int i = 0; i < b.length; i++)
        {
            if (b[i] - i != diff)
            {
                System.out.println("Missing element : " + (i + diff));
                break;
            }
        }

        // Multiple missing elements
        int[] c = { 1, 2, 3, 4, 5, 6, 8, 9, 12, 15, 16, 17, 18, 19, 20 };

        diff = c[0] - 0;
        for (int i = 0; i < c.length; i++)
        {
            if (c[i] - i != diff)
            {
                while (diff < c[i] - i)
                {
                    System.out.print("\t" + (i + diff));
                    diff++;
                }
            }
        }

        // Hash Multiple missing elements
        int[] d = { 1, 2, 3, 4, 5, 6, 8, 9, 12, 15, 16 };
        System.out.println();
        int max = d[0];
        for (int i = 1; i < d.length; i++)
        {
            if (d[i] > max)
                max = d[i];
        }

        int[] h = new int[max + 1];

        for (int i = 0; i < d.length; i++)
        {
            h[d[i]]++;
        }

        for (int i = 1; i < h.length; i++)
        {
            if (h[i] == 0)
                System.out.print("\t" + i);
        }
    }
}
