package com.starter.datastructures;

public class S13_Stack_2_LinkedList
{
    Node top;

    class Node
    {
        int data;
        Node next;

        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S13_Stack_2_LinkedList ll = new S13_Stack_2_LinkedList();

        ll.push(5);
        ll.push(17);
        ll.push(8);

        ll.display();
        ll.peek();
        ll.peek(2);

        ll.pop();

        ll.push(22);

        ll.display();
    }

    private void display()
    {
        System.out.println();

        Node p = top;
        while (p != null)
        {
            System.out.print("\t" + p.data);
            p = p.next;
        }
    }

    private void pop()
    {
        if (!isEmpty())
        {
            Node p = top;
            top = top.next;
            int x = p.data;
            System.out.println("\n" + x + " is popped.");
        }
    }

    private boolean isEmpty()
    {
        if (top == null)
            return true;

        return false;
    }

    private void peek()
    {
        System.out.println("\n" + top.data);
    }

    private void peek(int pos)
    {
        Node p = top;

        for (int i = 0; i < pos - 1 && p != null; i++)
        {
            p = p.next;
        }

        if (p != null)
        {
            System.out.println("\n" + p.data);
        }
    }

    private void push(int val)
    {
        Node t = new Node(val);

        if (!isFull(t))
        {
            t.next = top;
            top = t;
        }
    }

    private boolean isFull(Node t)
    {
        if (t == null)
            return true;

        return false;
    }

}
