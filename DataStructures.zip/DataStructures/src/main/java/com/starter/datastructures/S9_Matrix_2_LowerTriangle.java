package com.starter.datastructures;

public class S9_Matrix_2_LowerTriangle
{

    public static void main(String[] args)
    {
        int[][] m = new int[][] { { 25, 0, 0, 0, 0 }, { 17, 45, 0, 0, 0 }, { 34, 98, 1, 0, 0 }, { 91, 20, 54, 85, 0 },
                { 28, 32, 51, 78, 6 } };
        int[] a = new int[15];
        
        rowMajor(m, a);
        
        int[][] n = new int[][] { { 25, 32, 67 }, { 17, 45, 12 }, { 34, 98, 5 }};
        int[] b = new int[9];
        
        colMajor(n, b);
    }

    /**
     *  m[j][i] 
     */
    private static void colMajor(int[][] m, int[] a)
    {
        int k=0; 
        
        // Set from 2D -> 1D
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (i >= j)
                {
//                    int index = n*(j-1)-(j-2)*(j-1)/2 + (i-j)
                    a[k++] = m[j][i];                                                // FYI
                }
            }
        }

        for (int i = 0; i < 6; i++)
            System.out.print("\t" + a[i]);

        System.out.println("\nMatrix - ");

        k=0;                                                                        // FYI
        
        // Print 1D -> 2D format
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                 if (i >= j)                                                        // FYI
                System.out.print("\t" + a[k++]);
                 else
                 System.out.print("\t" + 0);
            }
            System.out.println();
        }        
    }

    /**
     * m[i][j]
     * 
     */
    private static void rowMajor(int[][] m, int[] a)
    {
        int k=0;
        
        // Set from 2D -> 1D
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if (i >= j)
                {
//                    int index = i * (i - 1) / 2 + j - 1;
                    a[k++] = m[i][j];                                                           // FYI
                }
            }
        }

        for (int i = 0; i < 15; i++)
            System.out.print("\t" + a[i]);

        System.out.println("\nMatrix - ");

        k=0;
        
        // Print 1D -> 2D format
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                 if (i >= j)                                                                // FYI
                System.out.print("\t" + a[k++]);
                 else
                 System.out.print("\t" + 0);
            }
            System.out.println();
        }        
    }

}
