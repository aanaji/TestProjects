package com.starter.datastructures;

public class S16_BST_1_BinarySearchTree {
	TreeNode root;

	static class TreeNode {
		TreeNode left;
		int data;
		TreeNode right;

		TreeNode(int data) {
			this.data = data;
			left = null;
			right = null;
		}
	}

	public static TreeNode recurssionSearch(TreeNode node, int key) {

		TreeNode element = null;
		if (node == null) {
			return null;
		}

		if (node.data == key) {
			return node;
		}

		if (key < node.data) {
			element = recurssionSearch(node.left, key);
		} else {
			element = recurssionSearch(node.right, key);
		}

		return element;
	}

	public static TreeNode iterativeSearch(TreeNode node, int key) {

		while (node != null) {

			if (node.data == key) {
				return node;
			}

			if (key < node.data) {
				node = node.left;
			} else {
				node = node.right;
			}
		}
		return null;
	}

	public static void iterativeInsertAna(TreeNode node, int key) {

		TreeNode previous = null;

		while (node != null) {

			previous = node;

			if (node.data == key) {
				return;
			}

			if (key < node.data) {
				node = node.left;
			} else {
				node = node.right;
			}
		}

		TreeNode newNode = new TreeNode(key);
		newNode.left = newNode.right = null;

		if (previous == null) {
			node = newNode;
		} else if (key < previous.data) {
			previous.left = newNode;
		} else {
			previous.right = newNode;
		}
	}

	public static void main(String[] args) {
		S16_BST_1_BinarySearchTree tree = new S16_BST_1_BinarySearchTree();
		tree.root = new TreeNode(40);
		tree.root.left = new TreeNode(30);
		tree.root.right = new TreeNode(50);

		tree.root.left.left = new TreeNode(25);
		tree.root.left.right = new TreeNode(35);

		tree.root.left.right.left = new TreeNode(32);
		tree.root.left.right.right = new TreeNode(37);

		iterativeInsert(tree.root, 55);

		tree.inOrder(tree.root); // FYI : InOrder gives Sorted Order

		TreeNode root = null;

		root = recursiveInsert(root, 40);
		recursiveInsert(root, 30);
		recursiveInsert(root, 50);
		recursiveInsert(root, 20);
		recursiveInsert(root, 10);
		recursiveInsert(root, 60);

		System.out.println();
		System.out.println(iterativeSearch(root, 40).data);
		// System.out.println(recurssionSearch(root, 800));

		tree.inOrder(root);
	}

	private static void iterativeInsert(TreeNode t, int key) {
		TreeNode r = null;

		while (t != null) {
			r = t;

			if (key == t.data)
				return;

			else if (key < t.data)
				t = t.left;

			else
				t = t.right;
		}

		TreeNode p = new TreeNode(key);
		p.left = p.right = null;

		if (p.data < r.data)
			r.left = p;

		else
			r.right = p;
	}

	private static TreeNode recursiveInsert(TreeNode p, int key) {
		TreeNode t;

		if (p == null) {
			t = new TreeNode(key);
			t.left = t.right = null;
			return t;
		}
//        else
//        {
		if (key < p.data)
			p.left = recursiveInsert(p.left, key);

		else if (key > p.data)
			p.right = recursiveInsert(p.right, key);
//        }
		return p;
	}

	void inOrder(TreeNode node) {
		if (node == null)
			return;

		inOrder(node.left);
		System.out.print(node.data + " ");
		inOrder(node.right);
	}

}