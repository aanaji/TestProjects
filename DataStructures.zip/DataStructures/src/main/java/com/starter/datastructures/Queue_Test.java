package com.starter.datastructures;

import java.util.ArrayDeque;
import java.util.Queue;

public class Queue_Test {

	public static void main(String[] args) {
		Queue<String> dataQueue = new ArrayDeque<String>();

		dataQueue.add("Ananda");
		dataQueue.add("Anaji");

		// dataQueue.iterator().forEachRemaining(action);
	}
}
