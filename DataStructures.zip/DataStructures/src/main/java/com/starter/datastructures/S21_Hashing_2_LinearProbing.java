package com.starter.datastructures;

public class S21_Hashing_2_LinearProbing
{
    static int SIZE = 10;

    public static void main(String[] args)
    {
        int[] ht = new int[10];

        insert(ht, 12);
        insert(ht, 25);
        insert(ht, 35);
        insert(ht, 26);

        System.out.println("\nKey found at : " + search(ht, 35));
    }

    static int hash(int key)
    {
        return key % SIZE;
    }

    static int probe(int H[], int key)  // linearly check where to insert
    {
        int index = hash(key);
        int i = 0;
        while (H[(index + i) % SIZE] != 0)  // find next free space
            i++;
        return (index + i) % SIZE;
    }

    static void insert(int H[], int key)
    {
        int index = hash(key);
        
        if (H[index] != 0)  // check if free 
            index = probe(H, key);
        
        H[index] = key;
    }

    static int search(int H[], int key)
    {
        int index = hash(key);
        int i = 0;

        while (H[(index + i) % SIZE] != key)    // check if same key, if not, linear probing
            i++;

        return (index + i) % SIZE;
    }

}
