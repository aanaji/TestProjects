package com.starter.datastructures;

import java.util.LinkedList;
import java.util.Queue;

public class S15_Tree_3_BinaryTree_Level {
	static class TreeNode {
		TreeNode left;
		int data;
		TreeNode right;

		TreeNode(int data) {
			this.data = data;
			left = null;
			right = null;
		}
	}

	static void printLevelOrder(TreeNode root) {
		if (root == null)
			return;

		Queue<TreeNode> q = new LinkedList<>(); // FYI
		q.add(root); // FYI

		while (!q.isEmpty()) {
			TreeNode p = q.poll(); // FYI
			System.out.print(p.data + " ");

			if (p.left != null) {
				q.add(p.left);
			}

			if (p.right != null) {
				q.add(p.right);
			}
		}
	}

	public static void main(String[] args) {
		TreeNode root = new TreeNode(1);
		root.left = new TreeNode(4);
		root.right = new TreeNode(5);
		root.left.left = new TreeNode(6);
		root.left.right = new TreeNode(2);
		root.right.right = new TreeNode(3);

		printLevelOrder(root);

	}

}