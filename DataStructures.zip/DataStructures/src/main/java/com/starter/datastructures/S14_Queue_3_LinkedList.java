package com.starter.datastructures;

class LinkedNode                                            // FYI
{
    int data;
    LinkedNode next;
    
    LinkedNode(int data)
    {
        this.data = data;
    }
}

class LinkedQueue
{
    LinkedNode front, rear;                                 // FYI

    LinkedQueue()
    {
        front = rear = null;                                  // FYI
    }

    void enqueue(int val)
    {
        LinkedNode t = new LinkedNode(val);
        
        if(t == null)
        {
            System.out.println("Queue is full");
        }
        else
        {
            if(front == null)
            {
                front = rear = t;
            }
            else
            {
                rear.next = t;
                rear = t;
            }
        }
    }

    void dequeue()
    {
        // int x = -1;
        if (front == null)
        {
            System.out.println("Queue is empty");
        }
        else
        {
            // LinkedNode p = front;
            front = front.next;
            // x = p.data; free(p); // return x;
        }
    }
    
    int deQueue()
    {
        int x = -1;
        
        if (front == null)
        {
            System.out.println("Queue is empty");
        }
        else
        {
             LinkedNode p = front;
             front = front.next;
             x = p.data;  
        }
        
        return x;
    }

    void display()
    {
        if (front == null)
        {
            System.out.println("Queue is Empty");
        }
        else
        {
            LinkedNode p = front;
            while( p != null)
            {
                System.out.println(p.data);
                p = p.next;
            }
        }
    }
}

public class S14_Queue_3_LinkedList
{
    public static void main(String[] args)
    {
        LinkedQueue q = new LinkedQueue();                                     // FYI
        q.display();

        q.enqueue(20);
        q.enqueue(30);
        q.enqueue(40);
        q.enqueue(50);

        q.display();

        q.enqueue(60);

        q.display();

        q.dequeue();
        q.dequeue();
        System.out.printf("After two node deletion");

        q.enqueue(70);
        q.enqueue(65);
        
        q.display();

    }

}
