package com.starter.datastructures;

import java.util.Arrays;

public class S20_Sorting_9_Shell
{
    public static void main(String[] args)
    {
        int[] arr = { 11, 13, 7, 12, 16, 9, 24, 5, 10, 3 };

        System.out.println("Before Shell Sort - ");
        System.out.print(" " + Arrays.toString(arr));

        shellSort(arr, arr.length);

        System.out.println("\nAfter Shell Sort - ");
        System.out.print(" " + Arrays.toString(arr));
    }

    private static void shellSort(int arr[], int n)
    {
        int gap, i, j, temp;

        for (gap = n / 2; gap >= 1; gap /= 2)
        {
            for (i = gap; i < n; i++)
            {
                temp = arr[i];
                j = i - gap;
                while (j >= 0 && arr[j] > temp)
                {
                    arr[j + gap] = arr[j];
                    j = j - gap;
                }
                arr[j + gap] = temp;
            }
        }
    }

}
