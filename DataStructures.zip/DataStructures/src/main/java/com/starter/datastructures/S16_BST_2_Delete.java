package com.starter.datastructures;

public class S16_BST_2_Delete {
	TreeNode root;

	static class TreeNode {
		TreeNode left;
		int data;
		TreeNode right;

		TreeNode(int data) {
			this.data = data;
			left = null;
			right = null;
		}
	}

	public TreeNode recursiveDelete2(TreeNode node, int key) {

		if (node == null) {
			return null;
		}
		TreeNode temp;
		if (node.left == null && node.right == null) {

			if (node == root) {
				root = null;
			}
			return null;
		}

		if (key < node.data) {
			node.left = recursiveDelete2(node.left, key);
		} else if (key > node.data) {
			node.right = recursiveDelete2(node.right, key);
		} else {

			if (height(node.left) > height(node.right)) {
				temp = inPre(node.left);
				node.data = temp.data;
				node.left = recursiveDelete2(node.left, temp.data);
			} else {
				temp = inSucc(node.right);
				node.data = temp.data;
				node.right = recursiveDelete2(node.right, key);
			}
		}
		return node;
	}

	public static void main(String[] args) {
		S16_BST_2_Delete tree = new S16_BST_2_Delete();

		TreeNode root = null;
		root = recursiveInsert(root, 10);
		recursiveInsert(root, 5);
		recursiveInsert(root, 20);
		recursiveInsert(root, 20);
		recursiveInsert(root, 8);
		recursiveInsert(root, 30);

		tree.inOrder(root);

		tree.recursiveDelete(root, 20);

		System.out.println();
		tree.inOrder(root);

		TreeNode root2 = null;
		root2 = recursiveInsert(root2, 50);
		recursiveInsert(root2, 10);
		recursiveInsert(root2, 40);
		recursiveInsert(root2, 20);
		recursiveInsert(root2, 30);
		recursiveInsert(root2, 10);

		System.out.println();
		tree.inOrder(root2);

		tree.recursiveDelete(root2, 50);

		System.out.println();
		tree.inOrder(root2);
	}

	private TreeNode recursiveDelete(TreeNode p, int key) {
		TreeNode q;

		if (p == null)
			return null;

		if (p.left == null && p.right == null) // FYI
		{
			if (p == root)
				root = null;

			// free(p);

			return null;
		}

		if (key < p.data)
			p.left = recursiveDelete(p.left, key);

		else if (key > p.data)
			p.right = recursiveDelete(p.right, key);

		else {
			if (height(p.left) > height(p.right)) // FYI
			{
				q = inPre(p.left); // FYI
				p.data = q.data;
				p.left = recursiveDelete(p.left, q.data); // FYI
			} else {
				q = inSucc(p.right);
				p.data = q.data;
				p.right = recursiveDelete(p.right, q.data); // FYI
			}
		}

		return p;
	}

	private TreeNode inPre(TreeNode p) {
		while (p != null && p.right != null) // FYI
			p = p.right;

		return p;
	}

	private TreeNode inSucc(TreeNode p) {
		while (p != null && p.left != null) // FYI
			p = p.left;

		return p;
	}

	private int height(TreeNode p) {
		if (p == null)
			return 0;

		int x = height(p.left);
		int y = height(p.right);

		return x > y ? x + 1 : y + 1; // FYI
	}

	private static TreeNode recursiveInsert(TreeNode p, int key) {
		TreeNode t;

		if (p == null) {
			t = new TreeNode(key);
			t.left = t.right = null;
			return t;
		} else {
			if (key < p.data)
				p.left = recursiveInsert(p.left, key);

			else if (key > p.data)
				p.right = recursiveInsert(p.right, key);
		}
		return p;
	}

	public TreeNode recurssionInsert(TreeNode node, int key) {
		if (node == null) {
			TreeNode newNode = new TreeNode(key);
			newNode.left = newNode.right = null;
			return newNode;
		}

		if (key < node.data) {
			node.left = recurssionInsert(node.left, key);
		} else if (key > node.data) {
			node.right = recurssionInsert(node.right, key);
		}

		return node;
	}

	void inOrder(TreeNode node) {
		if (node == null)
			return;

		inOrder(node.left);
		System.out.print(node.data + " ");
		inOrder(node.right);
	}

}