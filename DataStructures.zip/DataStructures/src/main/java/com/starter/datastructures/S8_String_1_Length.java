package com.starter.datastructures;

public class S8_String_1_Length
{

    public static void main(String[] args)
    {
        char[] arr = { 'w', 'e', 'l', 'c', 'o', 'm', 'e' };
        System.out.println("Length : " + arr.length);

        int count = 0;
        for (char c : arr)
            count++;
        System.out.println("Length : " + count);

        String str = "welcome";
        count = 0;
        char[] arrStr = str.toCharArray();                      // toCharArray
        for (char c : arrStr)
            count++;
        System.out.println("Length : " + count);

        System.out.println("Length : " + str.lastIndexOf(""));  // lastIndexOf
    }

}
