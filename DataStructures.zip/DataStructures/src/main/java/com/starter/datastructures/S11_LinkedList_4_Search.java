package com.starter.datastructures;

public class S11_LinkedList_4_Search
{
    Node first;

    static class Node
    {
        int data;
        Node next;

        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_4_Search ll = new S11_LinkedList_4_Search();

        ll.first = new Node(1);
        Node second = new Node(2);
        Node third = new Node(3);

        ll.first.next = second;
        second.next = third;

        Node ele = ll.search(ll.first, 3);

        System.out.println(ele);

        ele = ll.recursiveSearch(ll.first, 3);

        System.out.println(ele);

        ele = ll.improvisedSearch(ll.first, 3);

        System.out.println(ele);
    }

    private Node search(Node p, int key)
    {
        while (p != null)
        {
            if (key == p.data)
                return p;
            p = p.next;
        }
        return null;
    }

    private Node recursiveSearch(Node p, int key)
    {
        if (p == null)
            return null;

        if (key == p.data)
            return p;

        return recursiveSearch(p.next, key);
    }

    private Node improvisedSearch(Node p, int key)
    {
        Node q = null;
        while (p != null)
        {
            if (key == p.data)
            {
                q.next = p.next;
                p.next = first;
                first = p;
                return p;
            }
            q = p;
            p = p.next;
        }
        return null;
    }
}
