package com.starter.datastructures;

public class S11_LinkedList_1_Display {
	Node head;

	static class Node<E> {
		E data;
		Node next;

		Node(E data) {
			this.data = data;
		}
	}

	public static void main(String[] args) {
		S11_LinkedList_1_Display ll = new S11_LinkedList_1_Display();

		ll.head = new Node(1);

		Node second = new Node(2);
		Node third = new Node(3);

		ll.head.next = second;
		second.next = third;

		ll.printLL();

		System.out.println();

		ll.printRecursiveLL(ll.head);

		System.out.println();

		ll.printRecursiveLLReverse(ll.head);
	}

	public void print() {

		Node n = head;
		while (n != null) {
			System.out.println(n.data);
			n = n.next;
		}
	}

	private void printLL() {
		Node n = head;

		while (n != null) // FYI : while
		{
			System.out.print("\t" + n.data);
			n = n.next;
		}
	}

	private void printRecursiveLL(Node n) {
		if (n != null) // FYI : recursive : if
		{
			System.out.print("\t" + n.data);
			printRecursiveLL(n.next);
		}
	}

	private void printRecursiveLLReverse(Node n) {
		if (n != null) // FYI : recursive : if
		{
			printRecursiveLLReverse(n.next);
			System.out.print("\t" + n.data);
		}
	}

}
