package com.starter.datastructures.inheritance;

public class Client {

	public static void main(String[] args) {

		ParentClass classs = new ChildClass();

		System.out.println(classs.populateOrder());
	}
}
