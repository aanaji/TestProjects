package com.starter.datastructures.inheritance;

public class ChildClass extends ParentClass {

	@Override
	public Order populateOrder() {

		Order order = super.populateOrder();

		order.setOrderTotal("100");
		return order;
	}
}
