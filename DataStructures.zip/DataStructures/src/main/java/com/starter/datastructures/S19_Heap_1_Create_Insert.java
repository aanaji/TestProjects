package com.starter.datastructures;

public class S19_Heap_1_Create_Insert {

	public static void main(String[] args) {
		int[] A = { 0, 10, 20, 30, 25, 5, 40, 35 };
		int i;

		for (i = 2; i <= 7; i++) // FYI
			insert(A, i);

		System.out.println("Heap - ");
		for (i = 1; i <= 7; i++)
			System.out.print(" " + A[i]);
	}

	private static void insert(int[] A, int n) // FYI
	{
		int temp, i = n;
		temp = A[n];

		// Compare and Move

		while (i > 1 && temp < A[i / 2]) // FYI & '<' : MIN HEAP
		{
			A[i] = A[i / 2];
			i = i / 2;
		}
		A[i] = temp;
	}

	void inset1(int[] list, int j, int key) {

		list[j] = key;
		int i = j;

		while (i > 1) {

			i = i / 2;

			if (list[i] < key) {
				// swap
			} else {
				break;
			}
		}
		list[i] = key;
	}

	void delete(int[] a, int size) {
		int i = 1;
		int j = 2;

		int deletedElement = a[0];
		a[0] = a[size - 1];

		while (j <= size - 1) {

			if (j < size && a[j] < a[j + 1]) {
				j = j + 1;
			}

			if (a[i] < a[j]) {
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
				i = j;

				j = 2 * i;
			} else {
				break;
			}

		}

		a[size - 1] = deletedElement;

	}
	// Heap is complete binary tree

}