package com.starter.datastructures;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// A class to store a graph edge
public class SnakeAndLadderGame {
	// Perform BFS on graph `g` starting from a given source vertex
	public static void BFS(Graph g, int source, int N) {
		// create a queue for doing BFS
		java.util.Queue<Node123> q = new ArrayDeque<>();

		// to keep track of whether a vertex is discovered or not
		boolean[] discovered = new boolean[N + 1];

		// mark the source vertex as discovered
		discovered[source] = true;

		// assign the minimum distance of the source vertex as 0 and
		// enqueue it
		Node123 Node123 = new Node123(source, 0);
		q.add(Node123);

		// loop till queue is empty
		while (!q.isEmpty()) {
			// dequeue front Node123
			Node123 = q.poll();

			// Stop BFS if the last Node123 is reached
			if (Node123.ver == N) {
				System.out.println(Node123.min_dist);
				break;
			}

			// do for every adjacent Node123 of the current Node123
			for (int u : g.adjList.get(Node123.ver)) {
				if (!discovered[u]) {
					// mark it as discovered and enqueue it
					discovered[u] = true;

					// assign the minimum distance of the current Node123
					// one more than the minimum distance of the parent Node123
					Node123 n = new Node123(u, Node123.min_dist + 1);
					q.add(n);
				}
			}
		}
	}

	public static void findSolution(Map<Integer, Integer> ladder, Map<Integer, Integer> snake) {
		// total number of nodes in the graph
		int N = 10 * 10;

		// find all edges involved and store them in a list
		List<Edge> edges = new ArrayList<>();
		for (int i = 0; i < N; i++) {
			for (int j = 1; j <= 6 && i + j <= N; j++) {
				int src = i;

				// update destination if there is any ladder
				// or snake from the current position.
				int dest;

				int _ladder = (ladder.get(i + j) != null) ? ladder.get(i + j) : 0;
				int _snake = (snake.get(i + j) != null) ? snake.get(i + j) : 0;

				if (_ladder != 0 || _snake != 0) {
					dest = _ladder + _snake;
				} else {
					dest = i + j;
				}

				// add an edge from src to dest
				edges.add(new Edge(src, dest));
			}
		}

		// construct a directed graph
		Graph g = new Graph(edges, N);

		// Find the shortest path between 1 and 100 using BFS
		BFS(g, 0, N);
	}

	public static void main(String[] args) {
		// snakes and ladders are represented using a map.
		Map<Integer, Integer> ladder = new HashMap();
		Map<Integer, Integer> snake = new HashMap();

		// insert ladders into the map
		ladder.put(1, 38);
		ladder.put(4, 14);
		ladder.put(9, 31);
		ladder.put(21, 42);
		ladder.put(28, 84);
		ladder.put(51, 67);
		ladder.put(72, 91);
		ladder.put(80, 99);

		// insert snakes into the map
		snake.put(17, 7);
		snake.put(54, 34);
		snake.put(62, 19);
		snake.put(64, 60);
		snake.put(87, 36);
		snake.put(93, 73);
		snake.put(95, 75);
		snake.put(98, 79);

		findSolution(ladder, snake);
	}
}

class Edge {
	int src, dest;

	public Edge(int src, int dest) {
		this.src = src;
		this.dest = dest;
	}
}

// A queue Node123
class Node123 {
	// stores number associated with graph Node123
	int ver;

	// `min_dist` stores the minimum distance of a Node123 from the starting vertex
	int min_dist;

	public Node123(int ver, int min_dist) {
		this.ver = ver;
		this.min_dist = min_dist;
	}
}

// A class to represent a graph object
class Graph {
	// A list of lists to represent an adjacency list
	List<List<Integer>> adjList = null;

	// Constructor
	Graph(List<Edge> edges, int N) {
		adjList = new ArrayList<>();
		for (int i = 0; i < N; i++) {
			adjList.add(new ArrayList<>());
		}

		// add edges to the graph
		for (Edge edge : edges) {
			int src = edge.src;
			int dest = edge.dest;

			// Please note that the graph is directed
			adjList.get(src).add(dest);
		}
	}
}
