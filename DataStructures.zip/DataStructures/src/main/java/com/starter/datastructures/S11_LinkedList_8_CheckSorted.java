package com.starter.datastructures;

public class S11_LinkedList_8_CheckSorted
{
    Node first, last;

    static class Node
    {
        int data;
        Node next;

        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_8_CheckSorted ll = new S11_LinkedList_8_CheckSorted();

        ll.insertLast(3);
        ll.insertLast(6);
        ll.insertLast(7);
        ll.insertLast(6);
        ll.insertLast(15);

        ll.printLL();

        boolean result = ll.checkSorted();
        System.out.println(result);
    }

    private boolean checkSorted()
    {
        int x = -32768;
        Node p = first;

        while (p != null)
        {
            if (p.data < x)
                return false;

            x = p.data;
            p = p.next;
        }
        return true;
    }

    private void insertLast(int val)
    {
        Node t = new Node(val);

        if (first == null)
        {
            first = last = t;
        }
        else
        {
            last.next = t;
            last = t;
        }
    }

    private void printLL()
    {
        System.out.println();
        Node n = first;

        while (n != null) // FYI : while
        {
            System.out.print("\t" + n.data);
            n = n.next;
        }
    }
}
