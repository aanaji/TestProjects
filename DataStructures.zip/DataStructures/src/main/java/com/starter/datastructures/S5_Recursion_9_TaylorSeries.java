package com.starter.datastructures;

public class S5_Recursion_9_TaylorSeries
{

    static double p = 1, f = 1;

    public static void main(String[] args)
    {
        int x = 4, n = 15;
        double result = recursiveTaylor(x, n);
        System.out.println("Result : " + result);
    }

    private static double recursiveTaylor(int x, int n)
    {
        double r;

        if (n == 0)
            return 1;

        r = recursiveTaylor(x, n - 1);
        p = p * x;
        f = f * n;
        return r + p / f;
    }

}
