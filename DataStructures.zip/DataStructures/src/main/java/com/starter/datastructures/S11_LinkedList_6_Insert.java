package com.starter.datastructures;

public class S11_LinkedList_6_Insert
{
    Node first, last;

    static class Node
    {
        int data;
        Node next;

        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_6_Insert ll = new S11_LinkedList_6_Insert();

        ll.insertLast(3);
        ll.insertLast(6);
        ll.insertLast(7);
        ll.insertLast(9);
        ll.insertLast(15);

        ll.printLL();

        ll.insertSorted(2);
        ll.insertSorted(8);
        ll.insertSorted(20);

        ll.printLL();
    }

    private void insertSorted(int val)
    {
        Node p = first;
        Node q = null;

        Node t = new Node(val);

        if (first == null)
        {
            first = t;
        }
        else
        {
            while (p != null && p.data < val)
            {
                q = p;
                p = p.next;
            }

            if (p == first)
            {
                t.next = first;
                first = t;
            }
            else
            {
                t.next = q.next;
                q.next = t;
            }
        }
    }

    private void insertLast(int val)
    {
        Node t = new Node(val);

        if (first == null)
        {
            first = last = t;
        }
        else
        {
            last.next = t;
            last = t;
        }
    }

    private void printLL()
    {
        System.out.println();
        Node n = first;

        while (n != null) // FYI : while
        {
            System.out.print("\t" + n.data);
            n = n.next;
        }
    }
}
