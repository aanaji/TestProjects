package com.starter.datastructures;

public class S20_Sorting_1_Bubble
{

    public static void main(String[] args)
    {
        int[] A = { 8, 8, 10, 5 };

        int i;

        System.out.println("Before Bubble Sort - ");
        for (i = 0; i < A.length; i++)
            System.out.print(" " + A[i]);

        bubbleSort(A);

        System.out.println("\nAfter Bubble Sort - ");
        for (i = 0; i < A.length; i++)
            System.out.print(" " + A[i]);
    }

    private static void bubbleSort(int[] arr)
    {
        int flag;

        for (int i = 0; i < arr.length; i++)
        {
            flag = 0;                                                   // FYI

            for (int j = 0; j < arr.length - 1 - i; j++)                // FYI
            {
                if (arr[j] > arr[j + 1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;

                    flag = 1;
                }
            }

            if (flag == 0)
                break;
        }
    }
}