package com.starter.datastructures;

public class S13_Stack_6_Infix_Postfix_2
{
    Node top;

    class Node
    {
        char data;
        Node next;

        Node(char data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S13_Stack_6_Infix_Postfix_2 ll = new S13_Stack_6_Infix_Postfix_2();

//        ll.push('#');
        
        char[] infix = { '(', '(', 'a', '+', 'b', ')', '*', 'c', ')', '-', 'd', '^', 'e', '^', 'f', '\0' };

        ll.convert(infix);
    }

    private void convert(char[] infix)
    {
        char[] postfix = new char[infix.length+1];

        int i = 0, j = 0;

        while (infix[i] != '\0')
        {
            if (isOperand(infix[i]))
            {
                postfix[j++] = infix[i++];
            }
            else
            {
                if (isEmpty() || outPre(infix[i]) > inPre(stackTop()))          
                {   
                    push(infix[i++]);
                }
                else if (outPre(infix[i]) == inPre(stackTop()))                 // FYI
                {
                    pop();
                }
                else
                {
                    postfix[j++] = pop();
                }
            }
        }
        
        // pop out remaining char from stack
        
        while(!isEmpty())
        {
            char x = pop();
            
            if (x != ')')                                   // FYI
                postfix[j++] = x;
        }
        
        System.out.println(postfix);
    }

    private boolean isOperand(char c)
    {
        if (c == '+' || c == '-' || c == '*' || c == '/' || c =='^' || c =='(' || c ==')')
            return false;

        return true;
    }

    private int outPre(char c)                              // FYI
    {
        if (c == '+' || c == '-')
            return 1;

        if (c == '*' || c == '/')
            return 3;
        
        if(c == '^')
            return 6;
        
        if(c == '(')
            return 7;
        
        if(c == ')')
            return 0;

        return -1;
    }
    
    private int inPre(char c)                               // FYI
    {
        if (c == '+' || c == '-')
            return 2;

        if (c == '*' || c == '/')
            return 4;
        
        if(c == '^')
            return 5;
        
        if(c == '(')
            return 0;

        return -1;
    }

    private char stackTop()
    {
        return top.data;
    }

    private char pop()
    {
        char x = '\0';
        if (!isEmpty())
        {
            Node p = top;
            top = top.next;
            x = p.data;
        }
        return x;
    }

    private boolean isEmpty()
    {
        if (top == null)
            return true;

        return false;
    }

    private void push(char val)
    {
        Node t = new Node(val);

        if (!isFull(t))
        {
            t.next = top;
            top = t;
        }
    }

    private boolean isFull(Node t)
    {
        if (t == null)
            return true;

        return false;
    }

}
