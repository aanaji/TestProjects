package com.starter.datastructures;

public class S11_LinkedList_16_Circular_Delete
{
    Node head;
    int flag = 0;
    
    static class Node
    {
        int data;
        Node next;
        
        Node() 
        { }
        
        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_16_Circular_Delete ll = new S11_LinkedList_16_Circular_Delete();
        
        ll.head = new Node(8);
        
        Node second = new Node(3);
        Node third = new Node(4);
        
        ll.head.next = second;
        second.next = third;
        third.next = ll.head;
        
        ll.printCircularLL(ll.head);
        
        ll.deleteCircularLL(1);
        ll.deleteCircularLL(3);
        
        ll.printCircularLL(ll.head);
        
    }
    
    private void deleteCircularLL(int pos)
    {
        Node p;
        
        if(pos == 1)
        {
            p = head;                               // FYI
            
            while(p.next != head)                   
                p = p.next;
            
            if(p == head)                           // FYI : last node being deleted
                head = null;
            
            else
            {
                p.next = head.next;
                head = p.next;
            }
        }
        else
        {
            p = head;                                     // FYI
            
            for(int i=0; i<pos-2; i++)
                p = p.next;
            
            Node q = p.next;
            p.next = q.next;
        }
    }

    private void printCircularLL(Node p)
    {
        System.out.println();
        
        do                                        // FYI : do - while
        {
            System.out.print("\t" + p.data);
            p = p.next;
            
        } while( p != head);
    }

}
