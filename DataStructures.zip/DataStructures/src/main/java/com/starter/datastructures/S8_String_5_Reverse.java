package com.starter.datastructures;

public class S8_String_5_Reverse
{

    public static void main(String[] args)
    {
        char[] a = "Java".toCharArray();
        char[] b = new char[4];
        int i = 0, j = 0;
        for (; i < a.length; i++)
        {
        }
        i = i - 1;
        for (; i >= 0; i--, j++)
            b[j] = a[i];

        System.out.println(b);

        j = 0;
        i = 0;
        for (; j < a.length; j++)
        {
        }
        j = j - 1;
        for (; i < j; i++, j--)
        {
            char t = a[i];
            a[i] = a[j];
            a[j] = t;
        }
        System.out.println(a);
    }

}
