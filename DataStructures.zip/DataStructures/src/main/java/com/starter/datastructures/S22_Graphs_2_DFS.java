package com.starter.datastructures;

public class S22_Graphs_2_DFS
{
    static int[] visited = new int[8];

    public static void main(String[] args)
    {
        int A[][] = { { 0, 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 1, 1, 1, 0, 0, 0 }, { 0, 1, 0, 1, 0, 0, 0, 0 },
                { 0, 1, 1, 0, 1, 1, 0, 0 }, { 0, 1, 0, 1, 0, 1, 0, 0 }, { 0, 0, 0, 1, 1, 0, 1, 1 },
                { 0, 0, 0, 0, 0, 1, 0, 0 }, { 0, 0, 0, 0, 0, 1, 0, 0 } };

        DFS(4, A, 8);
    }

    static void DFS(int u, int A[][], int n)
    {
        if (visited[u] == 0)
        {
            System.out.println("\t" + u);
            visited[u] = 1;

            for (int v = 1; v < n; v++)
            {
                if (A[u][v] == 1)
                {
                    DFS(v, A, n);
                }
            }
        }
    }
}
