package com.starter.datastructures;

public class S20_Sorting_6_Count
{
    public static void main(String[] args)
    {
        int[] arr = { 6, 3, 9, 10, 15, 6, 8, 12, 3, 6 };
        int i;

        System.out.println("Before Count Sort - ");
        for (i = 0; i < arr.length; i++)
            System.out.print(" " + arr[i]);

        countSort(arr, arr.length);

        System.out.println("\nAfter Count Sort - ");
        for (i = 0; i < arr.length; i++)
            System.out.print(" " + arr[i]);
    }

    private static void countSort(int[] arr, int n)
    {
        int max, i, j;

        max = findMax(arr, n);
        int[] count = new int[max + 1];

        for (i = 0; i < max + 1; i++)
            count[i] = 0;

        for (i = 0; i < n; i++)
            count[arr[i]]++;

        i = 0;
        j = 0;

        while (i < max + 1)
        {
            if (count[i] > 0)
            {
                arr[j++] = i;
                count[i]--;
            }
            else
                i++;
        }
    }

    private static int findMax(int[] arr, int n)
    {
        int max = arr[0];

        for (int i = 1; i < n; i++)
            if (max < arr[i])
                max = arr[i];

        return max;
    }

}
