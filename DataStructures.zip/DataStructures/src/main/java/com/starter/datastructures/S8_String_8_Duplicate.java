package com.starter.datastructures;

public class S8_String_8_Duplicate
{

    public static void main(String[] args)
    {
        char[] a = "finding".toCharArray();

        // Hashing
        int[] h = new int[26];
        for (int i = 0; i < a.length; i++)
        {
            h[a[i] - 97]++;
        }
        for (int i = 0; i < 26; i++)
        {
            if (h[i] > 1)
            {
                char ch = (char) (i + 97);
                System.out.println(ch + " appears " + h[i] + " times.");
            }
        }
        
        // Bitwise
        long h1=0,x=0;
        
        for (int i = 0; i < a.length; i++)
        {
            x = 1;
            x = x << a[i] - 97;

            if ((x & h1) > 0)
            {
                System.out.println("Duplicate found : " + a[i]);
            }
            else
            {
                h1 = x | h1;
            }
        }
    }

}
