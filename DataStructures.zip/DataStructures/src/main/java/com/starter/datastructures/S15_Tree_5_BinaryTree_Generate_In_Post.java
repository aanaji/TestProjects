package com.starter.datastructures;

public class S15_Tree_5_BinaryTree_Generate_In_Post
{
    TreeNode root;

    static class TreeNode
    {
        TreeNode left;
        int data; 
        TreeNode right;

        TreeNode(int data)
        {
            this.data = data;
            left = null;
            right = null;
        }
    }

    class Index                                 //  FYI 
    {
        int index;
    }

    public static void main(String[] args)
    {
        S15_Tree_5_BinaryTree_Generate_In_Post tree = new S15_Tree_5_BinaryTree_Generate_In_Post();

        int in[] = new int[] { 4, 8, 2, 5, 1, 6, 3, 7 };
        int post[] = new int[] { 8, 4, 5, 2, 6, 7, 3, 1 };

        int n = in.length;
        TreeNode root = tree.buildTree(in, post, n);
        System.out.println("Preorder of the constructed tree : ");
        tree.preOrder(root);

    }

    TreeNode buildUtil(int in[], int post[], int inStrt, int inEnd, Index pIndex)
    {
        if (inStrt > inEnd)
            return null;

        TreeNode node = new TreeNode(post[pIndex.index]);
        (pIndex.index)--;                                           // FYI

        if (inStrt == inEnd)
            return node;

        int iIndex = search(in, inStrt, inEnd, node.data);

        node.left = buildUtil(in, post, inStrt, iIndex - 1, pIndex);
        node.right = buildUtil(in, post, iIndex + 1, inEnd, pIndex);

        return node;
    }

    TreeNode buildTree(int in[], int post[], int n)
    {
        Index pIndex = new Index();                                 // FYI
        pIndex.index = n - 1;
        return buildUtil(in, post, 0, n - 1, pIndex);               // FYI
    }

    int search(int arr[], int strt, int end, int value)
    {
        int i;
        for (i = strt; i <= end; i++)
        {
            if (arr[i] == value)
                break;
        }
        return i;
    }

    void preOrder(TreeNode node)
    {
        if (node == null)
            return;

        System.out.print(node.data + " ");
        preOrder(node.left);
        preOrder(node.right);
    }

}