package com.starter.datastructures;

public class S13_Stack_7_Infix_Postfix_Evaluation
{
    Node top;

    class Node
    {
        int data;                                                               // FYI

        Node next;

        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S13_Stack_7_Infix_Postfix_Evaluation ll = new S13_Stack_7_Infix_Postfix_Evaluation();

        char[] postfix = { '3', '5', '*', '6', '2', '/', '+', '4', '-', '\0' };

        ll.eval(postfix);
    }

    private void eval(char[] postfix)
    {
        int i, x1, x2, r = 0;

        for (i = 0; postfix[i] != '\0'; i++)
        {
            if (isOperand(postfix[i]))
            {
                push(postfix[i] - '0');                                             // FYI
            }
            else
            {
                x2 = pop();                                                        // FYI
                x1 = pop();

                switch (postfix[i])
                {
                    case '+':
                        r = x1 + x2;
                        break;

                    case '-':
                        r = x1 - x2;
                        break;

                    case '*':
                        r = x1 * x2;
                        break;

                    case '/':
                        r = x1 / x2;
                        break;
                }
                
                push(r);
            }
        }

        System.out.println(r);

    }

    private boolean isOperand(char c)
    {
        if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^' || c == '(' || c == ')')
            return false;

        return true;
    }

    private int pop()
    {
        int x = 0;
        if (!isEmpty())
        {
            Node p = top;
            top = top.next;
            x = p.data;
        }
        return x;
    }

    private boolean isEmpty()
    {
        if (top == null)
            return true;

        return false;
    }

    private void push(int i)
    {
        Node t = new Node(i);

        if (!isFull(t))
        {
            t.next = top;
            top = t;
        }
    }

    private boolean isFull(Node t)
    {
        if (t == null)
            return true;

        return false;
    }

}
