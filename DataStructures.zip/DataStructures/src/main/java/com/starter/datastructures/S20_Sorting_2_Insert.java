package com.starter.datastructures;

public class S20_Sorting_2_Insert
{

    public static void main(String[] args)
    {
        int[] A = { 8, 8, 10, 5 };

        int i;
        
        System.out.println("Before Insert Sort - ");
        for (i = 0; i < A.length; i++)
            System.out.print(" " + A[i]);

        insertSort(A);

        System.out.println("\nAfter Insert Sort - ");
        for (i = 0; i < A.length; i++)
            System.out.print(" " + A[i]);
    }

    private static void insertSort(int[] arr)
    {
        int i, j, x;

        for (i = 1; i < arr.length; i++)
        {
            j = i - 1;
            x = arr[i];

            while (j >= 0 && arr[j] > x)
            {
                arr[j + 1] = arr[j];
                j--;
            }

            arr[j + 1] = x;
        }
    }
}