package com.starter.datastructures;

public class S15_Tree_4_BinaryTree_Generate_In_Pre
{
    static int preIndex = 0;                            // FYI
    
    TreeNode root;
    
    static class TreeNode
    {
        TreeNode left;
        char data;                                      // FYI
        TreeNode right;

        TreeNode(char data)
        {
            this.data = data;
            left = null;
            right = null;
        }
    }

    public static void main(String[] args)
    {
        S15_Tree_4_BinaryTree_Generate_In_Pre tree = new S15_Tree_4_BinaryTree_Generate_In_Pre(); 
        
        char in[] = new char[] { 'D', 'B', 'E', 'A', 'F', 'C' }; 
        char pre[] = new char[] { 'A', 'B', 'D', 'E', 'C', 'F' }; 
        
        int len = in.length; 
        TreeNode root = tree.buildTree(in, pre, 0, len - 1); 
  
        System.out.println("Inorder traversal of constructed tree is : "); 
        tree.printInorder(root); 

    }
    
    TreeNode buildTree(char in[], char pre[], int inStrt, int inEnd) 
    { 
        if (inStrt > inEnd) 
            return null; 
  
        TreeNode tNode = new TreeNode(pre[preIndex++]); 
  
        if (inStrt == inEnd) 
            return tNode; 
  
        int inIndex = search(in, inStrt, inEnd, tNode.data); 
  
        tNode.left = buildTree(in, pre, inStrt, inIndex - 1); 
        tNode.right = buildTree(in, pre, inIndex + 1, inEnd); 
  
        return tNode; 
    } 
    
    int search(char arr[], int strt, int end, char value) 
    { 
        int i; 
        for (i = strt; i <= end; i++) { 
            if (arr[i] == value) 
                return i; 
        } 
        return i; 
    } 
    
    void printInorder(TreeNode node) 
    { 
        if (node == null) 
            return; 
  
        printInorder(node.left); 
        System.out.print(node.data + " "); 
        printInorder(node.right); 
    } 

}