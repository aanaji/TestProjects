package com.starter.datastructures;

public class S7_Array_6_CheckArraySort
{

    public static void main(String[] args)
    {
        int[] a = new int[10];
        int length = 0;
        for (int i = 0; i < 9; i++)
        {
            a[i] = i * 2;
            length++;
        }
        int key = 7;
        insertSort(a, key, length);

        System.out.println();
        int[] arr = { 4, 8, 13, 3, 23, 34, 45, 56, 67 };
        boolean checkSort = checkSort(arr);
        System.out.println(checkSort);

        System.out.println();
        int[] n = { -3, 0, 34, -12, 34, -89 };
        negativePositiveSide(n);
    }

    private static void insertSort(int[] a, int key, int len)
    {
        int i = len - 1;
        for (; i > 0; i--)
        {
            if (key < a[i])
            {
                a[i + 1] = a[i];
            }
            else
            {
                a[i + 1] = key;
                break;
            }
        }

        for (int k = 0; k < a.length; k++)
        {
            System.out.print("\t" + a[k]);
        }
    }

    private static boolean checkSort(int[] arr)
    {
        for (int i = 0; i < arr.length - 1; i++)
        {
            if (arr[i] > arr[i + 1])
                return false;
        }
        return true;
    }

    private static void negativePositiveSide(int[] n)
    {
        int i = 0, j = n.length - 1;

        while (i < j)
        {
            while (n[i] < 0)
                i++;

            while (n[j] >= 0)
                j--;

            if (i < j)
            {
                int temp = n[i];
                n[i] = n[j];
                n[j] = temp;
            }
        }

        for (int k = 0; k < n.length; k++)
        {
            System.out.print("\t" + n[k]);
        }
    }

}
