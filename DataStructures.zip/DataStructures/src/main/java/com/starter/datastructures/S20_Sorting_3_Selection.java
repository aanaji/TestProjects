package com.starter.datastructures;

public class S20_Sorting_3_Selection
{

    public static void main(String[] args)
    {
        int[] arr = { 8, 6, 3, 2, 5, 4 };
        int i;

        System.out.println("Before Selection Sort - ");
        for (i = 0; i < arr.length; i++)
            System.out.print(" " + arr[i]);

        selectionSort(arr, arr.length);

        System.out.println("\nAfter Selection Sort - ");
        for (i = 0; i < arr.length; i++)
            System.out.print(" " + arr[i]);
    }

    private static void selectionSort(int[] arr, int n)
    {
        int i, j, k;

        for (i = 0; i < n - 1; i++)
        {
            for (j = k = i; j < n; j++)
            {
                if (arr[j] < arr[k])
                {
                    k = j;
                }
            }

            int temp = arr[k];
            arr[k] = arr[i];
            arr[i] = temp;
        }
    }

}
