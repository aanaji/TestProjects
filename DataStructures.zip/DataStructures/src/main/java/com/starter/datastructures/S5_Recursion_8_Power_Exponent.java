package com.starter.datastructures;

public class S5_Recursion_8_Power_Exponent
{

    public static void main(String[] args)
    {
        int m = 2, n = -2;

        int result1 = recursivePower1(m, n);
        System.out.println("Result-1 : " + result1);

        m = 2; n = -2;
        double result2 = recursivePower2(m, n);
        System.out.println("Result-2 : " + result2);
    }

    private static int recursivePower1(int m, int n)
    {
        if (n <= 0)
            return 1;
        else
            return recursivePower1(m, n - 1) * m;
    }

    private static double recursivePower2(double m, double n)    // Reduced Complexity
    {
        if (n <= 0)
            return 1;

        if (n % 2 == 0)
            return recursivePower2(m * m, n / 2);
        else
            return recursivePower2(m * m, (n - 1)/2) * m;
    }

}
