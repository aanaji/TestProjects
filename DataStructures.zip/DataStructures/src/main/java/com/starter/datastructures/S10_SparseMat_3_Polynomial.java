package com.starter.datastructures;

public class S10_SparseMat_3_Polynomial
{
    public static void main(String[] args)
    {
        int p1[][] = { { 5, 2, 5 }, { 4, 2, 0 } };
        int p2[][] = { { 6, 5, 9, 2, 3 }, { 4, 3, 2, 1, 0 } };
        int p3[][] = new int[5][5];

        int i = 0, j = 0, k = 0;
        int m = 3, n = 5;

        int x=5;    // Evaluation
        
        // Addition
        while (i < m && j < n)
        {
            if (p1[1][i] > p2[1][j])
            {
                p3[0][k] = p1[0][i];
                p3[1][k] = p1[1][i];
                i++;
                k++;
            }
            else if (p2[1][j] > p1[1][i])
            {
                p3[0][k] = p2[0][j];
                p3[1][k] = p2[1][j];
                j++;
                k++;
            }
            else
            {
                p3[0][k] = p1[0][i] + p2[0][j];
                p3[1][k] = p2[1][j];
                i++;
                j++;
                k++;
            }
        }

        for (i = 0; i < k; i++)
        {
            System.out.println(p3[0][i] + " x to power of " + p3[1][i]);
        }
    }
}
