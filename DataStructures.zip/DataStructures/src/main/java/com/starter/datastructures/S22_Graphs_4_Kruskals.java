package com.starter.datastructures;

public class S22_Graphs_4_Kruskals
{
    static int I = 32767;

    static int V = 7;

    static int E = 8; // or 9

    public static void main(String[] args)
    {
        int edges[][] = { { 1, 1, 2, 2, 3, 4, 4, 5, 5 }, { 2, 6, 3, 7, 4, 5, 7, 6, 7 },
                { 25, 5, 12, 10, 8, 16, 14, 20, 18 } };

        kruskals(edges);
    }

    static void kruskals(int edges[][])
    {
        int i = 0;
        
        int[] included = new int[E];
        int[] set = { -1, -1, -1, -1, -1, -1, -1, -1 };
        int[][] T = new int[2][V - 1];

        while (i < V - 1)
        {
            int min = I;
            int u = 0;
            int v = 0;
            int k = 0;

            // Find a minimum cost edge
            for (int j = 0; j < E; j++)
            {
                if (included[j] == 0 && edges[2][j] < min)
                {
                    min = edges[2][j];
                    u = edges[0][j];
                    v = edges[1][j];
                    k = j;
                }
            }

            // Check if the selected min cost edge (u, v) forming a cycle or not
            if (find(u, set) != find(v, set))
            {
                T[0][i] = u;
                T[1][i] = v;

                // Perform union
                union(find(u, set), find(v, set), set);
                i++;
            }
            included[k] = 1;
        }

        print(T, edges);
    }

    // Set operations: Union and Find
    static void union(int u, int v, int s[])
    {
        if (s[u] < s[v])
        {
            s[u] += s[v];
            s[v] = u;
        }
        else
        {
            s[v] += s[u];
            s[u] = v;
        }
    }

    static int find(int u, int s[])
    {
        int x = u;
        int v = 0;

        while (s[x] > 0)
        {
            x = s[x];
        }

        while (u != x)
        {
            v = s[u];
            s[u] = x;
            u = v;
        }
        return x;
    }

    static void print(int T[][], int G[][])
    {
        System.out.print("\nMinimum Spanning Tree Edges (w/ cost)\n");

        for (int i = 0; i < V - 1; i++)
        {
            System.out.println("[" + T[0][i] + "]---[" + T[1][i] + "]");
        }
    }
}
