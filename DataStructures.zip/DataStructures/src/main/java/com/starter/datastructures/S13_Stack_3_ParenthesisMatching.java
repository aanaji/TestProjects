package com.starter.datastructures;

public class S13_Stack_3_ParenthesisMatching
{
    Node top;

    class Node
    {
        char data;                                      // FYI
        Node next;

        Node(char data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S13_Stack_3_ParenthesisMatching ll = new S13_Stack_3_ParenthesisMatching();

        char[] exp = { '(', '(', 'a', '+', 'b', ')', '*', '(', 'c', '+', 'd', ')', ')', ')' };

        ll.isBalanced(exp);
    }

    private void isBalanced(char[] exp)
    {
        for(int i=0; i<exp.length; i++)
        {
            if(exp[i] == '(')
            {
                push(exp[i]);
            }
            else if (exp[i] == ')')
            {
                if(isEmpty())
                {
                    System.out.println("Not balanced");
                    return;
                }
                else
                {
                    pop();
                }
            }
        }
        
        if(isEmpty())
        {
            System.out.println("Balanced");
        }
        else
        {
            System.out.println("Not balanced");
        }
    }

    private void pop()
    {
        if (!isEmpty())
        {
            Node p = top;
            top = top.next;
            char x = p.data;
            System.out.println("\n" + x + " is popped.");
        }
    }

    private boolean isEmpty()
    {
        if (top == null)
            return true;

        return false;
    }

    private void push(char val)
    {
        Node t = new Node(val);

        if (!isFull(t))
        {
            t.next = top;
            top = t;
        }
    }

    private boolean isFull(Node t)
    {
        if (t == null)
            return true;

        return false;
    }

}
