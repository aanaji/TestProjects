package com.starter.datastructures;

public class S10_SparseMat_1_Display
{
    
    // 3-col representation
    
    public static void main(String[] args)
    {
        int sparseMatrix[][] = { { 0, 0, 3, 0, 4 }, { 0, 0, 5, 7, 0 }, { 0, 0, 0, 0, 0 }, { 0, 2, 6, 0, 0 } };

        int nonZero = 0;

        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 5; j++)
                if (sparseMatrix[i][j] != 0)
                    nonZero++;

        int arr[][] = new int[3][nonZero];

        int k = 0;

        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 5; j++)
                if (sparseMatrix[i][j] != 0)
                {
                    arr[0][k] = i;
                    arr[1][k] = j;
                    arr[2][k] = sparseMatrix[i][j];
                    k++;
                }

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < nonZero; j++)
            {
                System.out.print(arr[i][j]);
            }
            System.out.println();
        }

    }

}
