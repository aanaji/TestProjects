package com.starter.datastructures;

public class S22_Graphs_3_Prims
{
    static int I = 32767;

    static int V = 8;

    public static void main(String[] args)
    {
        int cost[][] = { { I, I, I, I, I, I, I, I }, { I, I, 25, I, I, I, 5, I }, { I, 25, I, 12, I, I, I, 10 },
                { I, I, 12, I, 8, I, I, I }, { I, I, I, 8, I, 16, I, 14 }, { I, I, I, I, 16, I, 20, 18 },
                { I, 5, I, I, I, 20, I, I }, { I, I, 10, I, 14, 18, I, I } };

        prims(cost, cost.length - 1);
    }

    static void prims(int G[][], int n)
    {
        int u = 0;
        int v = 0;
        int min = I;
        int[] near = new int[V];
        int[][] T = new int[2][V - 2];

        // Initial: Find min cost edge
        for (int i = 1; i < V; i++)
        {
            near[i] = I; // Initialize near array with INFINITY
            for (int j = i; j < V; j++)
            {
                if (G[i][j] < min)
                {
                    min = G[i][j];
                    u = i;
                    v = j;
                }
            }
        }
        T[0][0] = u;
        T[1][0] = v;
        near[u] = near[v] = 0;

        // Initialize near array to near min cost edges
        for (int i = 1; i < V; i++)
        {
            if (near[i] != 0)
            {
                if (G[i][u] < G[i][v])
                {
                    near[i] = u;
                }
                else
                {
                    near[i] = v;
                }
            }
        }

        // Repeat
        for (int i = 1; i < n - 1; i++)
        {
            int k = 0;
            min = I;
            for (int j = 1; j < V; j++)
            {
                if (near[j] != 0 && G[j][near[j]] < min)
                {
                    k = j;
                    min = G[j][near[j]];
                }
            }
            T[0][i] = k;
            T[1][i] = near[k];
            near[k] = 0;

            // Update near array to near min cost edges
            for (int j = 1; j < V; j++)
            {
                if (near[j] != 0 && G[j][k] < G[j][near[j]])
                {
                    near[j] = k;
                }
            }
        }

        print(T, G);
    }

    static void print(int T[][], int G[][])
    {
        System.out.print("\nMinimum Spanning Tree Edges (w/ cost)\n");
        int sum = 0;

        for (int i = 0; i < V - 2; i++)
        {
            int c = G[T[0][i]][T[1][i]];
            System.out.println("[" + T[0][i] + "]---[" + T[1][i] + "] cost: " + c);
            sum += c;
        }

        System.out.print("\nTotal cost of MST: " + sum);
    }
}
