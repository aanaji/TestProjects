package com.starter.datastructures;

public class S8_String_9_Permutation
{

    public static void main(String[] args)
    {
        String s = "ABC";
        recursivePerm(s, 0, s.length() - 1);
    }

    private static void recursivePerm(String s, int l, int h)
    {
        int i;
        if (l == h)
            System.out.println(s);

        else
        {
            for (i = l; i <= h; i++)
            {
                s = swap(s, l, i);
                recursivePerm(s, l + 1, h);
                s = swap(s, l, i);
            }
        }
    }

    public static String swap(String a, int i, int j)
    {
        char temp;
        char[] charArray = a.toCharArray();
        
        temp = charArray[i];
        charArray[i] = charArray[j];
        charArray[j] = temp;
        
        return String.valueOf(charArray);
    }
}