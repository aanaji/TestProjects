package com.starter.datastructures;

public class S17_AVL_2_Delete
{
    TreeNode root;

    static class TreeNode
    {
        TreeNode left;
        int data; 
        int height;                             // FYI : to calculate bf
        TreeNode right;

        TreeNode(int data)
        {
            this.data = data;
            left = null;
            right = null;
        }
    }

    public static void main(String[] args)
    {
        S17_AVL_2_Delete tree = new S17_AVL_2_Delete();
        
        // LL
        TreeNode root0 = null;
        root0 = tree.recursiveInsert(root0, 10);
        tree.recursiveInsert(root0, 20);
        tree.recursiveInsert(root0, 30);
        tree.recursiveInsert(root0, 40);
        
        tree.recursiveDelete(root0, 40);
    }
    
    private TreeNode recursiveDelete(TreeNode p, int key)
    {
        if (p == null)
            return null;
        
        if (p.left == null && p.right == null)
        {
            if (p == root)
                root = null;
            
            // delete p;
            return null;
        }
        
        if (key < p.data)
            p.left = recursiveDelete(p.left, key);

        else if (key > p.data)
            p.right = recursiveDelete(p.right, key);
        
        else
        {
            TreeNode q;
            
            if (nodeHeight(p.left) > nodeHeight(p.right))
            {
                q = inPre(p.left);                                  //  FYI 
                p.data = q.data;
                p.left = recursiveDelete(p.left, q.data);            //  FYI 
            }
            else
            {
                q = inSucc(p.right);
                p.data = q.data;
                p.right = recursiveDelete(p.right, q.data);              //  FYI 
            }
        }
        
        p.height = nodeHeight(p);                           // FYI
        
        if(balanceFactor(p) == 2)
        {
            if(balanceFactor(p.left) == 1) 
                return LLRotation(p);                   // LL = L1
            
            else if (balanceFactor(p.left) == -1)       // LR = L-1  
                return LRRotation(p);
            
            else if (balanceFactor(p.left) == 0)        // LL = L0
                return LLRotation(p);           
        }
        else if(balanceFactor(p) == -2)
        {
            if(balanceFactor(p.right) == 1)             // RL = R1
                return RLRotation(p);                   
            
            else if (balanceFactor(p.right) == -1)      // RR = R-1
                return RRRotation(p);
            
            else if (balanceFactor(p.right) == 0)      // RR = R0
                return RRRotation(p);
        } 
        
        return p;
    }
    
    private TreeNode inPre(TreeNode p)
    {
        while (p != null && p.right != null)                 //  FYI 
            p = p.right;

        return p;
    }

    private TreeNode inSucc(TreeNode p)
    {
        while (p != null && p.left != null)                  //  FYI 
            p = p.left;

        return p;
    }
    
    static int nodeHeight(TreeNode p)
    {
        int hl, hr;
        
        hl = (p!= null && p.left != null) ? p.left.height : 0;
        hr = (p!= null && p.right != null) ? p.right.height : 0;
        
        return (hl > hr) ? (hl + 1) : (hr + 1);
    }
    
    static int balanceFactor(TreeNode p)
    {
        int hl, hr;
        
        hl = (p!= null && p.left != null) ? p.left.height : 0;
        hr = (p!= null && p.right != null) ? p.right.height : 0;
        
        return hl - hr;
    }

    private TreeNode recursiveInsert(TreeNode p, int key)
    {
        TreeNode t;

        if (p == null)
        {
            t = new TreeNode(key);
            t.height = 1;                               // Set Height for every Node
            t.left = t.right = null;
            return t;
        }
        
        if (key < p.data)
            p.left = recursiveInsert(p.left, key);

        else if (key > p.data)
            p.right = recursiveInsert(p.right, key);
        
        p.height = nodeHeight(p);                           // FYI
        
        if(balanceFactor(p) == 2)
        {
            if(balanceFactor(p.left) == 1)
                return LLRotation(p);
            
            else if (balanceFactor(p.left) == -1)
                return LRRotation(p);
        }
        else if(balanceFactor(p) == -2)
        {
            if(balanceFactor(p.right) == 1)
                return RLRotation(p);
            
            else if (balanceFactor(p.right) == -1)
                return RRRotation(p);
        }
        
        return p;
    }
    
    private TreeNode LLRotation(TreeNode p)                     // FYI
    {
        TreeNode pl = p.left;
        TreeNode plr = pl.right;
        
        pl.right = p;
        p.left = plr;
        
        p.height = nodeHeight(p);
        pl.height = nodeHeight(pl);
        
        if(root == p)
            root = pl;
        
        return pl;
    }
    
    private TreeNode LRRotation(TreeNode p)                     // FYI
    {
        TreeNode pl = p.left;
        TreeNode plr = pl.right;
        
        pl.right = plr.left;
        p.left = plr.right;
        
        p.height = nodeHeight(p);
        pl.height = nodeHeight(pl);
        plr.height = nodeHeight(plr);
        
        if(root == p)
            root = plr;
        
        return plr;
    }
    
    private TreeNode RLRotation(TreeNode p)                     // FYI
    {
        TreeNode pr = p.right;
        TreeNode prl = pr.left;
        
        pr.left = prl.right;
        p.right = prl.left;
        
        p.height = nodeHeight(p);
        pr.height = nodeHeight(pr);
        prl.height = nodeHeight(prl);
        
        if(root == p)
            root = prl;
        
        return prl;
    }

    
    private TreeNode RRRotation(TreeNode p)                     // FYI
    {
        TreeNode pr = p.right;
        TreeNode prl = pr.left;
        
        pr.left = p;
        p.right = prl;
        
        p.height = nodeHeight(p);
        pr.height = nodeHeight(pr);
        
        if(root == p)
            root = pr;
        
        return pr;
    }

}