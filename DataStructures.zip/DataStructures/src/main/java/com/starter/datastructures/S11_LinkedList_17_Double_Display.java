package com.starter.datastructures;

public class S11_LinkedList_17_Double_Display {
	Node first, last;

	static class Node {
		Node prev;
		int data;
		Node next;

		Node(int data) {
			this.data = data;
		}
	}

	public static void main(String[] args) {
		S11_LinkedList_17_Double_Display ll = new S11_LinkedList_17_Double_Display();

		Node first = new Node(8);
		first.prev = first.next = null; // FYI

		ll.first = first;
		ll.last = first;

		Node second = new Node(3);

		ll.last.next = second;
		second.prev = ll.last;
		ll.last = second;
		ll.last.next = null;

		Node third = new Node(4);

		ll.last.next = third;
		third.prev = ll.last;
		ll.last = third;
		ll.last.next = null;

		ll.printDoubleLL(ll.first);

		ll.length(ll.first);
	}

	private void length(Node p) {
		int len = 0;
		while (p != null) {
			len++;
			p = p.next;
		}

		System.out.println("Length/ Number of nodes : " + len);
	}

	private void printDoubleLL(Node p) {
		System.out.println();

		while (p != null) // FYI : while
		{
			System.out.print("\t" + p.data);
			p = p.next;

		}
	}

	private int findSmallest(int[] num) {

		int res = 1;

		for (int i = 0; i < num.length && num[i] <= res; i++) {
			res = res + num[i];
		}

		return res;
	}
	
	//private void 

}
