package com.starter.datastructures;

import java.util.Arrays;

public class S7_Array_14_RearrangeNumbers {
	public static void main(String[] args) {

		int[] abc = { 1, 2, 3, -4, -1, 4 };

		Arrays.sort(abc);

		System.out.println(Arrays.toString(abc));

		int start = 0;
		int end = abc.length - 1;

		int[] result = new int[abc.length];
		int i = 0;
		while (start < end) {

			result[i++] = abc[start++];
			result[i++] = abc[end--];
		}
		System.out.println(Arrays.toString(result));

	}
}
