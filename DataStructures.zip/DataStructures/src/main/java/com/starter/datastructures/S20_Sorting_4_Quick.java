package com.starter.datastructures;

public class S20_Sorting_4_Quick
{

    public static void main(String[] args)
    {
        int[] arr = { 50, 70, 60, 90, 40, 80, 10, 20, 30 };
        int i;

        System.out.println("Before Quick Sort - ");
        for (i = 0; i < arr.length; i++)
            System.out.print(" " + arr[i]);

        quickSort(arr, 0, arr.length-1);

        System.out.println("\nAfter Quick Sort - ");
        for (i = 0; i < arr.length; i++)
            System.out.print(" " + arr[i]);
        
        int[] arr2 = { 50, 70, 60, 90, 40, 80, 10, 20, 30 };
        
        System.out.println("\nBefore Quick Sort - ");
        for (i = 0; i < arr2.length; i++)
            System.out.print(" " + arr2[i]);
        
        quickSortLast(arr2, 0, arr2.length-1);
        
        System.out.println("\nAfter Quick Sort - ");
        for (i = 0; i < arr2.length; i++)
            System.out.print(" " + arr2[i]);
    }

    private static void quickSortLast(int[] arr, int low, int high)
    {
        int j;

        if (low < high)
        {
            j = partitionLast(arr, low, high);
            quickSort(arr, low, j - 1);
            quickSort(arr, j + 1, high);
        }
        
    }

    private static int partitionLast(int[] arr, int low, int high)
    {
        int pivot = arr[high];
        int i = low - 1;
        
        for (int j = low; j <= high - 1; j++)
        {
            if (arr[j] < pivot)
            {
                i++;
                
                // swap (arr[i], arr[j]);
                
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        
        // swap (arr[i+1], arr[high]);

        int temp = arr[i+1];
        arr[i+1] = arr[high];
        arr[high] = temp;
        
        return i + 1;
    }

    private static void quickSort(int[] arr, int low, int high)
    {
        int j;

        if (low < high)
        {
            j = partition(arr, low, high);
            quickSort(arr, low, j - 1);
            quickSort(arr, j + 1, high);
        }
    }
    
    private static int partition(int[] arr, int low, int high)          
    {
        int pivot = arr[low];                                               // FYI
        int i = low + 1, j = high;

        while (true)
        {
            while (i <= j && arr[i] <= pivot)
                i++;
            
            while (i <= j && arr[j] >= pivot)
                j--;
            
            if (j < i)
                break;
            else
            {
                // swap (arr[i], arr[j]);
                
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        // swap (arr[low], arr[j]);

        int temp = arr[low];
        arr[low] = arr[j];
        arr[j] = temp;

        return j;                                                               // FYI
    }

}
