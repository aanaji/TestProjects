package com.starter.datastructures;

public class S7_Array_10_DuplicateEle
{

    public static void main(String[] args)
    {
        int[] a = { 1, 2, 4, 5, 5, 6, 7, 8, 8, 8, 12, 18, 18, 18, 18, 18, 19 };

        int lastDup = 0;
        for (int i = 0; i < a.length - 1; i++)
        {
            if (a[i] == a[i + 1] && lastDup != a[i])    // consider only the 1st duplicate element
            {
                System.out.print("\t" + a[i]);
                lastDup = a[i];
            }
        }
        System.out.println();
        
        // Count duplicates
        int j=0;
        for (int i = 0; i < a.length - 1; i++)
        {
            if (a[i] == a[i + 1])    
            {
                j=i+1;                  // i-j
                
                while(a[i]==a[j])       // move j for all the duplicates
                    j++;
                
                System.out.println(a[i] + " appears " + (j-i)  + " times");     // count=j-i;
                i=j-1;                  // i-j
            }
        }
        
        // count duplicates using Hashing/ BitSet (sorted and unsorted)
        int[] b = { 1, 44, 44, 53, 5, 6, 7, 8, 58, 8, 12, 18, 17, 18, 21, 18, 19 };
        
        int max = 0;
        for (int i = 0; i < b.length; i++)
            if (b[i] > max)
                max = b[i];

        int[] h = new int[++max];

        for (int i = 0; i < b.length; i++)
            h[b[i]]++;

        for (int i = 0; i < h.length; i++)
            if (h[i] > 1)
                System.out.println(i + " appears " + h[i] + " times");
            
        // unsorted array : in-place : no extra space
        for (int i = 0; i < b.length - 1; i++)
        {
            int count = 1;
            if (b[i] != -1)
            {
                for (int k = i + 1; k < b.length; k++)
                {
                    if (b[i] == b[k])
                    {
                        count++;
                        b[k] = -1;
                    }
                }
                if (count > 1)
                    System.out.println(b[i] + " appears " + count + " times");
            }
        }
    }

}
