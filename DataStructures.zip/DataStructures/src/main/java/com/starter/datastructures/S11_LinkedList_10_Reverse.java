package com.starter.datastructures;

public class S11_LinkedList_10_Reverse {
	Node first, last;

	static class Node {
		int data;
		Node next;

		Node(int data) {
			this.data = data;
		}
	}

	public static void main(String[] args) {
		S11_LinkedList_10_Reverse ll = new S11_LinkedList_10_Reverse();

		ll.insertLast(2);
		ll.insertLast(4);
		ll.insertLast(6);
		ll.insertLast(8);

		ll.printLL();

		// ll.reverseElements();

		/*
		 * ll.printLL();
		 * 
		 * ll.reverseSlidPtr();
		 * 
		 * ll.printLL();
		 * 
		 * 
		 * 
		 * ll.printLL();
		 */

		Node p = ll.first;
		Node q = null;
		// ll.reverseRecursion12(q, p);

		ll.reverseRecursion(q, p);

		ll.printLL();
	}

	private void reverseRecursion(Node previous, Node current) {

		if (current != null) {
			reverseRecursion(current, current.next);
			current.next = previous;
		} else {
			first = previous;
		}
	}

	private void reverseRecursion12(Node q, Node p) {
		if (p != null) {
			reverseRecursion(p, p.next);
			p.next = q;
		} else {
			first = q;
		}
	}

	private void test() {
		Node curent = first;
		Node temp = null;
		Node reverse = null;

		while (curent != null) {
			temp = reverse;
			reverse = curent;
			curent = curent.next;
			reverse.next = temp;
		}
		first = reverse;
	}

	private void reverseSlidPtr() {
		Node p = first;
		Node q = null;
		Node r = null;

		while (p != null) {
			r = q;
			q = p;
			p = p.next;
			q.next = r;
		}
		first = q;
	}

	private void reverseElements() {
		Node p = first;
		int[] arr = new int[4];
		int i = 0;

		while (p != null) {
			arr[i] = p.data;
			p = p.next;
			i++;
		}
		p = first;
		i--;
		while (p != null) {
			p.data = arr[i];
			p = p.next;
			i--;
		}
	}

	private void insertLast(int val) {
		Node t = new Node(val);

		if (first == null) {
			first = last = t;
		} else {
			last.next = t;
			last = t;
		}
	}

	private void printLL() {
		System.out.println();
		Node n = first;

		while (n != null) // FYI : while
		{
			System.out.print("\t" + n.data);
			n = n.next;
		}
	}
}
