package com.starter.datastructures;

public class S5_Recursion_4_Indirect
{

    public static void main(String[] args)
    {
        int n=20;
        
        recursiveIndirectA(n);
    }

    private static void recursiveIndirectA(int n)
    {
        if(n>0)
        {
            System.out.print("\t" + n);
            recursiveIndirectB(n-1);
        }
    }
    
    private static void recursiveIndirectB(int n)
    {
        if(n>1)
        {
            System.out.print("\t" + n);
            recursiveIndirectA(n/2);
        }
    }
}
