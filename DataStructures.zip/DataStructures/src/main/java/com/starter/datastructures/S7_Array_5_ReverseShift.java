package com.starter.datastructures;

public class S7_Array_5_ReverseShift
{

    public static void main(String[] args)
    {
        int[] n = { 4, 8, 23, 12, 98, 6 };
        reverse1(n);
        System.out.println();

        int[] m = { 4, 8, 23, 12, 98, 6 };
        reverse2(m);
        System.out.println();

        int[] o = { 4, 8, 23, 12, 98, 6 };
        shift(o);
    }

    private static void reverse1(int[] n)
    {
        int[] m = new int[n.length];

        for (int i = n.length - 1, j = 0; i >= 0; i--, j++)
        {
            m[j] = n[i];
        }

        for (int i = 0; i < n.length; i++)
        {
            n[i] = m[i];
        }

        for (int i = 0; i < n.length; i++)
        {
            System.out.print("\t " + n[i]);
        }
    }

    private static void reverse2(int[] n)
    {
        for (int i = 0, j = n.length - 1; i < j; i++, j--)
        {
            int temp = n[i];
            n[i] = n[j];
            n[j] = temp;
        }

        for (int i = 0; i < n.length; i++)
        {
            System.out.print("\t " + n[i]);
        }
    }

    private static void shift(int[] n)
    {
        int ele = n[0];
        for (int i = 0; i < n.length - 1; i++)
        {
            n[i] = n[i + 1];
        }
        n[n.length - 1] = ele;

        for (int i = 0; i < n.length; i++)
        {
            System.out.print("\t " + n[i]);
        }
    }
}
