package com.starter.datastructures;

public class S11_LinkedList_2_Sum_Count
{
    Node head;

    static class Node
    {
        int data;
        Node next;

        Node(int data)
        {
            this.data = data;
        }
    }

    public static void main(String[] args)
    {
        S11_LinkedList_2_Sum_Count ll = new S11_LinkedList_2_Sum_Count();

        ll.head = new Node(2);

        Node second = new Node(4);
        Node third = new Node(6);

        ll.head.next = second;
        second.next = third;

        int sum = ll.sum(ll.head);
        System.out.println("Sum : " + sum);

        sum = ll.recursiveSum(ll.head);
        System.out.println("R Sum : " + sum);

        int count = ll.count(ll.head);
        System.out.println("Count : " + count);

        count = ll.recursivecount(ll.head);
        System.out.println("R Count : " + count);

    }

    private int recursivecount(Node head2)
    {
        if(head2 == null)
            return 0;

        return recursivecount(head2.next) + 1;
    }

    private int count(Node head2)
    {
        int count = 0;
        while(head2 != null)
        {
            count++;
            head2 = head2.next;
        }
        return count;
    }

    private int recursiveSum(Node head2)
    {
        if(head2 == null)
            return 0;

        return recursiveSum(head2.next) + head2.data;
    }

    private int sum(Node head2)
    {
        int sum = 0;
        while(head2 != null)
        {
            sum += head2.data;
            head2 = head2.next;
        }
        return sum;
    }

}
