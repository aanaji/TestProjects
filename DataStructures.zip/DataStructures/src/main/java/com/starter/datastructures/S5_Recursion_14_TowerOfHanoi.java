package com.starter.datastructures;

public class S5_Recursion_14_TowerOfHanoi
{

    public static void main(String[] args)
    {
        int n = 3;

        TOH(n, 'A', 'B', 'C');
    }

    private static void TOH(int n, char src, char aux, char dest)
    {
        if (n > 0)
        {
            TOH(n - 1, src, dest, aux);
            System.out.println("Move from " + src + " to " + dest);
            TOH(n - 1, aux, src, dest);
        }
    }
}
