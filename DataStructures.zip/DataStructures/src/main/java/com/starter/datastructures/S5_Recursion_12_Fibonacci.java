package com.starter.datastructures;

/**
 * Fibonacci of Nth term
 * 
 * @author msabapathy
 *
 */

public class S5_Recursion_12_Fibonacci
{

    static int[] fibo = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };

    public static void main(String[] args)
    {
        int result = recursive(6);
        System.out.println("Result-1 : " + result);

        result = iterative(6);
        System.out.println("Result-2 : " + result);

        result = memoization(6);
        System.out.println("Result-3 : " + result);
    }

    private static int memoization(int n)
    {
        if (n <= 1)
        {
            fibo[n] = n;
            return n;
        }
        else
        {
            if (fibo[n - 2] == -1)
                fibo[n - 2] = memoization(n - 2);

            if (fibo[n - 1] == -1)
                fibo[n - 1] = memoization(n - 1);

            fibo[n] = fibo[n - 2] + fibo[n - 1]; // check this

            return fibo[n - 2] + fibo[n - 1];
        }
    }

    private static int iterative(int n)
    {
        int a = 0, b = 1, sum = 0;
        for (int i = 2; i <= n; i++)
        {
            sum = a + b;
            a = b;
            b = sum;
        }
        return sum;
    }

    private static int recursive(int n)
    {
        if (n <= 1)
            return n;

        return recursive(n - 2) + recursive(n - 1);
    }

}
