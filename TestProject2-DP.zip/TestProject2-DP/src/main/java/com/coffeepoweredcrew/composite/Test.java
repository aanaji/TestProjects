package com.coffeepoweredcrew.composite;

public class Test
{

}


class Patient {
    
}


class PreExam {
    
}