
public class Test2 {

	public static void main(String[] args) {

		String inputString = "anana";

		boolean isPalindrome = true;
		for (int i = 0, j = inputString.length() - 1; i <= j; i++, j--) {

			if (inputString.charAt(i) != inputString.charAt(j)) {
				isPalindrome = false;
				break;
			}
		}

		System.out.println(isPalindrome);
	}

}
