import java.util.Scanner;

public class MorseToEnglish {

	public static void main(String[] args) {
		// Define and initialize variables
		int choiceIn;
		String englishIn = "";

		char[] charNum = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
				'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', ' ' };

		String[] morseCode = { ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..",
				"--", "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--..",
				".----", "..---", "...--", "....-", ".....", "-....", "--...", "---..", "----.", "-----", "|" };

		// Use a Scanner to take user inputs
		Scanner input = new Scanner(System.in);

		// Input first value for the month
		System.out.print(
				"\n" + "Welcome to Morse Code Translator. Press 1 for Morse to English and 2 for English to Morse:");
		choiceIn = input.nextInt();

		input.nextLine();

		if (choiceIn == 1) {
			System.out.print("\n" + "Enter a Morse code for translation:");
			String morseIn = input.nextLine();
			morseIn = morseIn.trim();

			morseToEnglish(morseIn, morseCode, charNum);
		} else if (choiceIn == 2) {
			System.out.print("\n" + "Enter English words for translation:");
			englishIn = input.nextLine();
			englishIn = englishIn.trim();

			// englishToMorse(englishIn, morseCode, charNum);
		}

	}

	public static void morseToEnglish(String morseIn, String[] morseCode, char[] charNum) {
		int indexChar;
		int indAdr;

		String codeOut = "";
		String valueChar;

		char codeValue = 0;
		System.out.println("morse code1 is:" + morseIn);
		String[] morseStr = morseIn.split(" ");

		for (indexChar = 0; indexChar < morseStr.length; indexChar++) {

			System.out.println("string length is:" + morseStr.length);
			// System.out.println("array length is:" + morseCode.length );
			valueChar = morseStr[indexChar];
			valueChar = valueChar.trim();
			System.out.println("value is:" + valueChar);

			for (indAdr = 0; indAdr < morseCode.length; indAdr++) {
				morseCode[indAdr] = morseCode[indAdr].trim();
				// System.out.println ("morse code is:" + morseCode[indAdr]) ;
				if (morseCode[indAdr].equals(valueChar))

				{
					System.out.println("Chars value:" + charNum[indAdr]);
					codeValue = charNum[indAdr];
				}

			}
			codeOut = codeOut + codeValue;

		}

		System.out.print(" code is:" + codeOut);
	}

}