package com.learnJava.methodreferences;

import com.learnJava.data.Student;
import com.learnJava.data.StudentDataBase;

import java.util.function.Consumer;

public class ConsumerMethodReferenceExample {

	/**
	 * Class::instancemethod
	 */
	static Consumer<Student> c1 = System.out::println;

	static Consumer<Student> c5 = c5 -> System.out.println(c5);

	/**
	 * instance::instancemethod
	 */
	static Consumer<Student> c2 = student -> student.printListOfActivities();
	static Consumer<Student> c3 = (Student::printListOfActivities);

	public static void main(String[] args) {

		StudentDataBase.getAllStudents().forEach(c5);
		StudentDataBase.getAllStudents().forEach(c2);
		StudentDataBase.getAllStudents().forEach(c3);
	}

}
