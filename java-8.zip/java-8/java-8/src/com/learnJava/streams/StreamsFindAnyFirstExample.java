package com.learnJava.streams;

import com.learnJava.data.Student;
import com.learnJava.data.StudentDataBase;
import com.sun.xml.internal.ws.api.ha.StickyFeature;

import java.util.Comparator;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class StreamsFindAnyFirstExample {

	public static Optional<Student> findAny() {

		return StudentDataBase.getAllStudents().stream().filter(student -> student.getGpa() >= 3.8).findAny();
	}

	public static Optional<Student> findFirst() {

		return StudentDataBase.getAllStudents().stream().filter(student -> student.getGpa() >= 3.8).findFirst();
	}

	public static void main(String[] args) {

		Optional<Student> findAnyStudent = findAny();
		if (findAnyStudent.isPresent()) {
			System.out.println("Student is :" + findAnyStudent.get());
		} else {
			System.out.println("No Student Found");
		}

		Optional<Student> findFirst = findFirst();
		if (findFirst.isPresent()) {
			System.out.println("Student is :" + findFirst.get());
		} else {
			System.out.println("No Student Found");
		}
		// it will make a lot of different during parallel stream

		System.out.println(StudentDataBase.getAllStudents().stream()
				.sorted(Comparator.comparing(Student::getGradeLevel).reversed()).findAny().get());

		StudentDataBase.getAllStudents().stream().collect(Collectors.toMap(Student::getName, Function.identity()))
				.forEach((A, B) -> System.out.println(B));

		System.out.println(StudentDataBase.getAllStudents().stream().sorted(Comparator.comparing(Student::getGpa))
				.collect(Collectors.groupingBy(s -> s.getGpa() >= 3.9 ? "A" : "B")));
	}
}
