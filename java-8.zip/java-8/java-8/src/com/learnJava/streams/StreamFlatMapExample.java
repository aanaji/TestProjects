package com.learnJava.streams;

import com.learnJava.data.Student;
import com.learnJava.data.StudentDataBase;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

import java.util.Comparator;
import java.util.HashSet;

public class StreamFlatMapExample {

	public static List<String> printStudentActivities() {

		List<String> studentActivities = StudentDataBase.getAllStudents().stream().map(Student::getActivities) // Stream<List<String>>
				.flatMap(List::stream) // <Stream<String>
				.collect(toList());

		return studentActivities;

	}

	public static List<String> printUniqueStudentActivities() {

		List<String> studentActivities = StudentDataBase.getAllStudents().stream().map(Student::getActivities)
				.flatMap(List::stream).distinct().sorted().collect(toList());

		return studentActivities;

	}

	public static long getStudentActivitiesCount() {

		long totalActivities = StudentDataBase.getAllStudents().stream().map(Student::getActivities)
				.flatMap(List::stream).distinct().count();

		return totalActivities;

	}

	public static void main(String[] args) {

		/*
		 * System.out.println("Student Activities : " + printStudentActivities());
		 * System.out.println("Unique Student Activities : " +
		 * printUniqueStudentActivities());
		 * System.out.println("Unique Student Activities Count: " +
		 * getStudentActivitiesCount());
		 */

		anandTest();

	}

	private static Set<Set<Student>> testSet = new HashSet<>();

	private static void anandTest() {

		// System.out.println(StudentDataBase.getAllStudents().stream().map(Student::getActivities).count());

		// testSet.stream().forEach(action);

		System.out.println(StudentDataBase.getAllStudents().stream().map(Student::getGender).distinct().sorted()
				.collect(Collectors.toList()));

		StudentDataBase.getAllStudents().stream().map(Student::getGender).distinct().count();

		System.out.println(StudentDataBase.getAllStudents().stream().sorted(Comparator.comparing(Student::getName))
				.collect(toList()));

		System.out.println(StudentDataBase.getAllStudents().stream().limit(2).skip(1)
				.sorted(Comparator.comparing(Student::getName)).collect(toList()));
		
		//AtomicReference<V>
		StudentDataBase.getAllStudents().stream().filter( s -> s.getName() == "Ananda").findFirst().ifPresent( abc -> abc.getName());
		// StudentDataBase.getAllStudents().stream().filter( s -> s.getName()== "ddsd").

		ReentrantLock lock = new ReentrantLock();

		try {
			lock.lockInterruptibly();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
