package com.learnJava.streams;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toSet;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.learnJava.data.Student;
import com.learnJava.data.StudentDataBase;

public class CollectionsvsStreams {

	public static void main(String[] args) {

		ArrayList<String> names = new ArrayList<>();
		names.add("Adam");
		names.add("Jim");
		names.add("Jenny");

		Stream<String> namesStream = names.stream();

		namesStream.forEach(System.out::println);
		// namesStream.forEach(System.out::println);
		// System.out.println(names);

		System.out
				.println(StudentDataBase.getAllStudents().stream().collect(Collectors.groupingBy(Student::getGender)));

		System.out.println(StudentDataBase.getAllStudents().stream().sorted(Comparator.comparing(Student::getGpa))
				.collect(Collectors.groupingBy(s -> s.getGpa() >= 3.9 ? "A" : "B")));

		// Map<String, List<Student>> stu =
		// StudentDataBase.getAllStudents().stream().collect(Collectors.groupingBy(Student::getGender));

		System.out.println(StudentDataBase.getAllStudents().stream().sorted(Comparator.comparing(Student::getGpa))
				.collect(Collectors.groupingBy(Student::getGradeLevel,
						Collectors.groupingBy(s -> s.getGpa() >= 3.9 ? "A" : "B"))));

		LinkedHashMap<String, Set<Student>> studentMap = StudentDataBase.getAllStudents().stream()
				.collect(groupingBy(Student::getName, LinkedHashMap::new, toSet()));

		System.out.println(studentMap);
	}
}
