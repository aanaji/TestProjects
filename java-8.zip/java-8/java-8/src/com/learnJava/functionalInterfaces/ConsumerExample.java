package com.learnJava.functionalInterfaces;

import com.learnJava.data.Student;
import com.learnJava.data.StudentDataBase;
import com.sun.xml.internal.ws.api.ha.StickyFeature;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ConsumerExample {

	static Consumer<Student> c1 = p -> System.out.println(p);

	static Consumer<Student> c2 = p -> System.out.print(p.getName().toUpperCase());

	static Consumer<Student> c3 = p -> System.out.println(p.getActivities());

	public static void printName() {

		List<Student> personList = StudentDataBase.getAllStudents();

		personList.forEach(c1);

	}

	public static void printNameAndActivities() {
		System.out.println("\n" + "**************************************************" + "\n");
		System.out.println("printNameAndActivities : ");
		List<Student> personList = StudentDataBase.getAllStudents();
		personList.forEach(c2.andThen(c3));
	}

	public static void printNameAndActivitiesUsingCondition() {
		System.out.println("\n" + "**************************************************" + "\n");
		System.out.println("printNameAndActivitiesUsingCondition : ");
		List<Student> personList = StudentDataBase.getAllStudents();
		personList.forEach((s) -> {
			if (s.getGradeLevel() >= 3 && s.getGpa() > 3.9) {
				c2.andThen(c3).accept(s);
			}
		});
	}

	public static void main(String[] args) {

		Consumer<String> c1 = (s) -> System.out.println(s.toUpperCase());

		c1.accept("java8");

		// printName();
		// printNameAndActivities();
		// printNameAndActivitiesUsingCondition();

		Supplier<List<String>> test = ArrayList::new;

		// StudentDataBase.getAllStudents().forEach( (student, student)->
		// System.out.println(student));

		BiConsumer<Student, List<String>> studentBiConsumer = (student, activities) -> {
			System.out.println(student + "" + activities);
		};

		// StudentDataBase.getAllStudents().forEach(stud ->
		// studentBiConsumer.accept(stud, stud.getActivities()));

//		StudentDataBase.getAllStudents().forEach(s -> System.out.println(s));

		// StudentDataBase.getAllStudents().stream().filter(s -> s.equals("")).

		Comparator<Student> studnetCompare = (S1, S2) -> {
			return S2.getName().compareTo(S1.getName());
		};
		StudentDataBase.getAllStudents().stream().distinct().sorted(studnetCompare).forEach(s -> System.out.println(s));

		List<Double> intList = IntStream.range(0, 100).boxed().mapToDouble(doub -> Double.valueOf(doub)).boxed()
				.collect(Collectors.toList());

		intList.stream().parallel().forEach(System.out::println);

		Map<String, Student> studentMap = StudentDataBase.getAllStudents().stream()
				.collect(Collectors.toMap(Student::getName, student -> student));

		// sstudentMap.forEach((a, b) -> System.out.println(a + " " + b));

		String names = StudentDataBase.getAllStudents().stream().map(Student::getName).collect(Collectors.joining("-"));

		System.out.println(names);

		System.out.println(IntStream.range(16, 30).boxed().map(String::valueOf)
				.collect(Collectors.mapping(Function.identity(), Collectors.toList())));

		System.out.println(IntStream.range(16, 30).boxed().map(String::valueOf)
				.collect(Collectors.maxBy(Comparator.comparing(Function.identity()))));

		System.out.println(IntStream.range(10, 40).boxed().collect(Collectors.averagingInt(s -> s)));

		// StudentDataBase.getAllStudents().stream().min

		System.out.println(StudentDataBase.getAllStudents().stream().sorted(Comparator.comparing(Student::getGpa))
				.collect(Collectors.groupingBy(s -> s.getGpa() >= 3.9 ? "A" : "B")));

		System.out
				.println(StudentDataBase.getAllStudents().stream().collect(Collectors.groupingBy(Student::getGender)));

		System.out.println(StudentDataBase.getAllStudents().stream().collect(Collectors
				.groupingBy(Student::getGradeLevel, Collectors.maxBy(Comparator.comparing(Student::getGpa)))));

		StudentDataBase.getAllStudents().stream().map(Student::getGender).distinct().forEach(System.out::println);
	}
}
