package com.learnJava.functionalInterfaces;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import com.learnJava.data.Student;
import com.learnJava.data.StudentDataBase;
import com.sun.org.apache.xml.internal.serializer.ToXMLStream;

public class SupplierExample {

	public static Supplier<Student> studentSupplier = () -> new Student("Adam", 2, 4.0, "male",
			Arrays.asList("swimming", "basketball", "volleyball"));

	public static Supplier<List<Student>> studentsSupplier = () -> StudentDataBase.getAllStudents();

	public static void main(String[] args) {

		Student student = studentSupplier.get();

		System.out.println("Student is : " + student);

		System.out.println("Students are : " + studentsSupplier.get());

		Function<String, String> toUpper = String::toUpperCase;

		Supplier<Student> stud = Student::new;

		System.out.println(StudentDataBase.getAllStudents().stream());

		List<String> output = StudentDataBase.getAllStudents().stream().map(Student::getName)
				.collect(Collectors.toList());

		System.out.println(output);

		List<Integer> intList = Arrays.asList(1, 2, 3, 4, 5);

		System.out.println(intList.stream().reduce(1, (a, b) -> a * b));

		System.out.println(StudentDataBase.getAllStudents().stream().filter(s -> s.getGender() == "female")
				.map(Student::getNoteBooks).reduce(Integer::sum));
	}
}
