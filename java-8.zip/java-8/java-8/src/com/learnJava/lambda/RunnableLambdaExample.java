package com.learnJava.lambda;

import java.util.Comparator;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import com.learnJava.data.StudentDataBase;

public class RunnableLambdaExample {

	public static void main(String[] args) {

		Runnable runnable = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("Test 1 ");
			}
		};

		new Thread(runnable).start();

		Runnable runnable2 = () -> {
			System.out.println("Test 2");
			System.out.println("Multi");
		};

		new Thread(runnable2).start();

		new Thread(() -> System.out.println("Test 3")).start();

		new Thread("Test 4").start();
		
		
		Comparator<Integer> comparator = (o1, o2) -> o1.compareTo(o2); 
		
		System.out.println(comparator.compare(3, 2));
		
		Consumer<String> stringConsumer = System.out::println;
		
		stringConsumer.accept("ABC");
		
		StudentDataBase.getAllStudents().forEach( student -> System.out.println(student));
		
		BiConsumer<String, String> biStringConsumer = (String a , String b) -> System.out.println(a + b);
	}
}
 