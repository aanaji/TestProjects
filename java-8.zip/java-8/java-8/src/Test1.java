import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Test1 {

	public static void main(String[] args) {
		List<List<Integer>> list = new ArrayList<>();

		List<Integer> firstRow = new ArrayList<>();
		firstRow.add(1);
		firstRow.add(2);
		firstRow.add(3);
		List<Integer> secondRow = new ArrayList<>();
		secondRow.add(5);
		secondRow.add(6);

		list.add(firstRow);
		list.add(secondRow);

		List<List<Integer>> outList = new ArrayList<>();

		System.out.println();
		
		//1,2,3,4,5,6,7,8
		//map<0,0>, <1,3> <2,5>
		
		while (list.spliterator() != null) {
			//type type = (type) list.nextElement();
			
		}
		
		//Arrays.copyof
		/*
		 * for (List<Integer> integer : list) {
		 * 
		 * //System.out.println(integer); for (Integer integer2 : integer) {
		 * //System.out.println(integer2); outList. } }
		 */
		
		/*List<Integer> newList = Stream.concat(list.stream(), secondRow.stream())
                .collect(Collectors.toList());*/
		
		//List<Integer> map = list.stream().map( in -> in)
		
		//System.out.println(newList);


		// System.out.println(indValue);
	}

}
