
@FunctionalInterface
public interface Test {

	void test();

	String toString();
}
