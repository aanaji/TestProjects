import java.time.LocalDate;
import java.time.LocalDateTime;

public class LocalDateTest {

	public static void main(String[] args) {
		System.out.println(LocalDateTime.now());
	}
}
