import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.learnJava.data.Student;
import com.learnJava.data.StudentDataBase;
import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils.Collections;

public class EffectiveFinal implements Comparable<EffectiveFinal> {

	public static void main(String[] args) {

		int i = 0;

		IntStream.range(0, 100).forEach(in -> {
			// System.out.println(++i);
		});

		System.out.println(i);

		StudentDataBase.getAllStudents().stream().map(Student::getActivities).flatMap(List::stream)
				.forEach(s -> System.out.println(s));

		Integer integer = 10012;

		Double doub = integer.doubleValue();

		integer = (int) doub.doubleValue();

		System.out.println(integer);

		List<String> arraylist = new ArrayList<>();

		arraylist.add("Ananda");
		arraylist.add("Thirakappa");

		arraylist.replaceAll(s -> s.concat(" Anaji"));

		arraylist.stream().forEach(System.out::println);

		// StudentDataBase.getAllStudents().replaceAll(operator);

		// java.util.Collections.synchronizedMap(new LinkedHashMap<>());

		NestedInnerClass nest = new NestedInnerClass();

		// Arrays.eq

	}

	static class NestedInnerClass {

		public void testing() {

		}
	}

	@Override
	public int compareTo(EffectiveFinal o) {
		// TODO Auto-generated method stub
		return 0;
	}
}

abstract class Test123<T> {
	
	public T setValue(T request) {
		return request;
		
	}
}

interface Testing12312 {

	void testing();
}

class Animal {
	String name;

	public Animal() {
		this.name = "Default	Name";
	}

	// This is called a one argument constructor.
	public Animal(String name) {
		this.name = name;
	}

	public static void main(String[] args) {
		Animal animal = new Animal();
	}
}