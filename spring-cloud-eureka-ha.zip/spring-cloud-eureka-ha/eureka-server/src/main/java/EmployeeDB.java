/*
 * This is an application program which accepts user's input for number
 * of employees, name, address and hiring date implemented in main method
 * which uses other class methods to print the employee database
 *  
 */

public class EmployeeDB {

	public static void main(String[] args) {

		Employee[] employeeArray = new Employee[3];

		/*
		 * Employee employee1 = new Employee(100, name.setFirstName("Dave"),
		 * name.setLastName("Smith"), address.setStreetName("Hill Road"),
		 * address.setCityName("Phoenix"), address.setStateName("AZ"),
		 * address.setZipCode(85055), date.setHireMonth(12), date.setHireDate(05),
		 * date.setHireyear(1998));
		 * 
		 * Employee employee2 = new Employee(100, name.setFirstName("Mike"),
		 * name.setLastName("George"), address.setStreetName("Lake View"),
		 * address.setCityName("Folsom"), address.setStateName("CA"),
		 * address.setZipCode(95621), date.setHireMonth(22), date.setHireDate(10),
		 * date.setHireyear(2001));
		 * 
		 * Employee employee2 = new Employee(100, name.setFirstName("Sun"),
		 * name.setLastName("Korri"), address.setStreetName("Park Road"),
		 * address.setCityName("Denver"), address.setStateName("CO"),
		 * address.setZipCode(95621), date.setHireMonth(29), date.setHireDate(11),
		 * date.setHireyear(2010));
		 */

		Employee employee = new SalariedEmployee(100, new Name("Dave", "Smith"),
				new Address("Hill Road", "Phoenix", "AZ", 85055), new Date(12, 05, 1998), 100000);

		employeeArray[0] = employee;

		Employee employee1 = new HourlyEmployee(101, new Name("Mike", "George"),
				new Address("Lake View", "Folsom", "CA", 95621), new Date(10, 10, 2001), 40, 20, 200, 10);

		employeeArray[1] = employee1;

		Employee employee2 = new HourlyEmployee(101, new Name("Mike", "George"),
				new Address("Lake View", "Folsom", "CA", 95621), new Date(10, 10, 2001), 40, 20, 200, 10);

		employeeArray[2] = employee2;

		// loop thru array objects to print employee database
		System.out.println("\n" + "Printing employee database." + "\n");
		for (int emp = 0; emp < employeeArray.length; emp++) {
			System.out.println(employeeArray[emp].toString());
			System.out.println("-------------------");
		}
		System.out.print("\n");
	}

}
