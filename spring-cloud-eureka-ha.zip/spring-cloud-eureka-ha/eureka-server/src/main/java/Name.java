/*
 * This is single class program defines its constructors, setters, getters
 * and prints the value in the main method of application program when called 
 * with its set and get methods 
 *  
 */
public class Name {
	// declaring private variables
	private String firstName;
	private String lastName;

	public Name() // creating constructor of the class EmployeeName
	{
		this.firstName = "";
		this.lastName = "";
	}

	public Name(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	// calling setter to set variable value
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	// calling getter method to return variable
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return firstName + "    " + lastName;
	}
}
