/*
 * This is single class program for EmployeeDate defines its constructors, 
 * setters, getters and prints the value in the main method of application
 * program when called with its set and get methods 
 *  
 */
public class Date {

	// declaring private variables
	private int hireMonth;
	private int hireDate;
	private int hireyear;

	public Date() // creating constructor of the class EmployeeDate
	{
		this.hireMonth = 0;
		this.hireDate = 0;
		this.hireyear = 0;
	}

	public Date(int hireMonth, int hireDate, int hireyear) {
		super();
		this.hireMonth = hireMonth;
		this.hireDate = hireDate;
		this.hireyear = hireyear;
	}

	public int getHireMonth() {
		return hireMonth;
	}

	public void setHireMonth(int hireMonth) {
		// condition check for month entered between 1 and 12
		if (hireMonth >= 1 && hireMonth <= 12) {
			this.hireMonth = hireMonth;
		} else {
			System.out.println("Enter valid month between 1 to 12\n");
		}

	}

	public int getHireDate() // calling getter method to return variable
	{
		return hireDate;
	}

	public void setHireDate(int hireDate) // calling setter to set variable value
	{
		// condition check for date entered between 1 and 31
		if (hireDate >= 1 && hireDate <= 31) {
			this.hireDate = hireDate; // accessing private variable with 'this'
		} else {
			System.out.println("Enter valid date from 1 to 31\n");
		}
	}

	public int getHireyear() {
		return hireyear;
	}

	public void setHireyear(int hireyear) {
		// condition check for year entered between 1900 and 2020
		if (hireyear > 1900 && hireyear <= 2020) {
			this.hireyear = hireyear;
		} else {
			System.out.println("Enter valid year between 1900 and 2020\n");
		}
	}

	@Override
	public String toString() {
		return getHireMonth() + "    " + getHireDate() + "    " + getHireyear();
	}
}
