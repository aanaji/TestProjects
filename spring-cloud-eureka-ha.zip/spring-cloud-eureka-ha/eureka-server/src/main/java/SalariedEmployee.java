
public class SalariedEmployee extends Employee {

	private double annualSalary;

	public SalariedEmployee(int employeeId, Name name, Address address, Date date, double annualSalary) {
		super(employeeId, name, address, date);
		this.annualSalary = annualSalary;
	}

	public double getAnnualSalary() {
		return annualSalary;
	}

	public void setAnnualSalary(double annualSalary) {
		this.annualSalary = annualSalary;
	}

	@Override
	public String toString() {
		/*
		 * return "SalariedEmployee [annualSalary=" + annualSalary +
		 * ", getAnnualSalary()=" + getAnnualSalary() + ", getSalalry()=" + getSalalry()
		 * + ", getEmployeeId()=" + getEmployeeId() + ", getName()=" + getName() +
		 * ", getAddress()=" + getAddress() + ", getDate()=" + getDate() +
		 * ", toString()=" + super.toString() + ", getClass()=" + getClass() +
		 * ", hashCode()=" + hashCode() + "]";
		 */
		return super.toString() + "   " + annualSalary;
	}

}
