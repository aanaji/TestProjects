/*
 * This is single class program defines its constructors, setters, getters
 * and prints the value in the main method of application program when called 
 * with its set and get methods 
 *  
 */
public class Employee {
	// declaring private variables
	private int employeeId;
	private Name name;

	private Address address;

	private Date date;

	public Employee(int employeeId, Name name, Address address, Date date) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.address = address;
		this.date = date;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId; // accessing private variable with 'this'
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return name.toString() + "    " + address.toString() + "    " + date.toString();
	}

	// toSTring method to print value of each object when printed
	/*
	 * public String toString() { return name.getFirstName() + "\t: \t" +
	 * name.getLastName() + "\t: \t" + address.getStreetName() + "\t: \t" +
	 * address.getCityName() + "\t: \t" + address.getStateName() + "\t: \t" +
	 * address.getZipCode() + "\t: \t" + date.getHireDate() + "." +
	 * date.getHireMonth() + "." + date.getHireyear(); }
	 */

}
