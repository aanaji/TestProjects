
public class HourlyEmployee extends Employee {
	private int hourlyRate;
	private float newRate;
	private int totalHrs;
	private int diffHrs;
	private double totSalary;

	public HourlyEmployee(int employeeId, Name name, Address address, Date date, int hourlyRate, float newRate,
			int totalHrs, int diffHrs) {
		super(employeeId, name, address, date);
		this.hourlyRate = hourlyRate;
		this.newRate = newRate;
		this.totalHrs = totalHrs;
		this.diffHrs = diffHrs;
	}

	public int getHourlyRate() {
		return hourlyRate;
	}

	public void setHourlyRate(int hourlyRate) {
		this.hourlyRate = hourlyRate;
	}

	public int getTotalHrs() {
		return totalHrs;
	}

	public void setTotalHrs(int totalHrs) {
		this.totalHrs = totalHrs;
	}

	public double getTotSalary() {
		return totSalary;
	}

	public void setTotSalary(int totSalary) {
		if (getTotalHrs() > 40) {
			this.diffHrs = getTotalHrs() - 40;
			this.newRate = (float) 1.5 * getHourlyRate();
			this.totSalary = (getTotalHrs() * getHourlyRate() * 52) + (this.diffHrs * this.newRate * 52);
		} else {
			this.totSalary = getTotalHrs() * getHourlyRate() * 52;
		}

	}

	@Override
	public String toString() {
		/*
		 * return "SalariedEmployee [annualSalary=" + annualSalary +
		 * ", getAnnualSalary()=" + getAnnualSalary() + ", getSalalry()=" + getSalalry()
		 * + ", getEmployeeId()=" + getEmployeeId() + ", getName()=" + getName() +
		 * ", getAddress()=" + getAddress() + ", getDate()=" + getDate() +
		 * ", toString()=" + super.toString() + ", getClass()=" + getClass() +
		 * ", hashCode()=" + hashCode() + "]";
		 */
		return super.toString() + "   " + hourlyRate + "   " + newRate + "    " + totalHrs + "    " + diffHrs + "    "
				+ totSalary;
	}

}
