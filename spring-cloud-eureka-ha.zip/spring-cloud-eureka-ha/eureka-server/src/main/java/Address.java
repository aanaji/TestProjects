/*
 * This is single class program defines its constructors, setters, getters
 * and prints the value in the main method of application program when called 
 * with its set and get methods 
 *  
 */
public class Address {
	// declaring private variables
	private String streetName;
	private String cityName;
	private String stateName;
	private int zipCode;

	public Address() // creating constructor of the class EmployeeAddress
	{
		this.streetName = "";
		this.cityName = "";
		this.stateName = "";
		this.zipCode = 0;
	}

	public Address(String streetName, String cityName, String stateName, int zipCode) {
		super();
		this.streetName = streetName;
		this.cityName = cityName;
		this.stateName = stateName;
		this.zipCode = zipCode;
	}

	public String getStreetName() // calling getter method to return variable
	{
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName; // calling setter to set variable value
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName; // accessing private variable with 'this'
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	@Override
	public String toString() {
		return streetName + "    " + cityName + "    " + stateName + "   " + zipCode;
	}

}
