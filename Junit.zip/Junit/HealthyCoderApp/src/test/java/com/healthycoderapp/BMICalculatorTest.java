package com.healthycoderapp;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class BMICalculatorTest {

	@Test
	void should_ReturnTrue_When_DietRecommended() {
		// fail("Not yet implemented");

		// given : are the initial conditions, the input values

		double weight = 89.0;
		double height = 1.72;
		// when : where we invoke the methods under the test
		boolean recommended = BMICalculator.isDietRecommended(weight, height);
		// then : we provide assertion
		assertTrue(recommended);
	}

	@Test
	void should_ReturnFalse_When_DietRecommended() {
		// fail("Not yet implemented");

		// given : are the initial conditions, the input values

		double weight = 50.0;
		double height = 1.92;
		// when : where we invoke the methods under the test
		boolean recommended = BMICalculator.isDietRecommended(weight, height);
		// then : we provide assertion
		assertFalse(recommended);
	}

	@Test
	void should_ThrowException_When_DietRecommended() {
		// fail("Not yet implemented");

		// given : are the initial conditions, the input values

		double weight = 50.0;
		double height = 0.0;
		// when : where we invoke the methods under the test
		Executable executable = () -> BMICalculator.isDietRecommended(weight, height);
		// then : we provide assertion
		assertThrows(ArithmeticException.class, executable);
	}

	@Test
	void should_ReturnCoderWithWorstBMI_When_CodeListNotEmpty() {

		List<Coder> coder = new ArrayList<>();

		coder.add(new Coder(1.8, 60.0));
		coder.add(new Coder(1.82, 98.0));
		coder.add(new Coder(1.82, 64.7));

		Coder coderWorstBMI = BMICalculator.findCoderWithWorstBMI(coder);

		assertAll(() -> assertEquals(1.82, coderWorstBMI.getHeight()),
				() -> assertEquals(98.0, coderWorstBMI.getWeight()));
	}

	@Test
	void should_ReturnNull_When_CodeListIsEmpty() {

		List<Coder> coder = new ArrayList<>();

		// given

		// when
		Coder coderWorstBMI = BMICalculator.findCoderWithWorstBMI(coder);

		// then
		assertNull(coderWorstBMI);
	}

}
