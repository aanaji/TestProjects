import java.util.ArrayList;
import java.util.Arrays;

public class Test {

	static int abc = 0;
	static Object obja = new Object();

	public static void main(String[] args) {

		String test = "Ananda";

		System.out.println(Arrays.toString(test.split("^An")));
	}
}
